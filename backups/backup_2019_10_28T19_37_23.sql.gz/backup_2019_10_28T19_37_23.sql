--
-- PostgreSQL database dump
--

-- Dumped from database version 11.3 (Debian 11.3-1.pgdg90+1)
-- Dumped by pg_dump version 11.3 (Debian 11.3-1.pgdg90+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: authtoken_token; Type: TABLE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE TABLE public.authtoken_token (
    key character varying(40) NOT NULL,
    created timestamp with time zone NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.authtoken_token OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: patients_patient; Type: TABLE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE TABLE public.patients_patient (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    first_name character varying(140) NOT NULL,
    last_name character varying(140) NOT NULL,
    username character varying(15) NOT NULL,
    gender character varying(2) NOT NULL,
    birthdate date NOT NULL,
    doctor_id integer NOT NULL
);


ALTER TABLE public.patients_patient OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: patients_patient_id_seq; Type: SEQUENCE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE SEQUENCE public.patients_patient_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.patients_patient_id_seq OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: patients_patient_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER SEQUENCE public.patients_patient_id_seq OWNED BY public.patients_patient.id;


--
-- Name: users_profile; Type: TABLE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE TABLE public.users_profile (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    registration_number character varying(20),
    registration_type_id integer NOT NULL,
    speciality_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.users_profile OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: users_profile_id_seq; Type: SEQUENCE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE SEQUENCE public.users_profile_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_profile_id_seq OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: users_profile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER SEQUENCE public.users_profile_id_seq OWNED BY public.users_profile.id;


--
-- Name: users_registrationtype; Type: TABLE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE TABLE public.users_registrationtype (
    id integer NOT NULL,
    name character varying(250) NOT NULL,
    slug_name character varying(40) NOT NULL
);


ALTER TABLE public.users_registrationtype OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: users_registrationtype_id_seq; Type: SEQUENCE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE SEQUENCE public.users_registrationtype_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_registrationtype_id_seq OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: users_registrationtype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER SEQUENCE public.users_registrationtype_id_seq OWNED BY public.users_registrationtype.id;


--
-- Name: users_speciality; Type: TABLE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE TABLE public.users_speciality (
    id integer NOT NULL,
    name character varying(250) NOT NULL,
    slug_name character varying(40) NOT NULL
);


ALTER TABLE public.users_speciality OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: users_speciality_id_seq; Type: SEQUENCE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE SEQUENCE public.users_speciality_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_speciality_id_seq OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: users_speciality_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER SEQUENCE public.users_speciality_id_seq OWNED BY public.users_speciality.id;


--
-- Name: users_user; Type: TABLE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE TABLE public.users_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(150) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    email character varying(254) NOT NULL
);


ALTER TABLE public.users_user OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: users_user_groups; Type: TABLE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE TABLE public.users_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.users_user_groups OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE SEQUENCE public.users_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_groups_id_seq OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER SEQUENCE public.users_user_groups_id_seq OWNED BY public.users_user_groups.id;


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users_user.id;


--
-- Name: users_user_user_permissions; Type: TABLE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE TABLE public.users_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.users_user_user_permissions OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE SEQUENCE public.users_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_user_permissions_id_seq OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER SEQUENCE public.users_user_user_permissions_id_seq OWNED BY public.users_user_user_permissions.id;


--
-- Name: visits_firstvisitcomplementinformation; Type: TABLE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE TABLE public.visits_firstvisitcomplementinformation (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    depresion_mayor boolean NOT NULL,
    otros_transtornos boolean NOT NULL,
    hta_no_controlada boolean NOT NULL,
    tratamiento_hipoglucemiantes boolean NOT NULL,
    convulsiones boolean NOT NULL,
    factores_predisponentes boolean NOT NULL,
    anorexia boolean NOT NULL,
    abuso_alcohol boolean NOT NULL,
    tratamiento_actual boolean NOT NULL,
    embarazo boolean NOT NULL,
    glaucoma boolean NOT NULL,
    tratamiento_beta_bloqueantes boolean NOT NULL,
    actividad_fisica character varying(10) NOT NULL,
    dieta_hipocalorica boolean NOT NULL,
    palpitaciones_aumento_fc boolean NOT NULL,
    intolerancia_lactosa boolean NOT NULL,
    tratamiento_levodopa boolean NOT NULL,
    funcion_renal character varying(50) NOT NULL,
    alergia_naltrexona boolean NOT NULL,
    insuficiencia_hepatica character varying(10) NOT NULL,
    visit_id integer NOT NULL,
    cirugia_planificada boolean NOT NULL
);


ALTER TABLE public.visits_firstvisitcomplementinformation OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: visits_firstvisitcomplementinformation_id_seq; Type: SEQUENCE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE SEQUENCE public.visits_firstvisitcomplementinformation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.visits_firstvisitcomplementinformation_id_seq OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: visits_firstvisitcomplementinformation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER SEQUENCE public.visits_firstvisitcomplementinformation_id_seq OWNED BY public.visits_firstvisitcomplementinformation.id;


--
-- Name: visits_followupvisitcomplementinformation; Type: TABLE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE TABLE public.visits_followupvisitcomplementinformation (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    depresion_mayor boolean NOT NULL,
    otros_transtornos boolean NOT NULL,
    hta_no_controlada boolean NOT NULL,
    tratamiento_hipoglucemiantes boolean NOT NULL,
    convulsiones boolean NOT NULL,
    factores_predisponentes boolean NOT NULL,
    anorexia boolean NOT NULL,
    abuso_alcohol boolean NOT NULL,
    tratamiento_actual boolean NOT NULL,
    embarazo boolean NOT NULL,
    glaucoma boolean NOT NULL,
    tratamiento_beta_bloqueantes boolean NOT NULL,
    actividad_fisica character varying(10) NOT NULL,
    dieta_hipocalorica boolean NOT NULL,
    palpitaciones_aumento_fc boolean NOT NULL,
    intolerancia_lactosa boolean NOT NULL,
    tratamiento_levodopa boolean NOT NULL,
    hepatitis_aguda boolean NOT NULL,
    hipertension_arterial boolean NOT NULL,
    disfuncion_renal character varying(50) NOT NULL,
    nauseas boolean NOT NULL,
    constipacion boolean NOT NULL,
    cefalea boolean NOT NULL,
    mareos boolean NOT NULL,
    insomnio boolean NOT NULL,
    boca_seca boolean NOT NULL,
    diarrea boolean NOT NULL,
    vomitos boolean NOT NULL,
    dolor_abdominal boolean NOT NULL,
    otros_eventos boolean NOT NULL,
    incio_tratamiento_actual boolean NOT NULL,
    suspendio boolean NOT NULL,
    visit_id integer NOT NULL,
    cirugia_planificada boolean NOT NULL
);


ALTER TABLE public.visits_followupvisitcomplementinformation OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: visits_followupvisitcomplementinformation_id_seq; Type: SEQUENCE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE SEQUENCE public.visits_followupvisitcomplementinformation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.visits_followupvisitcomplementinformation_id_seq OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: visits_followupvisitcomplementinformation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER SEQUENCE public.visits_followupvisitcomplementinformation_id_seq OWNED BY public.visits_followupvisitcomplementinformation.id;


--
-- Name: visits_visit; Type: TABLE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE TABLE public.visits_visit (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    weight double precision NOT NULL,
    height double precision,
    type_visit character varying(10) NOT NULL,
    risk_factor boolean NOT NULL,
    doctor_id integer,
    patient_id integer NOT NULL,
    concept character varying(130),
    result text,
    percentage_evolution character varying(10),
    result_header text,
    treatment_weaks character varying(2)
);


ALTER TABLE public.visits_visit OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: visits_visit_id_seq; Type: SEQUENCE; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE SEQUENCE public.visits_visit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.visits_visit_id_seq OWNER TO "drTRFirsjjWlynNSYPKywpdutrRazkEk";

--
-- Name: visits_visit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER SEQUENCE public.visits_visit_id_seq OWNED BY public.visits_visit.id;


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: patients_patient id; Type: DEFAULT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.patients_patient ALTER COLUMN id SET DEFAULT nextval('public.patients_patient_id_seq'::regclass);


--
-- Name: users_profile id; Type: DEFAULT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.users_profile ALTER COLUMN id SET DEFAULT nextval('public.users_profile_id_seq'::regclass);


--
-- Name: users_registrationtype id; Type: DEFAULT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.users_registrationtype ALTER COLUMN id SET DEFAULT nextval('public.users_registrationtype_id_seq'::regclass);


--
-- Name: users_speciality id; Type: DEFAULT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.users_speciality ALTER COLUMN id SET DEFAULT nextval('public.users_speciality_id_seq'::regclass);


--
-- Name: users_user id; Type: DEFAULT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.users_user ALTER COLUMN id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Name: users_user_groups id; Type: DEFAULT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.users_user_groups ALTER COLUMN id SET DEFAULT nextval('public.users_user_groups_id_seq'::regclass);


--
-- Name: users_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.users_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.users_user_user_permissions_id_seq'::regclass);


--
-- Name: visits_firstvisitcomplementinformation id; Type: DEFAULT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.visits_firstvisitcomplementinformation ALTER COLUMN id SET DEFAULT nextval('public.visits_firstvisitcomplementinformation_id_seq'::regclass);


--
-- Name: visits_followupvisitcomplementinformation id; Type: DEFAULT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.visits_followupvisitcomplementinformation ALTER COLUMN id SET DEFAULT nextval('public.visits_followupvisitcomplementinformation_id_seq'::regclass);


--
-- Name: visits_visit id; Type: DEFAULT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.visits_visit ALTER COLUMN id SET DEFAULT nextval('public.visits_visit_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add permission	1	add_permission
2	Can change permission	1	change_permission
3	Can delete permission	1	delete_permission
4	Can view permission	1	view_permission
5	Can add group	2	add_group
6	Can change group	2	change_group
7	Can delete group	2	delete_group
8	Can view group	2	view_group
9	Can add content type	3	add_contenttype
10	Can change content type	3	change_contenttype
11	Can delete content type	3	delete_contenttype
12	Can view content type	3	view_contenttype
13	Can add session	4	add_session
14	Can change session	4	change_session
15	Can delete session	4	delete_session
16	Can view session	4	view_session
17	Can add log entry	5	add_logentry
18	Can change log entry	5	change_logentry
19	Can delete log entry	5	delete_logentry
20	Can view log entry	5	view_logentry
21	Can add Token	6	add_token
22	Can change Token	6	change_token
23	Can delete Token	6	delete_token
24	Can view Token	6	view_token
25	Can add Usuario	7	add_user
26	Can change Usuario	7	change_user
27	Can delete Usuario	7	delete_user
28	Can view Usuario	7	view_user
29	Can add Tipo de Matrícula	8	add_registrationtype
30	Can change Tipo de Matrícula	8	change_registrationtype
31	Can delete Tipo de Matrícula	8	delete_registrationtype
32	Can view Tipo de Matrícula	8	view_registrationtype
33	Can add Especialidad	9	add_speciality
34	Can change Especialidad	9	change_speciality
35	Can delete Especialidad	9	delete_speciality
36	Can view Especialidad	9	view_speciality
37	Can add Perfil	10	add_profile
38	Can change Perfil	10	change_profile
39	Can delete Perfil	10	delete_profile
40	Can view Perfil	10	view_profile
41	Can add Paciente	11	add_patient
42	Can change Paciente	11	change_patient
43	Can delete Paciente	11	delete_patient
44	Can view Paciente	11	view_patient
45	Can add Visita	12	add_visit
46	Can change Visita	12	change_visit
47	Can delete Visita	12	delete_visit
48	Can view Visita	12	view_visit
67	Can add Complemento Visita Seguimiento	34	add_followupvisitcomplementinformation
68	Can change Complemento Visita Seguimiento	34	change_followupvisitcomplementinformation
69	Can delete Complemento Visita Seguimiento	34	delete_followupvisitcomplementinformation
70	Can view Complemento Visita Seguimiento	34	view_followupvisitcomplementinformation
71	Can add Complemento Primera Visita	35	add_firstvisitcomplementinformation
72	Can change Complemento Primera Visita	35	change_firstvisitcomplementinformation
73	Can delete Complemento Primera Visita	35	delete_firstvisitcomplementinformation
74	Can view Complemento Primera Visita	35	view_firstvisitcomplementinformation
\.


--
-- Data for Name: authtoken_token; Type: TABLE DATA; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

COPY public.authtoken_token (key, created, user_id) FROM stdin;
4e4af0d0eee0d6ac3f64d54b0ccda97db6221c26	2019-08-31 06:23:05.627676+00	1
655e517a218297b46c4a3cb695cd2d09008ead88	2019-08-31 16:15:49.803185+00	5
d21c2c70fd364f8d446d1b448fe2d461ab5bba26	2019-08-31 20:56:22.188723+00	10
32834a9bce2e9e2aca1a9b2064f61920ca33b85e	2019-09-01 16:23:43.289318+00	15
73c06e903e64e274bb0a05594fcb7b5e25214743	2019-09-03 13:15:45.922986+00	18
070a77d7e11558479801ee2ddc85620a4e8d8586	2019-09-06 22:21:49.664908+00	19
4d28ddec7952284f497da0e34cffe329605500d6	2019-09-11 21:19:11.02264+00	23
c7d1de44e4b3edf75c6578ee650d0d1dfc95e6c9	2019-09-13 16:05:28.31298+00	28
279eaee545bdca120b9a438fbfa4a6bd9bd571d2	2019-09-13 16:16:09.898543+00	30
87f93fbc17b7bd0f62cf7cdc4faf96394d4d27c6	2019-09-16 19:05:18.113568+00	31
608e1c00e3b67babced92284912a72d0f5aff6f1	2019-09-17 18:45:28.923424+00	32
5f534297e03736e2f993a50c47a1847ac2439db4	2019-09-17 19:38:02.190891+00	33
3de55aef33987ce985701d874854e022b64877f4	2019-09-17 19:49:29.824957+00	34
8c074edc2c412b3db9089c4532a7c2d04c027639	2019-09-17 20:33:55.725112+00	35
be1cd2744e611484319a35a743e3493198f7e188	2019-09-20 14:39:10.122155+00	36
7e868dfa49994ea7dd7280f54df5c5d1ed509c0b	2019-10-05 04:04:55.413769+00	37
d2a4900175ae334713c1743b60d57a1303e400a0	2019-10-07 14:30:23.578884+00	70
7b7ed151af60605edab3e63ccdcaaa055478d3b1	2019-10-07 20:31:24.824534+00	71
b97d1f68ced0e61ebec243b9cd3bb8cfff3f4ade	2019-10-07 21:34:21.734387+00	72
4e7d3996827ac39de466c441fed342c3ca23f179	2019-10-08 00:35:46.113988+00	73
d32ec6f01ff40f4c362e20eddf888e5ec1c92fab	2019-10-08 03:02:25.953982+00	74
ee61fe68ec89ba05841ca822b31b517a37560618	2019-10-08 11:37:11.607025+00	75
bf05923ff987b2b14d988ad8d0293f465de783d5	2019-10-08 16:40:04.402528+00	76
396d3b035897cb9cff5b908f244633bbd6d75e7f	2019-10-08 18:24:17.056835+00	77
a61fe96798551c782aa1fafacd8f13ba7482e9ad	2019-10-08 18:43:08.88485+00	78
3ec4a1267ad4f2bc69bd6b288efae4dcb6142b7a	2019-10-08 18:43:24.385459+00	79
7389dbf35428dcb494a22050441d75da501662a4	2019-10-08 18:56:54.759445+00	80
0349061446e2eecbd7ce6e8624f5a59187a1a7e7	2019-10-08 19:03:06.123979+00	81
18680a1b8242588a4887e3ba58307f677ac07eb6	2019-10-08 19:05:54.881165+00	82
2d872c1ac1f5b0c9f535d96c07a9154af192f245	2019-10-08 19:06:57.770269+00	83
8dff58a1db2a601ad01bc7b3ffb6ea61c448a8da	2019-10-08 19:09:43.68357+00	84
e2481b8c2985e2e6393fb56ef98f425b5cbee0cc	2019-10-08 19:13:05.919549+00	85
d8569354f035c34af3645a4f99a1850c51b16fef	2019-10-08 19:13:54.668129+00	86
0f0ba7f64b054b30ff84b779569231a1a3c36c17	2019-10-08 19:24:44.488956+00	87
710bc864024ce2d63fd41fb91894e1927d7cabca	2019-10-08 19:30:39.804367+00	88
8f36318f3d14e8b22313d2581a083dec32391511	2019-10-08 19:34:25.443186+00	89
992c27e682376f876eb59f176cb699654d18cdf3	2019-10-08 19:41:47.802514+00	90
2cf90d90f5c00f63d4076a61c7333177619a73a9	2019-10-08 19:47:05.005034+00	91
af087dff1a9dcf6f1f9ada077374d1bbcc442526	2019-10-08 19:51:14.985861+00	92
87bf5e1e198bcb267ae4fb905961cfa7696e449c	2019-10-08 19:53:26.417593+00	93
df2d3cbf9b1636e296a70f29da06fdf9999a6b76	2019-10-08 20:02:05.723348+00	94
49ba70ea6a18998584e04519a817024ef0c668e1	2019-10-08 21:50:31.800016+00	95
a56e3de8d15378e0b4821155a5741c1455af6cbc	2019-10-08 22:09:39.200775+00	96
7cf9e8db1dd297f4301a4becd4cd139b98d30c52	2019-10-08 22:29:53.028978+00	97
b14f692a40cad5b1beb1461b239a7228475df706	2019-10-09 00:08:13.594396+00	98
0a2b760f699a9ad7b2e2de033874592de4d871c1	2019-10-09 01:03:31.303947+00	99
d605a173749c65ea545d216d3d3e94adb503826c	2019-10-09 09:30:08.166741+00	100
5592d5dbc4a27b4e2347e0e9e83e4e96cf1a2fbc	2019-10-09 11:25:12.761468+00	101
d73591842bf2067bb05677ed26dcadcaeee55890	2019-10-09 12:06:45.767493+00	102
78ce537cc21063c8058256124413566268a9fd5c	2019-10-09 13:44:19.045112+00	103
ca435ad6562b6edf16e3612565e1f02d905216bd	2019-10-09 15:57:01.391751+00	104
75df5dc097fb25cfc44a3ede50f4463de39958fb	2019-10-09 16:28:26.425966+00	105
9548dc23ab3a6361597bcdd6fb7f75991b57ec6b	2019-10-09 21:23:21.581898+00	106
e5222bed811b76e982bfd433b5b1535ecbb6158b	2019-10-09 21:42:51.447496+00	107
6af2f4bd8523a3d818bfc76e5fa2c4a8f8adc5fa	2019-10-09 22:36:18.774103+00	108
e50cc22082d5983824dc5e6edd90c584fcb23772	2019-10-10 00:16:50.66731+00	109
75c82a6896bb79a32ea6a9ecbb27da2e01db07c8	2019-10-10 12:20:44.151426+00	110
1c2db1ce943e038f2a0e42dcf7da3315a8f241ea	2019-10-10 12:44:16.946943+00	111
15e313971a52169a886b0983984d4ab53bda5026	2019-10-10 13:11:24.418485+00	112
eeb2500a650c6cbd84fbe9f17e6c161c6c2c8002	2019-10-10 13:17:49.19026+00	113
704185f3e0aa28f26f897baaccff677afc862483	2019-10-10 13:57:57.897989+00	114
2fd8f99798b196c40f2faa7dfa33623c69bc2967	2019-10-10 14:02:13.812006+00	115
0129603965358eb29d22459d9ad2e0614001e23d	2019-10-10 14:12:13.698459+00	116
25ec86ab92e58c498899cd375f47336a38121524	2019-10-10 14:30:07.502855+00	117
268ff394fa02ef3f3cffc5dd873cc07d524aa327	2019-10-10 14:39:01.841176+00	118
170990aacd70980e578264fcae9a59381d750698	2019-10-10 15:52:30.63774+00	119
bbc67b1f92091635195bb918145dc810795cea1f	2019-10-10 16:43:25.929177+00	120
65c865376449d8d7e8e6c2e6d10a2edb26f42518	2019-10-10 16:45:37.116178+00	121
ce4138a2b7553701871850214d6f55ff2ec18fdb	2019-10-10 16:50:00.612865+00	122
681f0440d5eba4990094c69dc0df502582630d63	2019-10-10 17:19:13.748858+00	123
366ddf9222b2713e1c057d13af6e35ed465d97bc	2019-10-10 17:32:54.028642+00	124
b23b718af07936b3a9586bc8856a9ebe9a1e64f8	2019-10-10 17:36:42.733915+00	125
5563c4ee860c6d03ffa19fa6481abd791dac7697	2019-10-10 18:14:59.391315+00	126
523821d722c718a5e752edc4f71b7279468d1028	2019-10-10 18:56:27.741609+00	127
fb203f0eb339c7e8e1cc9c19915a67e20c76b13e	2019-10-10 19:26:56.588685+00	128
98314e6316c3a397492a67109bdd2d26b8723b6e	2019-10-10 20:18:01.197962+00	129
0331f576f78fa1fcd131b7fdd19f3d72e2c40841	2019-10-10 21:13:15.001335+00	130
c0394bd3282001666b5fbf54400303b1c7682211	2019-10-10 21:26:28.702583+00	131
4a9e3d067c86f91b87683cdcd2f2ca2b15cbf90d	2019-10-10 21:37:06.906682+00	132
abe26321869272cbc54afd0b23f0f8d0b983e3fd	2019-10-10 22:06:50.132121+00	133
6c495bb0a9dd6e11eb92b03543dbef75dfa12ff2	2019-10-10 22:46:51.005102+00	134
c18921e6a69952cc8e708cf9e176e598a4865e9f	2019-10-10 23:05:32.039093+00	135
bac5188c8c2273f2381d851ea67774d50f82b9be	2019-10-10 23:19:58.702378+00	136
49c6240fbe657c1119b3215b6887be15dedf62d6	2019-10-11 01:35:17.234527+00	137
e009caafcfeef7a099f1975d5b76f91fcb0b84c9	2019-10-11 01:37:37.934994+00	138
9c5ff8b6679f7b975fe9292517c5cf1625b4df8d	2019-10-11 01:42:51.964595+00	139
d7be76d1fc6d13cd5e2755182c0c9dacbce023e9	2019-10-11 02:05:10.89157+00	140
551f79a64f3f023a77552b9ce64097fd1dbc501f	2019-10-11 02:30:36.065387+00	141
d7bca31edb970ef04c6cf61ef0345a91e530ca10	2019-10-11 02:52:15.892861+00	142
25027bee14f34016e75fcb0a58ec503a83bdf33c	2019-10-11 03:12:19.681083+00	143
7726beb7fc643eb64b087f5109584e3b8b5287ef	2019-10-11 03:12:49.781611+00	144
fd8cc53d4764149d687073d0f70080e9aeadd9e2	2019-10-11 04:42:39.404874+00	145
e5d02725fa277a78678405cbbb6444ab7df1c98e	2019-10-11 10:52:42.292701+00	146
4d4957c460e12e945b943868ddf3061c7a05af30	2019-10-11 11:04:56.195113+00	147
ea820ab366919d1952a5ab0b68b934cf13e4c2f2	2019-10-11 11:26:58.702672+00	148
a6f92fcc64f2082b50b2567346c3d9eaa3812df0	2019-10-11 11:53:00.898623+00	149
6aa137e1e17f7d32941945761616b24e7653c2bc	2019-10-11 12:05:12.427953+00	150
e0d5b10504193556ff10338c1316e94274542b69	2019-10-11 12:19:43.467166+00	151
c8882666a45483ac9da618da9ad5ab7017592f28	2019-10-11 12:41:27.961329+00	152
1be3f9292e755cd00f056fef62e5eca2efeddf93	2019-10-11 13:04:24.146457+00	153
a6fa52d31f5a6ff50023d3684867ae030d6f9347	2019-10-11 13:10:35.864337+00	154
30395b544951fccf4ae027ae66a8fbde73b36c6d	2019-10-11 13:26:14.988851+00	155
b7418b9609999b5bbc5f6b15466a50f98bf3c820	2019-10-11 13:53:05.048422+00	156
6b272272090147d9d88a3f542205b9e51004fff0	2019-10-11 14:15:34.522361+00	157
7e2511a1ef4ccaac093ddf311f43a1c74351800d	2019-10-11 15:47:29.389354+00	158
c3fc8b8c6b4f93a64c522f383c9c73d99e17c9d7	2019-10-11 15:48:17.911417+00	159
1c529754f2064f714643cfadcd6131174d7a3dea	2019-10-11 17:25:55.902824+00	160
6cdf7fffe659f89e8a4cace989477f0eabcdb6e1	2019-10-11 18:10:17.213465+00	161
4a98bbca3870e2db2cffc090c82464382436bbac	2019-10-11 18:15:45.717252+00	162
363b0ea0156c4e0082975e5342aa0a7e1ee81b1b	2019-10-11 20:03:12.971507+00	163
49fc02c6e8d45c42d654fcc34daac363b881021c	2019-10-12 00:09:14.381889+00	164
463cbc83c8fe4b39488aab8906fc60abcf5f0090	2019-10-12 07:27:31.591978+00	165
36a8060d0a2cce744489d32d02907a3dc09bb732	2019-10-12 11:37:53.108038+00	166
5c15b4beda815c2061addc9f9db1fc0abd5be8ab	2019-10-14 13:54:39.804423+00	167
1f8997e6dc17ddb94957b4ecbf3f8ecc8e8d25c5	2019-10-14 14:38:53.641187+00	168
3883e3b92fdf7dd38bd96ebfc70a00ed35428be1	2019-10-14 23:03:26.433838+00	189
c886fd14dc1db39765fddbb1c3f297fd1cf899be	2019-10-15 15:29:57.170288+00	191
1902e34c5f1c5697b5b75fef830beea0e9e2cc92	2019-10-15 16:09:48.280896+00	192
5a0d94f83cb681465443531e598e6e5852d68dd6	2019-10-15 16:53:49.342452+00	193
0d5c1d1890a97c610f0dc3dfe980e689e2afbf5f	2019-10-15 21:27:33.912805+00	194
89aa3738f9a55d3701f4dbc744a72895459f0e19	2019-10-15 22:42:50.240906+00	195
e32f4ecd8f542f819c90362ee8e332d818ea54ce	2019-10-16 17:02:35.153966+00	196
426e6bf24b67749ab00de495c1d02b60e7173b3c	2019-10-16 23:37:10.484485+00	197
92d4c47c6a752bd59ae84e1644b13b03c6c5c9d8	2019-10-17 03:05:24.43912+00	198
36e4d1c59733c759ee91456f0caf2ece36155420	2019-10-17 11:59:34.815778+00	199
ca40c94f2980ad4e2fdb0a6ef3ffdae7933dcec1	2019-10-17 16:21:32.068439+00	200
b5f1dad54c1d5be04db0a45e955b591313b513cf	2019-10-17 18:02:29.764451+00	201
d8efb5bb64fee7bdd568b5727bdd10b8a8d3097e	2019-10-17 18:27:58.762721+00	202
25510748299e2294bdb9e1af9a84f6f0b2ed9f23	2019-10-17 23:50:47.630426+00	203
c0075f3ddc28cbd42257902a4013982ed14edbe7	2019-10-18 15:41:48.340225+00	204
c53409e0e2018ecef98641cace7399ef94cf66cb	2019-10-19 15:24:55.732119+00	205
4dc4dc756cdda94399c3afacc80601e7204396d4	2019-10-19 18:12:56.861707+00	206
31c7e058f271cd6d5c0513ddf8559d76ec212c50	2019-10-19 20:48:44.979132+00	207
6d5d5ad596e62a329cc61f8c5ee7a84d36a1690a	2019-10-20 22:48:54.397462+00	208
fea7135c1dbc4b664bfbf180549979b41413d396	2019-10-21 18:16:13.490946+00	209
d618a1ddfaec1663caf07acc208f5db0d0667777	2019-10-22 15:25:14.797872+00	210
3b7d46e0bf66ece73a57983c7476cc9b0a8783a7	2019-10-22 20:02:12.197527+00	211
55d299a5bfa919d7490b61f9596745e53a7c3b7c	2019-10-23 12:29:18.945152+00	212
22d4b235db9ce3345092fc6a42f21e2dbdedc6a6	2019-10-23 15:19:01.238999+00	213
546850c5ba5bc7fe29ec72683ceb52981802c98b	2019-10-23 20:25:49.196864+00	214
774b760c39af99abafd1bc60d2d57491b4a502dc	2019-10-23 20:38:51.414674+00	215
fbe10063962e3bd8a9357719cb14d04a39a85ecd	2019-10-23 20:58:09.313834+00	216
9d490d0227a9a0935445d0e1b8050eb2af68dfee	2019-10-24 03:47:04.303876+00	217
a737340c508df78071db720b2d7a3200db173fd6	2019-10-24 11:36:19.188519+00	218
d404fa6fde8140cf35becf9e550b41443a4cff1b	2019-10-24 17:40:50.56547+00	219
a1c59acca7ff0fb09f2cd0a8e7a614e6d9b6b9d4	2019-10-25 15:14:53.230372+00	220
ef2e7c4c4f4fe8da5af4ecfd717e61e5bf88d0e6	2019-10-26 17:18:41.02882+00	221
38a8b8c263c2395ee5d30240b4755d4c2c3646d7	2019-10-28 16:47:00.219515+00	222
5b80b9b6b264e888a168ff4d163f1639feb9b0f5	2019-10-28 17:46:46.590591+00	223
466b9101256fd3cdc7d2fcb5893cc071accce8f0	2019-10-28 18:02:05.08183+00	224
3f8c9130316a403e36c019d38cdfc59f4bf7dc38	2019-10-28 18:36:20.236437+00	225
53d9ed127dedfc5379dacd2e5b4da7d19fe569e9	2019-10-28 18:49:59.144796+00	226
dcb6400e10c8b4c6dfaec27360076fcf933fef26	2019-10-28 18:51:42.581566+00	227
ee64dd089d01dd8b3eb16c3f76fd60c060c03684	2019-10-28 19:21:26.865172+00	228
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2019-08-31 04:38:47.493286+00	1	especialidad	1	[{"added": {}}]	9	1
2	2019-08-31 04:39:07.565572+00	1	matricula	1	[{"added": {}}]	8	1
3	2019-08-31 04:43:43.326165+00	2	catalina.picco@gmail.com	1	[{"added": {}}]	7	1
4	2019-08-31 06:29:31.81536+00	3	adfadfadf123	1	[{"added": {}}]	11	1
37	2019-08-31 06:56:54.850627+00	1	cardio	2	[{"changed": {"fields": ["name"]}}]	9	1
38	2019-08-31 06:57:11.47241+00	1	Cardiología	2	[{"changed": {"fields": ["name", "slug_name"]}}]	9	1
39	2019-08-31 06:57:17.916817+00	1	Cardiología	2	[]	9	1
40	2019-08-31 06:57:29.854952+00	2	Clínica médica	1	[{"added": {}}]	9	1
41	2019-08-31 06:57:48.780856+00	3	Endocrinología	1	[{"added": {}}]	9	1
42	2019-08-31 06:57:57.559903+00	4	Nutrición	1	[{"added": {}}]	9	1
43	2019-08-31 06:58:26.566809+00	5	Otras	1	[{"added": {}}]	9	1
44	2019-08-31 06:58:52.071756+00	1	Nacional	2	[{"changed": {"fields": ["name", "slug_name"]}}]	8	1
45	2019-08-31 06:59:00.354966+00	2	Provincial	1	[{"added": {}}]	8	1
46	2019-08-31 06:59:07.398436+00	3	En trámite	1	[{"added": {}}]	8	1
47	2019-08-31 07:00:52.594874+00	2	catalina.picco@gmail.com	3		7	1
48	2019-08-31 16:09:58.894215+00	5	catalina.picco@gmail.com	1	[{"added": {}}]	7	1
49	2019-08-31 16:11:19.622659+00	5	catalina.picco@gmail.com	2	[{"changed": {"fields": ["first_name", "last_name", "email", "last_login"]}}]	7	1
50	2019-08-31 16:13:16.469088+00	37	pepitoperez123	1	[{"added": {}}]	11	1
51	2019-08-31 17:48:57.551847+00	4	123456	3		7	1
52	2019-08-31 20:14:58.57607+00	7	123456	3		7	1
53	2019-08-31 20:27:58.265151+00	8	123456	3		7	1
54	2019-08-31 20:50:54.601224+00	9	123456	3		7	1
55	2019-08-31 23:43:46.594082+00	10	123456	2	[{"changed": {"fields": ["email"]}}]	7	1
56	2019-08-31 23:44:37.479651+00	40	user_OmLam8	3		11	1
57	2019-09-01 01:13:14.863254+00	43	user_TeTef2	3		11	1
58	2019-09-01 01:39:40.053035+00	48	user_MaYaf5	3		11	1
59	2019-09-01 01:39:40.053967+00	47	user_ElYaf8	3		11	1
60	2019-09-01 01:39:40.054506+00	46	user_TeTem8	3		11	1
61	2019-09-01 01:39:40.055062+00	45	user_LePam9	3		11	1
62	2019-09-01 01:39:40.055615+00	44	user_PaPem7	3		11	1
63	2019-09-01 01:39:40.056159+00	42	user_MaMaf7	3		11	1
64	2019-09-01 01:43:23.957255+00	50	user_ElYaf6	3		11	1
65	2019-09-01 01:43:23.958122+00	49	user_DiCom6	3		11	1
66	2019-09-01 03:30:44.642118+00	61	user_KiBjm1	3		11	1
67	2019-09-01 03:30:44.643026+00	60	user_TyGgm7	3		11	1
68	2019-09-01 03:30:44.643549+00	59	user_DaGom6	3		11	1
69	2019-09-01 03:30:44.644073+00	58	user_CuChf6	3		11	1
70	2019-09-01 03:58:17.456053+00	3	Patient: Omar visited Doctor: 123456. for: First	3		12	1
71	2019-09-01 06:46:24.746368+00	67	user_XaAlm4	3		11	1
72	2019-09-01 06:46:24.747324+00	66	user_PiPem2	3		11	1
73	2019-09-01 06:46:24.747874+00	65	user_LeMem5	3		11	1
74	2019-09-01 06:46:24.74846+00	64	user_PaPem4	3		11	1
75	2019-09-01 06:46:24.748969+00	63	user_AlMam2	3		11	1
76	2019-09-01 06:46:24.74953+00	62	user_PeHm7	3		11	1
77	2019-09-01 06:46:24.750146+00	57	user_YfIcm6	3		11	1
78	2019-09-01 06:46:24.750696+00	56	user_DoItf6	3		11	1
79	2019-09-01 06:46:24.751241+00	55	user_DyDyf3	3		11	1
80	2019-09-01 06:46:24.75177+00	54	user_5775f7	3		11	1
81	2019-09-01 06:46:24.75231+00	53	user_6575f8	3		11	1
82	2019-09-01 14:10:20.2481+00	69	user_JoAtm9	3		11	1
83	2019-09-01 14:10:20.249045+00	68	user_JuPem7	3		11	1
84	2019-09-01 14:38:40.11792+00	4	Patient: Omar visited Doctor: 123456. for: First	3		12	1
85	2019-09-01 14:41:15.802641+00	2	Patient: juan alejandro visited Doctor: alejo. for: follow-up	2	[{"changed": {"fields": ["type_visit"]}}]	12	1
86	2019-09-01 14:41:38.345021+00	1	Patient: juan alejandro visited Doctor: alejo. for: first	2	[{"changed": {"fields": ["type_visit"]}}]	12	1
87	2019-09-01 15:02:19.775419+00	72	user_DaLaf5	3		11	1
88	2019-09-01 15:02:19.776299+00	71	user_JoQum2	3		11	1
89	2019-09-01 15:02:19.776848+00	70	user_FlEnf7	3		11	1
90	2019-09-01 16:11:06.369279+00	2	Clínica médica	2	[{"changed": {"fields": ["slug_name"]}}]	9	1
91	2019-09-01 16:11:50.740954+00	12	1234567	3		7	1
92	2019-09-01 17:34:37.375248+00	82	user_JoLim2	3		11	1
93	2019-09-01 17:34:37.376079+00	81	user_JuChm7	3		11	1
94	2019-09-01 17:34:37.376634+00	80	user_JuMam6	3		11	1
95	2019-09-01 17:34:37.377218+00	79	user_CaPem2	3		11	1
96	2019-09-01 17:34:37.377808+00	78	user_AlChm2	3		11	1
97	2019-09-01 17:34:37.378363+00	77	user_sapim7	3		11	1
98	2019-09-01 17:34:37.378913+00	76	user_PaCam5	3		11	1
99	2019-09-01 17:34:37.379432+00	75	user_sepim2	3		11	1
100	2019-09-01 17:34:37.379993+00	74	user_JuPam1	3		11	1
101	2019-09-01 17:34:37.380531+00	73	user_ElYsf1	3		11	1
102	2019-09-01 17:34:37.381103+00	52	user_AnFif1	3		11	1
103	2019-09-01 21:13:35.804232+00	3	alejo	3		7	1
104	2019-09-01 21:13:35.805011+00	16	alejoad	3		7	1
105	2019-09-01 22:06:41.828355+00	17	florencia.rolandi@gmail.com	1	[{"added": {}}]	7	1
106	2019-09-01 22:11:15.517901+00	17	florencia.rolandi@gmail.com	2	[{"changed": {"fields": ["password"]}}]	7	1
107	2019-09-01 22:11:52.07975+00	17	florencia.rolandi@gmail.com	2	[{"changed": {"fields": ["first_name", "last_name", "email", "is_staff", "is_superuser"]}}]	7	1
108	2019-09-02 22:40:05.515568+00	53	Patient: PRUEBA 1 visited Doctor: 123456. for: follow-up	3		12	17
109	2019-09-02 23:00:10.941563+00	2	Patient: jose visited Doctor: 123456. for: first	3		34	17
110	2019-09-02 23:51:18.867181+00	56	Patient: PRUEBA 1 visited Doctor: 123456. for: follow-up	3		12	17
111	2019-09-02 23:51:18.868176+00	55	Patient: PRUEBA 1 visited Doctor: 123456. for: follow-up	3		12	17
112	2019-09-02 23:51:18.868785+00	54	Patient: PRUEBA 1 visited Doctor: 123456. for: follow-up	3		12	17
113	2019-09-02 23:51:18.869328+00	52	Patient: tete visited Doctor: 123456. for: first	3		12	17
114	2019-09-02 23:51:18.869941+00	51	Patient: Perez visited Doctor: 123456. for: follow-up	3		12	17
115	2019-09-02 23:51:18.870446+00	50	Patient: Gaba visited Doctor: 123456. for: follow-up	3		12	17
116	2019-09-02 23:51:18.871+00	49	Patient: Gaba visited Doctor: 123456. for: follow-up	3		12	17
117	2019-09-02 23:51:18.871505+00	48	Patient: Fabian visited Doctor: 456holauser. for: follow-up	3		12	17
118	2019-09-02 23:51:18.872085+00	47	Patient: Roque visited Doctor: 456holauser. for: follow-up	3		12	17
119	2019-09-02 23:51:18.872627+00	46	Patient: Catalina visited Doctor: 456holauser. for: first	3		12	17
120	2019-09-02 23:51:18.873184+00	45	Patient: jose visited Doctor: 123456. for: first	3		12	17
121	2019-09-02 23:51:18.873768+00	44	Patient: PRUEBA 1 visited Doctor: 123456. for: first	3		12	17
122	2019-09-02 23:51:18.874334+00	43	Patient: jose visited Doctor: 123456. for: first	3		12	17
123	2019-09-02 23:51:18.87524+00	42	Patient: jose visited Doctor: 123456. for: first	3		12	17
124	2019-09-02 23:51:18.875858+00	41	Patient: test aaaa visited Doctor: 123456. for: first	3		12	17
125	2019-09-02 23:51:18.876402+00	40	Patient: flor visited Doctor: 123456. for: first	3		12	17
126	2019-09-02 23:51:18.876961+00	39	Patient: Florencia visited Doctor: 123456. for: first	3		12	17
127	2019-09-02 23:51:18.877485+00	38	Patient: juan visited Doctor: 123456. for: first	3		12	17
128	2019-09-02 23:51:18.878126+00	37	Patient: juan visited Doctor: 456holauser. for: first	3		12	17
129	2019-09-02 23:51:18.878704+00	36	Patient: juan visited Doctor: 456holauser. for: first	3		12	17
130	2019-09-02 23:51:18.87928+00	35	Patient: Fabian visited Doctor: 456holauser. for: first	3		12	17
131	2019-09-02 23:51:18.879818+00	34	Patient: Roque visited Doctor: 456holauser. for: first	3		12	17
132	2019-09-02 23:51:18.880391+00	33	Patient: Paciente visited Doctor: 123456. for: first	3		12	17
133	2019-09-02 23:51:18.880972+00	32	Patient: claudio visited Doctor: 123456. for: first	3		12	17
134	2019-09-02 23:51:18.881485+00	31	Patient: Sancho visited Doctor: 123456. for: first	3		12	17
135	2019-09-02 23:51:18.882081+00	30	Patient: Sofia visited Doctor: 123456. for: first	3		12	17
136	2019-09-02 23:51:18.882596+00	29	Patient: Eleonor visited Doctor: 123456. for: first	3		12	17
137	2019-09-02 23:51:18.883128+00	28	Patient: maria visited Doctor: 123456. for: first	3		12	17
138	2019-09-02 23:51:18.883669+00	27	Patient: Perez visited Doctor: 123456. for: first	3		12	17
139	2019-09-02 23:51:18.884227+00	26	Patient: Ana visited Doctor: 123456. for: first	3		12	17
140	2019-09-02 23:51:18.884901+00	25	Patient: Talia visited Doctor: 123456. for: first	3		12	17
141	2019-09-02 23:51:18.885411+00	24	Patient: pamela visited Doctor: 123456. for: first	3		12	17
142	2019-09-02 23:51:18.886011+00	23	Patient: juan visited Doctor: 123456. for: first	3		12	17
143	2019-09-02 23:51:18.886558+00	22	Patient: Cata visited Doctor: 123456. for: first	3		12	17
144	2019-09-02 23:51:18.887257+00	21	Patient: Hector visited Doctor: 123456. for: first	3		12	17
145	2019-09-02 23:51:18.887807+00	20	Patient: Gaba visited Doctor: 123456. for: first	3		12	17
146	2019-09-02 23:51:18.888354+00	19	Patient: test visited Doctor: 123456. for: first	3		12	17
147	2019-09-02 23:51:18.888943+00	18	Patient: Lana visited Doctor: 123456. for: first	3		12	17
148	2019-09-02 23:51:18.88951+00	17	Patient: Luis visited Doctor: 123456. for: first	3		12	17
149	2019-09-02 23:51:18.890108+00	16	Patient: Cggarla visited Doctor: 67432659763256. for: first	3		12	17
150	2019-09-02 23:51:18.890622+00	15	Patient: Carla visited Doctor: 67432659763256. for: first	3		12	17
151	2019-09-02 23:51:18.891327+00	14	Patient: Carla visited Doctor: 67432659763256. for: first	3		12	17
152	2019-09-02 23:51:18.891885+00	13	Patient: Pepito visited Doctor: 67432659763256. for: first	3		12	17
153	2019-09-02 23:51:18.892412+00	12	Patient: fito visited Doctor: 67432659763256. for: first	3		12	17
154	2019-09-02 23:51:18.892975+00	11	Patient: prueba visited Doctor: 67432659763256. for: first	3		12	17
155	2019-09-02 23:51:18.893471+00	10	Patient: Fabian visited Doctor: 67432659763256. for: first	3		12	17
156	2019-09-02 23:51:18.894064+00	9	Patient: Juana visited Doctor: 67432659763256. for: first	3		12	17
157	2019-09-02 23:51:18.894578+00	8	Patient: Carla visited Doctor: 67432659763256. for: first	3		12	17
158	2019-09-02 23:51:18.895173+00	5	Patient: Omar visited Doctor: 123456. for: first	3		12	17
159	2019-09-03 01:34:25.613971+00	74	Patient: Ale visited Doctor: 123456. for: follow-up	3		12	17
160	2019-09-03 01:34:25.614943+00	73	Patient: jose visited Doctor: 123456. for: first	3		12	17
161	2019-09-03 01:34:25.615489+00	72	Patient: Pablo visited Doctor: 123holauser. for: first	3		12	17
162	2019-09-03 01:34:25.616043+00	71	Patient: Ale visited Doctor: 123456. for: first	3		12	17
163	2019-09-03 01:34:25.616581+00	70	Patient: Sole visited Doctor: 123456. for: first	3		12	17
164	2019-09-03 01:34:25.617123+00	69	Patient: rfv visited Doctor: 123456. for: first	3		12	17
165	2019-09-03 01:34:25.617665+00	68	Patient: qaz visited Doctor: 123456. for: first	3		12	17
166	2019-09-03 01:34:25.618227+00	67	Patient: test aaaa visited Doctor: 123456. for: first	3		12	17
167	2019-09-03 01:34:25.618777+00	66	Patient: mayor visited Doctor: 123456. for: first	3		12	17
168	2019-09-03 01:34:25.619311+00	65	Patient: AAAA visited Doctor: 123456. for: first	3		12	17
169	2019-09-03 01:34:25.619851+00	64	Patient: aa visited Doctor: 123456. for: first	3		12	17
170	2019-09-03 01:34:25.620399+00	63	Patient: PRUEBA 1 visited Doctor: 123456. for: first	3		12	17
171	2019-09-03 01:34:25.620937+00	62	Patient: paciente aaa visited Doctor: 123456. for: first	3		12	17
172	2019-09-03 01:34:25.621478+00	61	Patient: paciente a visited Doctor: 123456. for: first	3		12	17
173	2019-09-03 01:34:25.622033+00	60	Patient: Sole visited Doctor: 123456. for: first	3		12	17
174	2019-09-03 01:34:25.622576+00	59	Patient: Sole visited Doctor: 123456. for: first	3		12	17
175	2019-09-03 01:34:25.623124+00	58	Patient: Omar visited Doctor: 123456. for: follow-up	3		12	17
176	2019-09-03 01:34:25.623665+00	57	Patient: Omar visited Doctor: 123456. for: first	3		12	17
177	2019-09-03 01:34:37.599068+00	173	user_PaZim7	3		11	17
178	2019-09-03 01:34:37.599857+00	172	user_AlLom6	3		11	17
179	2019-09-03 01:34:37.600389+00	171	user_rftgm7	3		11	17
180	2019-09-03 01:34:37.600911+00	170	user_qawsm6	3		11	17
181	2019-09-03 01:34:37.601429+00	169	user_ma65m9	3		11	17
182	2019-09-03 01:34:37.601984+00	168	user_AABBf2	3		11	17
183	2019-09-03 01:34:37.602506+00	167	user_aabbf2	3		11	17
184	2019-09-03 01:34:37.60303+00	166	user_paaam5	3		11	17
185	2019-09-03 01:34:37.603547+00	165	user_papam7	3		11	17
186	2019-09-03 01:34:37.604068+00	164	user_Sofef2	3		11	17
187	2019-09-03 01:34:37.604591+00	163	user_SoFef9	3		11	17
188	2019-09-03 01:34:37.605114+00	162	user_SoFef1	3		11	17
189	2019-09-03 01:34:37.60564+00	161	user_HdHzm7	3		11	17
190	2019-09-03 01:34:37.606202+00	160	user_HoHom2	3		11	17
191	2019-09-03 01:34:37.606742+00	159	user_QdUfm9	3		11	17
192	2019-09-03 01:34:37.607266+00	158	user_QdUfm1	3		11	17
193	2019-09-03 01:34:37.607787+00	157	user_QdUfm5	3		11	17
194	2019-09-03 01:34:37.608304+00	156	user_QdUfm7	3		11	17
195	2019-09-03 01:34:37.608835+00	155	user_CaPaf4	3		11	17
196	2019-09-03 01:34:37.609355+00	154	user_PRPRf7	3		11	17
197	2019-09-03 01:34:37.609905+00	153	user_jopem8	3		11	17
198	2019-09-03 01:34:37.610428+00	151	user_jopem1	3		11	17
199	2019-09-03 01:34:37.610944+00	148	user_jopem9	3		11	17
200	2019-09-03 01:34:37.611468+00	147	user_jopem2	3		11	17
201	2019-09-03 01:34:37.611985+00	142	user_jopem3	3		11	17
202	2019-09-03 01:34:37.612503+00	141	user_jopem5	3		11	17
203	2019-09-03 01:34:37.613168+00	140	user_jopem7	3		11	17
204	2019-09-03 01:34:37.613696+00	139	user_jopem6	3		11	17
205	2019-09-03 01:34:37.614249+00	138	user_jopem4	3		11	17
206	2019-09-03 01:34:37.614783+00	137	user_tetef2	3		11	17
207	2019-09-03 01:34:37.615286+00	136	user_flrof2	3		11	17
208	2019-09-03 01:34:37.615827+00	135	user_flrof9	3		11	17
209	2019-09-03 01:34:37.616365+00	134	user_flrof3	3		11	17
210	2019-09-03 01:34:37.616889+00	133	user_flrof6	3		11	17
211	2019-09-03 01:34:37.617408+00	132	user_jupem4	3		11	17
212	2019-09-03 01:34:37.617981+00	131	user_papaf4	3		11	17
213	2019-09-03 01:34:37.618528+00	130	user_Cggdf3	3		11	17
214	2019-09-03 01:34:37.619057+00	129	user_jupef7	3		11	17
215	2019-09-03 01:34:37.619581+00	128	user_jupef8	3		11	17
216	2019-09-03 01:34:37.620122+00	127	user_FaPim1	3		11	17
217	2019-09-03 01:34:37.62064+00	125	user_PaNum9	3		11	17
218	2019-09-03 01:34:37.621163+00	124	user_clenm1	3		11	17
219	2019-09-03 01:34:37.621686+00	123	user_Sapaf1	3		11	17
220	2019-09-03 01:34:37.622244+00	122	user_SoVaf2	3		11	17
221	2019-09-03 01:34:37.622769+00	121	user_ElLof1	3		11	17
222	2019-09-03 01:34:37.623291+00	120	user_maluf1	3		11	17
223	2019-09-03 01:34:37.623822+00	119	user_TaBef6	3		11	17
224	2019-09-03 01:34:37.624341+00	118	user_paanf3	3		11	17
225	2019-09-03 01:34:37.624868+00	117	user_jupem1	3		11	17
226	2019-09-03 01:34:37.625394+00	116	user_CaPif9	3		11	17
227	2019-09-03 01:34:37.625937+00	115	user_HeRom1	3		11	17
228	2019-09-03 01:34:37.626458+00	114	user_tetef7	3		11	17
229	2019-09-03 01:34:37.626985+00	113	user_AnPef3	3		11	17
230	2019-09-03 01:34:37.627504+00	112	user_tetef8	3		11	17
231	2019-09-03 01:34:37.628028+00	111	user_prprm7	3		11	17
232	2019-09-03 01:34:37.628545+00	109	user_tetem9	3		11	17
233	2019-09-03 01:34:37.629064+00	107	user_tetem5	3		11	17
234	2019-09-03 01:34:37.629589+00	106	user_FlRof1	3		11	17
235	2019-09-03 01:34:37.63013+00	105	user_tetem1	3		11	17
236	2019-09-03 01:34:37.630702+00	104	user_LaDef3	3		11	17
237	2019-09-03 01:34:37.631221+00	103	user_tetwf5	3		11	17
238	2019-09-03 01:34:37.631759+00	102	user_LuCam1	3		11	17
239	2019-09-03 01:34:37.632302+00	101	user_Cggdf4	3		11	17
240	2019-09-03 01:34:37.632851+00	100	user_PeGam7	3		11	17
241	2019-09-03 01:34:37.633376+00	99	user_GaDif5	3		11	17
242	2019-09-03 01:34:37.633941+00	98	user_Cagdf9	3		11	17
243	2019-09-03 01:34:37.634491+00	97	user_prsef8	3		11	17
244	2019-09-03 01:34:37.63502+00	96	user_hopaf5	3		11	17
245	2019-09-03 01:34:37.635537+00	95	user_flpaf8	3		11	17
246	2019-09-03 01:34:37.636076+00	94	user_Cagdf7	3		11	17
247	2019-09-03 01:34:37.636624+00	92	user_edfem7	3		11	17
248	2019-09-03 01:34:37.637174+00	91	user_clvaf2	3		11	17
249	2019-09-03 01:34:37.637702+00	90	user_ninef2	3		11	17
250	2019-09-03 01:34:37.638265+00	89	user_CaArf7	3		11	17
251	2019-09-03 01:34:37.63896+00	88	user_PeLof3	3		11	17
252	2019-09-03 01:34:37.639509+00	87	user_fipam1	3		11	17
253	2019-09-03 01:34:37.640044+00	86	user_prprm6	3		11	17
254	2019-09-03 01:34:37.640556+00	85	user_FaPim7	3		11	17
255	2019-09-03 01:34:37.641076+00	84	user_JuLof3	3		11	17
256	2019-09-03 01:34:37.641602+00	83	user_CaRof4	3		11	17
257	2019-09-03 01:34:37.642166+00	51	user_RoGum6	3		11	17
258	2019-09-03 01:34:37.642707+00	41	user_OmLam1	3		11	17
259	2019-09-03 01:34:37.643231+00	39	user_CaRof8	3		11	17
260	2019-09-03 01:34:37.643776+00	38	user_JuPem6	3		11	17
261	2019-09-03 01:34:37.644293+00	37	pepitoperez123	3		11	17
262	2019-09-10 13:57:24.406089+00	237	Patient: juan alejandro visited Doctor: ducode. for: first	3		12	1
263	2019-09-10 13:57:42.419774+00	236	Patient: Djsksk visited Doctor: 456holauser. for: first	3		12	1
264	2019-09-10 13:57:59.108021+00	238	Patient: juan alejandro visited Doctor: ducode. for: first	3		12	1
265	2019-09-10 13:57:59.108919+00	235	Patient: pepe visited Doctor: 123456. for: first	3		12	1
266	2019-09-10 13:57:59.109451+00	234	Patient: Marta visited Doctor: 456holauser. for: first	3		12	1
267	2019-09-10 13:57:59.109996+00	233	Patient: Pedro visited Doctor: 456holauser. for: first	3		12	1
268	2019-09-10 13:57:59.110553+00	232	Patient: dalma visited Doctor: 123456. for: follow-up	3		12	1
269	2019-09-10 13:57:59.111117+00	231	Patient: dalma visited Doctor: 123456. for: first	3		12	1
270	2019-09-10 13:57:59.111619+00	230	Patient: carlos visited Doctor: 123456. for: follow-up	3		12	1
271	2019-09-10 13:57:59.112167+00	229	Patient: carlos visited Doctor: 123456. for: follow-up	3		12	1
272	2019-09-10 13:57:59.112687+00	228	Patient: carlos visited Doctor: 123456. for: follow-up	3		12	1
273	2019-09-10 13:57:59.113235+00	227	Patient: carlos visited Doctor: 123456. for: first	3		12	1
274	2019-09-10 13:57:59.113751+00	226	Patient: Ming visited Doctor: 456holauser. for: first	3		12	1
275	2019-09-10 13:57:59.114304+00	225	Patient: Yanina visited Doctor: 456holauser. for: follow-up	3		12	1
276	2019-09-10 13:57:59.114839+00	224	Patient: Yanina visited Doctor: 456holauser. for: first	3		12	1
277	2019-09-10 13:57:59.11537+00	223	Patient: Mariano visited Doctor: 456holauser. for: follow-up	3		12	1
278	2019-09-10 13:57:59.115895+00	222	Patient: diego visited Doctor: 123456. for: follow-up	3		12	1
279	2019-09-10 13:57:59.116426+00	221	Patient: diego visited Doctor: 123456. for: first	3		12	1
280	2019-09-10 13:57:59.116954+00	220	Patient: Mariano visited Doctor: 456holauser. for: first	3		12	1
281	2019-09-10 13:57:59.117508+00	219	Patient: pedro visited Doctor: 123456. for: follow-up	3		12	1
282	2019-09-10 13:57:59.118079+00	218	Patient: Cristina visited Doctor: 456holauser. for: first	3		12	1
283	2019-09-10 13:57:59.11862+00	217	Patient: pedro visited Doctor: 123456. for: first	3		12	1
284	2019-09-10 13:57:59.119162+00	216	Patient: wsx visited Doctor: 123456. for: follow-up	3		12	1
285	2019-09-10 13:57:59.119734+00	215	Patient: Beta visited Doctor: 123456. for: follow-up	3		12	1
286	2019-09-10 13:57:59.120289+00	214	Patient: pablo visited Doctor: 123456. for: follow-up	3		12	1
287	2019-09-10 13:57:59.120819+00	213	Patient: Kao visited Doctor: 123456. for: follow-up	3		12	1
288	2019-09-10 13:57:59.121369+00	212	Patient: Gaston visited Doctor: 123456. for: follow-up	3		12	1
289	2019-09-10 13:57:59.121933+00	211	Patient: Elsa visited Doctor: 123456. for: follow-up	3		12	1
290	2019-09-10 13:57:59.122502+00	210	Patient: juan visited Doctor: 123456. for: follow-up	3		12	1
291	2019-09-10 13:57:59.123061+00	209	Patient: juan visited Doctor: 123456. for: follow-up	3		12	1
292	2019-09-10 13:57:59.123579+00	208	Patient: Maria visited Doctor: 123456. for: follow-up	3		12	1
293	2019-09-10 13:57:59.124377+00	207	Patient: Flor visited Doctor: 123456. for: first	3		12	1
294	2019-09-10 13:57:59.125013+00	206	Patient: julio visited Doctor: 123456. for: follow-up	3		12	1
295	2019-09-10 13:57:59.125541+00	205	Patient: julio visited Doctor: 123456. for: first	3		12	1
296	2019-09-10 13:57:59.12614+00	204	Patient: qaz visited Doctor: 123456. for: follow-up	3		12	1
297	2019-09-10 13:57:59.126694+00	203	Patient: Ale visited Doctor: 123456. for: follow-up	3		12	1
298	2019-09-10 13:57:59.127243+00	202	Patient: Ale visited Doctor: 123456. for: follow-up	3		12	1
299	2019-09-10 13:57:59.127819+00	201	Patient: juan visited Doctor: 100667. for: first	3		12	1
300	2019-09-10 13:57:59.128354+00	200	Patient: Ale visited Doctor: 123456. for: follow-up	3		12	1
301	2019-09-10 13:57:59.128926+00	199	Patient: Dksksk visited Doctor: 456holauser. for: follow-up	3		12	1
302	2019-09-10 13:57:59.129456+00	198	Patient: Dksksk visited Doctor: 456holauser. for: follow-up	3		12	1
303	2019-09-10 13:57:59.130008+00	197	Patient: Pepe visited Doctor: 456holauser. for: first	3		12	1
304	2019-09-10 13:57:59.13069+00	196	Patient: Ana visited Doctor: 456holauser. for: follow-up	3		12	1
305	2019-09-10 13:57:59.131248+00	195	Patient: Ana visited Doctor: 456holauser. for: follow-up	3		12	1
306	2019-09-10 13:57:59.131817+00	194	Patient: Ana visited Doctor: 456holauser. for: follow-up	3		12	1
307	2019-09-10 13:57:59.132368+00	193	Patient: Ana visited Doctor: 456holauser. for: follow-up	3		12	1
308	2019-09-10 13:57:59.132959+00	192	Patient: Ana visited Doctor: 456holauser. for: first	3		12	1
309	2019-09-10 13:57:59.133519+00	191	Patient: Dksksk visited Doctor: 456holauser. for: follow-up	3		12	1
310	2019-09-10 13:57:59.134096+00	190	Patient: Dksksk visited Doctor: 456holauser. for: follow-up	3		12	1
311	2019-09-10 13:57:59.134666+00	189	Patient: hfghfj visited Doctor: 456holauser. for: follow-up	3		12	1
312	2019-09-10 13:57:59.135229+00	188	Patient: Dksksk visited Doctor: 456holauser. for: first	3		12	1
313	2019-09-10 13:57:59.13576+00	187	Patient: hfghfj visited Doctor: 456holauser. for: follow-up	3		12	1
314	2019-09-10 13:57:59.136312+00	186	Patient: hfghfj visited Doctor: 456holauser. for: follow-up	3		12	1
315	2019-09-10 13:57:59.136875+00	185	Patient: hfghfj visited Doctor: 456holauser. for: follow-up	3		12	1
316	2019-09-10 13:57:59.137436+00	184	Patient: hfghfj visited Doctor: 456holauser. for: first	3		12	1
317	2019-09-10 13:57:59.137995+00	183	Patient: wsx visited Doctor: 123456. for: follow-up	3		12	1
318	2019-09-10 13:57:59.138562+00	182	Patient: wsx visited Doctor: 123456. for: follow-up	3		12	1
319	2019-09-10 13:57:59.139112+00	181	Patient: Noel visited Doctor: 123456. for: first	3		12	1
320	2019-09-10 13:57:59.139628+00	180	Patient: Maria visited Doctor: 123456. for: first	3		12	1
321	2019-09-10 13:57:59.140308+00	179	Patient: Lio visited Doctor: 123456. for: first	3		12	1
322	2019-09-10 13:57:59.140864+00	178	Patient: Kao visited Doctor: 123456. for: first	3		12	1
323	2019-09-10 13:57:59.141407+00	177	Patient: Elsa visited Doctor: 123456. for: follow-up	3		12	1
324	2019-09-10 13:57:59.142015+00	176	Patient: Hugo visited Doctor: 123456. for: follow-up	3		12	1
325	2019-09-10 13:57:59.142597+00	175	Patient: Igor visited Doctor: 123456. for: first	3		12	1
326	2019-09-10 13:57:59.143166+00	174	Patient: Hugo visited Doctor: 123456. for: first	3		12	1
327	2019-09-10 13:57:59.14369+00	173	Patient: juan visited Doctor: 123456. for: follow-up	3		12	1
328	2019-09-10 13:57:59.144268+00	172	Patient: juan visited Doctor: 123456. for: follow-up	3		12	1
329	2019-09-10 13:57:59.144853+00	171	Patient: juan visited Doctor: 123456. for: follow-up	3		12	1
330	2019-09-10 13:57:59.145397+00	170	Patient: juan visited Doctor: 123456. for: follow-up	3		12	1
331	2019-09-10 13:57:59.145961+00	169	Patient: juan visited Doctor: 123456. for: follow-up	3		12	1
332	2019-09-10 13:57:59.146501+00	168	Patient: juan visited Doctor: 123456. for: first	3		12	1
333	2019-09-10 13:57:59.147028+00	167	Patient: diego visited Doctor: 123456. for: first	3		12	1
334	2019-09-10 13:57:59.14759+00	166	Patient: Pedro visited Doctor: 456holauser. for: first	3		12	1
335	2019-09-10 13:57:59.148178+00	165	Patient: Pablo visited Doctor: 456holauser. for: follow-up	3		12	1
336	2019-09-10 13:57:59.148743+00	164	Patient: Pablo visited Doctor: 456holauser. for: follow-up	3		12	1
337	2019-09-10 13:57:59.149294+00	163	Patient: Jah visited Doctor: 123456. for: first	3		12	1
338	2019-09-10 13:57:59.149865+00	162	Patient: Pablo visited Doctor: 456holauser. for: follow-up	3		12	1
339	2019-09-10 13:57:59.150397+00	161	Patient: Pablo visited Doctor: 456holauser. for: first	3		12	1
340	2019-09-10 13:57:59.150944+00	160	Patient: Catalina visited Doctor: 456holauser. for: follow-up	3		12	1
341	2019-09-10 13:57:59.151503+00	159	Patient: Lorena visited Doctor: 456holauser. for: first	3		12	1
342	2019-09-10 13:57:59.152073+00	158	Patient: Susana visited Doctor: 123holauser. for: follow-up	3		12	1
343	2019-09-10 13:57:59.152601+00	157	Patient: KdskalDjskaka visited Doctor: 123holauser. for: follow-up	3		12	1
344	2019-09-10 13:57:59.153168+00	156	Patient: KdskalDjskaka visited Doctor: 123holauser. for: follow-up	3		12	1
345	2019-09-10 13:57:59.153697+00	155	Patient: KdskalDjskaka visited Doctor: 123holauser. for: follow-up	3		12	1
346	2019-09-10 13:57:59.154281+00	154	Patient: Susana visited Doctor: 123holauser. for: first	3		12	1
347	2019-09-10 13:57:59.154797+00	153	Patient: Pepe visited Doctor: 123456. for: follow-up	3		12	1
348	2019-09-10 13:57:59.155362+00	152	Patient: Catalina visited Doctor: 456holauser. for: follow-up	3		12	1
349	2019-09-10 13:57:59.155953+00	151	Patient: Catalina visited Doctor: 456holauser. for: follow-up	3		12	1
350	2019-09-10 13:57:59.156512+00	150	Patient: Catalina visited Doctor: 456holauser. for: follow-up	3		12	1
351	2019-09-10 13:57:59.157085+00	149	Patient: Catalina visited Doctor: 456holauser. for: first	3		12	1
352	2019-09-10 13:57:59.157657+00	148	Patient: pablo visited Doctor: 123456. for: follow-up	3		12	1
353	2019-09-10 13:57:59.158271+00	147	Patient: Ale visited Doctor: 123456. for: follow-up	3		12	1
354	2019-09-10 13:57:59.158828+00	146	Patient: Ale visited Doctor: 123456. for: first	3		12	1
355	2019-09-10 13:57:59.15937+00	145	Patient: Pepe visited Doctor: 123456. for: first	3		12	1
356	2019-09-10 13:57:59.159948+00	144	Patient: Ale visited Doctor: 123456. for: follow-up	3		12	1
357	2019-09-10 13:57:59.1605+00	143	Patient: Didi6d6i visited Doctor: 123holauser. for: first	3		12	1
358	2019-09-10 13:57:59.16105+00	142	Patient: Fkditdiydiy visited Doctor: 123holauser. for: first	3		12	1
359	2019-09-10 13:57:59.161599+00	141	Patient: marta visited Doctor: 100000. for: follow-up	3		12	1
360	2019-09-10 13:57:59.162206+00	140	Patient: Ale visited Doctor: 123456. for: follow-up	3		12	1
361	2019-09-10 13:57:59.162775+00	139	Patient: Djsksnj visited Doctor: 123holauser. for: first	3		12	1
362	2019-09-10 13:57:59.163337+00	138	Patient: Dlufiydi6 visited Doctor: 123holauser. for: first	3		12	1
363	2019-09-10 13:57:59.163879+00	137	Patient: ana visited Doctor: 123456. for: follow-up	3		12	1
364	2019-09-10 13:58:07.712844+00	136	Patient: ana visited Doctor: 123456. for: follow-up	3		12	1
365	2019-09-10 13:58:07.713847+00	135	Patient: Gaston visited Doctor: 123456. for: first	3		12	1
366	2019-09-10 13:58:07.714426+00	134	Patient: Carlos visited Doctor: 123456. for: follow-up	3		12	1
367	2019-09-10 13:58:07.71498+00	133	Patient: Carlos visited Doctor: 123456. for: follow-up	3		12	1
368	2019-09-10 13:58:07.715563+00	132	Patient: Elsa visited Doctor: 123456. for: first	3		12	1
369	2019-09-10 13:58:07.716124+00	131	Patient: dora visited Doctor: 123456. for: first	3		12	1
370	2019-09-10 13:58:07.716656+00	130	Patient: Cata visited Doctor: 123456. for: first	3		12	1
371	2019-09-10 13:58:07.717243+00	129	Patient: Beta visited Doctor: 123456. for: first	3		12	1
372	2019-09-10 13:58:07.717841+00	128	Patient: Nuevo visited Doctor: 123holauser. for: first	3		12	1
373	2019-09-10 13:58:07.718449+00	127	Patient: ana visited Doctor: 123456. for: first	3		12	1
374	2019-09-10 13:58:07.719009+00	126	Patient: Ana visited Doctor: 123456. for: follow-up	3		12	1
375	2019-09-10 13:58:07.719561+00	125	Patient: Ana visited Doctor: 123456. for: first	3		12	1
376	2019-09-10 13:58:07.720138+00	124	Patient: marta visited Doctor: 100000. for: first	3		12	1
377	2019-09-10 13:58:07.720692+00	123	Patient: juan visited Doctor: 100000. for: follow-up	3		12	1
378	2019-09-10 13:58:07.721258+00	122	Patient: juan visited Doctor: 100000. for: first	3		12	1
379	2019-09-10 13:58:07.721836+00	121	Patient: Juan visited Doctor: 123456. for: follow-up	3		12	1
380	2019-09-10 13:58:07.722385+00	120	Patient: juan visited Doctor: 123456. for: follow-up	3		12	1
381	2019-09-10 13:58:07.722932+00	119	Patient: Andres visited Doctor: 123holauser. for: follow-up	3		12	1
382	2019-09-10 13:58:07.723474+00	118	Patient: Andres visited Doctor: 123holauser. for: first	3		12	1
383	2019-09-10 13:58:07.724017+00	117	Patient: pablo visited Doctor: 123456. for: follow-up	3		12	1
384	2019-09-10 13:58:07.7246+00	116	Patient: pablo visited Doctor: 123456. for: follow-up	3		12	1
385	2019-09-10 13:58:07.725178+00	115	Patient: pablo visited Doctor: 123456. for: follow-up	3		12	1
386	2019-09-10 13:58:07.725699+00	114	Patient: pablo visited Doctor: 123456. for: follow-up	3		12	1
387	2019-09-10 13:58:07.726286+00	113	Patient: pablo visited Doctor: 123456. for: first	3		12	1
388	2019-09-10 13:58:07.726831+00	112	Patient: Paula visited Doctor: 123holauser. for: follow-up	3		12	1
389	2019-09-10 13:58:07.72739+00	111	Patient: Carlos visited Doctor: 123456. for: follow-up	3		12	1
390	2019-09-10 13:58:07.727947+00	110	Patient: diego visited Doctor: 123456. for: follow-up	3		12	1
391	2019-09-10 13:58:07.728506+00	109	Patient: juan visited Doctor: 123456. for: follow-up	3		12	1
392	2019-09-10 13:58:07.729036+00	108	Patient: Carlos visited Doctor: 123456. for: first	3		12	1
393	2019-09-10 13:58:07.729604+00	107	Patient: juan visited Doctor: 123456. for: first	3		12	1
394	2019-09-10 13:58:07.730198+00	106	Patient: julian visited Doctor: 123456. for: first	3		12	1
395	2019-09-10 13:58:07.730738+00	105	Patient: diego visited Doctor: 123456. for: first	3		12	1
396	2019-09-10 13:58:07.731303+00	104	Patient: laura visited Doctor: 123456. for: follow-up	3		12	1
397	2019-09-10 13:58:07.731868+00	103	Patient: laura visited Doctor: 123456. for: follow-up	3		12	1
398	2019-09-10 13:58:07.732437+00	102	Patient: laura visited Doctor: 123456. for: first	3		12	1
399	2019-09-10 13:58:07.732961+00	101	Patient: KdskalDjskaka visited Doctor: 123holauser. for: follow-up	3		12	1
400	2019-09-10 13:58:07.733506+00	100	Patient: KdskalDjskaka visited Doctor: 123holauser. for: follow-up	3		12	1
401	2019-09-10 13:58:07.734106+00	99	Patient: Paula visited Doctor: 123holauser. for: first	3		12	1
402	2019-09-10 13:58:07.734671+00	98	Patient: Juan visited Doctor: 123456. for: first	3		12	1
403	2019-09-10 13:58:07.735263+00	97	Patient: Pedro visited Doctor: 123holauser. for: first	3		12	1
404	2019-09-10 13:58:07.735817+00	96	Patient: juan visited Doctor: 123456. for: first	3		12	1
405	2019-09-10 13:58:07.736392+00	95	Patient: juan visited Doctor: 123456. for: first	3		12	1
406	2019-09-10 13:58:07.73696+00	94	Patient: Ale visited Doctor: 123456. for: follow-up	3		12	1
407	2019-09-10 13:58:07.73753+00	93	Patient: Ale visited Doctor: 123456. for: follow-up	3		12	1
408	2019-09-10 13:58:07.738122+00	92	Patient: ana visited Doctor: 123456. for: follow-up	3		12	1
409	2019-09-10 13:58:07.738694+00	91	Patient: Cata visited Doctor: 123holauser. for: first	3		12	1
410	2019-09-10 13:58:07.739276+00	90	Patient: wsx visited Doctor: 123456. for: follow-up	3		12	1
411	2019-09-10 13:58:07.739988+00	89	Patient: wsx visited Doctor: 123456. for: follow-up	3		12	1
412	2019-09-10 13:58:07.740685+00	88	Patient: wsx visited Doctor: 123456. for: first	3		12	1
413	2019-09-10 13:58:07.741294+00	87	Patient: KdskalDjskaka visited Doctor: 123holauser. for: follow-up	3		12	1
414	2019-09-10 13:58:07.74189+00	86	Patient: KdskalDjskaka visited Doctor: 123holauser. for: first	3		12	1
415	2019-09-10 13:58:07.742464+00	85	Patient: Ale visited Doctor: 123holauser. for: follow-up	3		12	1
416	2019-09-10 13:58:07.74303+00	84	Patient: qaz visited Doctor: 123456. for: follow-up	3		12	1
417	2019-09-10 13:58:07.743587+00	83	Patient: ana visited Doctor: 123456. for: first	3		12	1
418	2019-09-10 13:58:07.744146+00	82	Patient: Ale visited Doctor: 123holauser. for: follow-up	3		12	1
419	2019-09-10 13:58:07.744725+00	81	Patient: Ale visited Doctor: 123holauser. for: first	3		12	1
420	2019-09-10 13:58:07.745307+00	80	Patient: ariel visited Doctor: 123456. for: follow-up	3		12	1
421	2019-09-10 13:58:07.745881+00	79	Patient: ariel visited Doctor: 123456. for: first	3		12	1
422	2019-09-10 13:58:07.746462+00	78	Patient: qaz visited Doctor: 123456. for: first	3		12	1
423	2019-09-10 13:58:07.747034+00	77	Patient: Patricia visited Doctor: 123holauser. for: follow-up	3		12	1
424	2019-09-10 13:58:07.747594+00	76	Patient: Patricia visited Doctor: 123holauser. for: first	3		12	1
425	2019-09-10 13:58:07.748145+00	75	Patient: Ale visited Doctor: 123456. for: first	3		12	1
426	2019-09-10 13:58:19.717375+00	239	Patient: juan alejandro visited Doctor: ducode. for: first	3		12	1
427	2019-09-10 14:00:11.463264+00	269	user_HrDjf1	3		11	1
428	2019-09-10 14:00:11.46418+00	268	user_judum9	3		11	1
429	2019-09-10 14:00:11.464716+00	267	user_DjDjm7	3		11	1
430	2019-09-10 14:00:11.465267+00	266	user_pelum1	3		11	1
431	2019-09-10 14:00:11.465857+00	265	user_UfFhm2	3		11	1
432	2019-09-10 14:00:11.466345+00	264	user_MaSaf8	3		11	1
433	2019-09-10 14:00:11.46688+00	263	user_PeSam8	3		11	1
434	2019-09-10 14:00:11.467368+00	262	user_dapef4	3		11	1
435	2019-09-10 14:00:11.46792+00	261	user_capem4	3		11	1
436	2019-09-10 14:00:11.468426+00	260	user_MiKaf7	3		11	1
437	2019-09-10 14:00:11.468967+00	259	user_YaLaf3	3		11	1
438	2019-09-10 14:00:11.46955+00	258	user_digom6	3		11	1
439	2019-09-10 14:00:11.470144+00	257	user_MaMam6	3		11	1
440	2019-09-10 14:00:11.470691+00	256	user_CrSuf7	3		11	1
441	2019-09-10 14:00:11.471564+00	255	user_pelom5	3		11	1
442	2019-09-10 14:00:11.472128+00	254	user_judim3	3		11	1
443	2019-09-10 14:00:11.472654+00	253	user_jupem8	3		11	1
444	2019-09-10 14:00:11.473223+00	251	user_PeArm5	3		11	1
445	2019-09-10 14:00:11.4738+00	250	user_AnPem2	3		11	1
446	2019-09-10 14:00:11.474347+00	249	user_DkJdm1	3		11	1
447	2019-09-10 14:00:11.474897+00	248	user_NoPim4	3		11	1
448	2019-09-10 14:00:11.475436+00	247	user_MaPif8	3		11	1
449	2019-09-10 14:00:11.476+00	246	user_LiPim2	3		11	1
450	2019-09-10 14:00:11.476599+00	245	user_KaPim8	3		11	1
451	2019-09-10 14:00:11.477135+00	244	user_IgPim4	3		11	1
452	2019-09-10 14:00:11.477667+00	243	user_HuPim1	3		11	1
453	2019-09-10 14:00:11.478209+00	242	user_jugam9	3		11	1
454	2019-09-10 14:00:11.478751+00	241	user_digam8	3		11	1
455	2019-09-10 14:00:11.479317+00	240	user_hfjgf8	3		11	1
456	2019-09-10 14:00:11.4799+00	239	user_PeBem1	3		11	1
457	2019-09-10 14:00:11.480448+00	238	user_JaLem5	3		11	1
458	2019-09-10 14:00:11.481028+00	237	user_PaZim5	3		11	1
459	2019-09-10 14:00:11.481559+00	236	user_LoPif9	3		11	1
460	2019-09-10 14:00:11.482125+00	235	user_PaRam5	3		11	1
461	2019-09-10 14:00:11.482629+00	234	user_LuFem4	3		11	1
462	2019-09-10 14:00:11.483156+00	233	user_PrPam1	3		11	1
463	2019-09-10 14:00:11.483669+00	232	user_DiKgm4	3		11	1
464	2019-09-10 14:00:11.484207+00	231	user_JgXkm1	3		11	1
465	2019-09-10 14:00:11.484728+00	230	user_PeBem8	3		11	1
466	2019-09-10 14:00:11.48523+00	229	user_JuPrm8	3		11	1
467	2019-09-10 14:00:11.485788+00	228	user_NoApm4	3		11	1
468	2019-09-10 14:00:11.4863+00	227	user_YuHff3	3		11	1
469	2019-09-10 14:00:11.486845+00	226	user_DuTdf3	3		11	1
470	2019-09-10 14:00:11.487333+00	225	user_ElPem4	3		11	1
471	2019-09-10 14:00:11.487883+00	224	user_UoXkf3	3		11	1
472	2019-09-10 14:00:11.488364+00	223	user_KyJzf3	3		11	1
473	2019-09-10 14:00:11.488894+00	222	user_FuHff6	3		11	1
474	2019-09-10 14:00:11.489444+00	221	user_DoUtf7	3		11	1
475	2019-09-10 14:00:11.490032+00	220	user_CrMam7	3		11	1
476	2019-09-10 14:00:11.490553+00	219	user_FrMem6	3		11	1
477	2019-09-10 14:00:11.49109+00	218	user_CaPif9	3		11	1
478	2019-09-10 14:00:11.491633+00	217	user_AlAlm5	3		11	1
479	2019-09-10 14:00:11.492174+00	216	user_PePim9	3		11	1
480	2019-09-10 14:00:11.492747+00	215	user_DiKhf9	3		11	1
481	2019-09-10 14:00:11.493265+00	214	user_FkDkm7	3		11	1
482	2019-09-10 14:00:11.493899+00	213	user_SuGif6	3		11	1
483	2019-09-10 14:00:11.494445+00	212	user_DlZkf7	3		11	1
484	2019-09-10 14:00:11.495009+00	211	user_DjJkm1	3		11	1
485	2019-09-10 14:00:11.495585+00	210	user_GaPim6	3		11	1
486	2019-09-10 14:00:11.496123+00	209	user_FlPif8	3		11	1
487	2019-09-10 14:00:11.496649+00	208	user_ElPif6	3		11	1
488	2019-09-10 14:00:11.49724+00	207	user_dopif1	3		11	1
489	2019-09-10 14:00:11.497835+00	206	user_CaPif3	3		11	1
490	2019-09-10 14:00:11.498402+00	205	user_BePif3	3		11	1
491	2019-09-10 14:00:11.498938+00	204	user_NuPam3	3		11	1
492	2019-09-10 14:00:11.499508+00	203	user_ansaf2	3		11	1
493	2019-09-10 14:00:11.500066+00	202	user_AnPim8	3		11	1
494	2019-09-10 14:00:11.500641+00	201	user_magof4	3		11	1
495	2019-09-10 14:00:11.501176+00	199	user_jupem7	3		11	1
496	2019-09-10 14:00:11.501847+00	196	user_AnRom6	3		11	1
497	2019-09-10 14:00:11.502433+00	195	user_pamam2	3		11	1
498	2019-09-10 14:00:11.503005+00	194	user_Cagom2	3		11	1
499	2019-09-10 14:00:11.503556+00	193	user_jupem1	3		11	1
500	2019-09-10 14:00:11.504092+00	192	user_judim4	3		11	1
501	2019-09-10 14:00:11.504654+00	191	user_digom7	3		11	1
502	2019-09-10 14:00:11.505231+00	190	user_lagof6	3		11	1
503	2019-09-10 14:00:11.50581+00	189	user_PaChf3	3		11	1
504	2019-09-10 14:00:11.506383+00	188	user_Julom8	3		11	1
505	2019-09-10 14:00:11.506917+00	187	user_PeBem6	3		11	1
506	2019-09-10 14:00:11.507449+00	186	user_jupem3	3		11	1
507	2019-09-10 14:00:11.50801+00	185	user_jupem6	3		11	1
508	2019-09-10 14:00:11.508572+00	184	user_CaPif7	3		11	1
509	2019-09-10 14:00:11.509119+00	183	user_DiLhf2	3		11	1
510	2019-09-10 14:00:11.509659+00	182	user_wsedm9	3		11	1
511	2019-09-10 14:00:11.510215+00	181	user_KdJdm8	3		11	1
512	2019-09-10 14:00:11.510784+00	180	user_anruf7	3		11	1
513	2019-09-10 14:00:11.511322+00	179	user_AlBaf7	3		11	1
514	2019-09-10 14:00:11.511862+00	178	user_argom5	3		11	1
515	2019-09-10 14:00:11.512395+00	177	user_qaqam3	3		11	1
516	2019-09-10 14:00:11.51293+00	176	user_PaGrf9	3		11	1
517	2019-09-10 14:00:11.513483+00	174	user_AlLom6	3		11	1
518	2019-09-11 22:42:12.068751+00	292	Patient: usuario visited Doctor: 570119. for: follow-up	3		12	1
519	2019-09-11 22:42:12.080878+00	291	Patient: usuario visited Doctor: 570119. for: first	3		12	1
520	2019-09-11 22:42:12.081602+00	290	Patient: Usuario 1 visited Doctor: 570119. for: first	3		12	1
521	2019-09-11 22:42:12.082264+00	289	Patient: Ming visited Doctor: 570119. for: follow-up	3		12	1
522	2019-09-11 22:42:12.082924+00	288	Patient: Pablo visited Doctor: 570119. for: first	3		12	1
523	2019-09-11 22:42:12.083607+00	287	Patient: Ming visited Doctor: 570119. for: first	3		12	1
524	2019-09-11 22:42:12.084267+00	286	Patient: Cata visited Doctor: 065940940. for: first	3		12	1
525	2019-09-11 22:42:12.0849+00	285	Patient: Ghhjk visited Doctor: 065940940. for: first	3		12	1
526	2019-09-11 22:42:12.085474+00	284	Patient: Juan visited Doctor: 456holauser. for: follow-up	3		12	1
527	2019-09-11 22:42:12.086131+00	283	Patient: Juan visited Doctor: 456holauser. for: first	3		12	1
528	2019-09-11 22:42:12.087378+00	282	Patient: Ricardo visited Doctor: 456holauser. for: follow-up	3		12	1
529	2019-09-11 22:42:12.088011+00	281	Patient: Ricardo visited Doctor: 456holauser. for: follow-up	3		12	1
530	2019-09-11 22:42:12.088672+00	280	Patient: Ricardo visited Doctor: 456holauser. for: first	3		12	1
531	2019-09-11 22:42:12.089414+00	279	Patient: Juan visited Doctor: 123456. for: first	3		12	1
532	2019-09-11 22:42:12.090093+00	278	Patient: Roberto visited Doctor: 456holauser. for: first	3		12	1
533	2019-09-11 22:42:12.090696+00	245	Patient: Ming visited Doctor: 456holauser. for: follow-up	3		12	1
534	2019-09-11 22:42:12.091322+00	244	Patient: Juan visited Doctor: 456holauser. for: first	3		12	1
535	2019-09-11 22:42:12.091965+00	243	Patient: Ming visited Doctor: 456holauser. for: first	3		12	1
536	2019-09-11 22:42:12.09262+00	242	Patient: Cata visited Doctor: 456holauser. for: follow-up	3		12	1
537	2019-09-11 22:42:12.093274+00	241	Patient: Cata visited Doctor: 456holauser. for: first	3		12	1
538	2019-09-11 22:42:21.902046+00	283	user_usapm6	3		11	1
539	2019-09-11 22:42:21.903356+00	282	user_UsApm7	3		11	1
540	2019-09-11 22:42:21.904067+00	281	user_PaRom1	3		11	1
541	2019-09-11 22:42:21.904693+00	280	user_MiKam6	3		11	1
542	2019-09-11 22:42:21.905376+00	279	user_CaPif6	3		11	1
543	2019-09-11 22:42:21.906084+00	278	user_GhXum9	3		11	1
544	2019-09-11 22:42:21.906913+00	277	user_GhXum2	3		11	1
545	2019-09-11 22:42:21.90751+00	276	user_JuFem1	3		11	1
546	2019-09-11 22:42:21.908144+00	275	user_RiGam5	3		11	1
547	2019-09-11 22:42:21.908796+00	274	user_JuPem3	3		11	1
548	2019-09-11 22:42:21.909433+00	273	user_RoLum7	3		11	1
549	2019-09-11 22:42:21.910125+00	272	user_JuPem8	3		11	1
550	2019-09-11 22:42:21.910749+00	271	user_MiKam7	3		11	1
551	2019-09-11 22:42:21.911403+00	270	user_CaPif8	3		11	1
552	2019-09-11 22:51:14.068624+00	294	Patient: alexis visited Doctor: 570119. for: follow-up	3		12	1
553	2019-09-11 22:59:58.496707+00	295	Patient: alexis visited Doctor: 570119. for: follow-up	3		12	1
586	2019-09-13 15:30:45.418633+00	27	101010101010	3		7	1
587	2019-09-13 15:33:12.583153+00	13	13698987901	3		7	1
588	2019-09-13 15:33:12.584002+00	14	789456	3		7	1
589	2019-09-13 15:33:12.584652+00	25	alejoad23	3		7	1
590	2019-09-27 22:20:42.340575+00	17	florencia.rolandi@gmail.com	2	[{"changed": {"fields": ["password"]}}]	7	1
591	2019-09-27 22:22:12.180339+00	17	florencia.rolandi@gmail.com	2	[{"changed": {"fields": ["password"]}}]	7	17
592	2019-10-14 15:00:37.388324+00	169	12345	3		7	1
593	2019-10-14 15:18:42.293631+00	170	00000	3		7	1
594	2019-10-14 15:18:42.29456+00	171	00001	3		7	1
595	2019-10-14 21:03:53.607244+00	173	00001	3		7	1
596	2019-10-14 21:03:53.608186+00	172	12315187238	3		7	1
597	2019-10-14 21:03:53.608993+00	174	59950455704	3		7	1
598	2019-10-14 21:10:33.148173+00	176	12345	3		7	1
599	2019-10-14 21:10:33.149074+00	175	24562736555	3		7	1
600	2019-10-14 21:14:01.924626+00	177	12345	3		7	1
601	2019-10-14 21:14:36.122066+00	10	123456	2	[{"changed": {"fields": ["is_staff"]}}]	7	1
602	2019-10-14 21:33:30.629405+00	178	12457	3		7	1
603	2019-10-14 21:33:30.630252+00	179	14725	3		7	1
604	2019-10-14 21:58:08.893947+00	182	018830	3		7	1
605	2019-10-14 21:58:08.894842+00	183	099963	3		7	1
606	2019-10-14 21:58:08.895518+00	181	14725	3		7	1
607	2019-10-14 21:58:08.896172+00	180	15960	3		7	1
608	2019-10-14 22:51:42.110289+00	185	014728	3		7	1
609	2019-10-14 22:51:42.111148+00	186	1472	3		7	1
610	2019-10-14 22:51:42.111801+00	184	26424105087	3		7	1
611	2019-10-14 22:52:49.380731+00	26	034648468	3		7	1
612	2019-10-14 22:52:49.38165+00	21	0650546	3		7	1
613	2019-10-14 22:52:49.382303+00	22	065940940	3		7	1
614	2019-10-14 22:52:49.382934+00	6	123holauser	3		7	1
615	2019-10-14 22:52:49.383572+00	24	4386784676	3		7	1
616	2019-10-14 22:52:49.384237+00	11	456holauser	3		7	1
617	2019-10-14 22:52:49.384881+00	20	5867348401076	3		7	1
618	2019-10-14 22:53:34.324886+00	187	7817049796	3		7	1
619	2019-10-14 23:17:25.665056+00	188	81313900928	3		7	1
620	2019-10-14 23:18:16.194297+00	190	18172636253	3		7	1
621	2019-10-28 16:00:32.862752+00	29	100000000000	3		7	17
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	auth	permission
2	auth	group
3	contenttypes	contenttype
4	sessions	session
5	admin	logentry
6	authtoken	token
7	users	user
8	users	registrationtype
9	users	speciality
10	users	profile
11	patients	patient
12	visits	visit
34	visits	followupvisitcomplementinformation
35	visits	firstvisitcomplementinformation
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2019-08-31 04:36:53.944256+00
2	contenttypes	0002_remove_content_type_name	2019-08-31 04:36:53.969608+00
3	auth	0001_initial	2019-08-31 04:36:54.035699+00
4	auth	0002_alter_permission_name_max_length	2019-08-31 04:36:54.107495+00
5	auth	0003_alter_user_email_max_length	2019-08-31 04:36:54.115018+00
6	auth	0004_alter_user_username_opts	2019-08-31 04:36:54.122132+00
7	auth	0005_alter_user_last_login_null	2019-08-31 04:36:54.129048+00
8	auth	0006_require_contenttypes_0002	2019-08-31 04:36:54.131407+00
9	auth	0007_alter_validators_add_error_messages	2019-08-31 04:36:54.138511+00
10	auth	0008_alter_user_username_max_length	2019-08-31 04:36:54.145331+00
11	auth	0009_alter_user_last_name_max_length	2019-08-31 04:36:54.152513+00
12	auth	0010_alter_group_name_max_length	2019-08-31 04:36:54.159676+00
13	auth	0011_update_proxy_permissions	2019-08-31 04:36:54.166765+00
14	users	0001_initial	2019-08-31 04:36:54.279871+00
15	admin	0001_initial	2019-08-31 04:36:54.459459+00
16	admin	0002_logentry_remove_auto_add	2019-08-31 04:36:54.499987+00
17	admin	0003_logentry_add_action_flag_choices	2019-08-31 04:36:54.512476+00
18	authtoken	0001_initial	2019-08-31 04:36:54.540082+00
19	authtoken	0002_auto_20160226_1747	2019-08-31 04:36:54.604344+00
20	patients	0001_initial	2019-08-31 04:36:54.623255+00
21	patients	0002_patient_doctor	2019-08-31 04:36:54.655943+00
22	sessions	0001_initial	2019-08-31 04:36:54.684438+00
23	visits	0001_initial	2019-08-31 04:36:54.733782+00
34	visits	0002_auto_20190901_0124	2019-09-01 02:18:22.75583+00
35	visits	0003_auto_20190901_0415	2019-09-01 04:24:07.088697+00
36	visits	0004_auto_20190902_0205	2019-09-02 02:59:07.835632+00
37	visits	0005_auto_20190902_0212	2019-09-02 02:59:07.900444+00
38	visits	0006_auto_20190902_0228	2019-09-02 02:59:07.920692+00
39	visits	0007_auto_20190904_2356	2019-09-05 01:57:14.692223+00
40	visits	0008_auto_20190929_0036	2019-09-29 00:40:49.051771+00
41	users	0002_auto_20191013_1847	2019-10-13 19:31:04.238609+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
guxth0zirvgfe5n1fcoltkgzsmqtjd3l	YWQ4MzJiZjcwYzYwYWZmN2RhNjJmMDgyMmQ2MDJhZDNhZTBjZjM0Yzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0Mjc2MzlhYWYzZGFlOTQ4MTNmYzUzMWUxOGM3YzQyY2JkNGNjMTg3In0=	2019-09-14 04:41:40.370909+00
y6e5l5qbof6ph4eo5p3o8diwd3ylic3u	YWQ4MzJiZjcwYzYwYWZmN2RhNjJmMDgyMmQ2MDJhZDNhZTBjZjM0Yzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0Mjc2MzlhYWYzZGFlOTQ4MTNmYzUzMWUxOGM3YzQyY2JkNGNjMTg3In0=	2019-09-14 06:53:52.163408+00
2dugz2wij70zg6medwhntrgfdcrpgf5t	YWQ4MzJiZjcwYzYwYWZmN2RhNjJmMDgyMmQ2MDJhZDNhZTBjZjM0Yzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0Mjc2MzlhYWYzZGFlOTQ4MTNmYzUzMWUxOGM3YzQyY2JkNGNjMTg3In0=	2019-09-14 16:07:38.843425+00
u0olr6pvk6pxmptl7tcsp5mybmfeln35	ZWNiMGNkZjVlODliMDlmZWEyOTM0MjMzMzE5YWM0YmNlNWM5MWJlNzp7Il9hdXRoX3VzZXJfaWQiOiIxNyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZTY4ZWZiZTZhMDkyZTk3ZmYxNDE5ODA3MTUzYmJkMWI3Njc0ZmQ1NyJ9	2019-09-15 22:12:12.458666+00
gmdtxu5nv2d66maenv8miaz8go2lpboy	ZWNiMGNkZjVlODliMDlmZWEyOTM0MjMzMzE5YWM0YmNlNWM5MWJlNzp7Il9hdXRoX3VzZXJfaWQiOiIxNyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZTY4ZWZiZTZhMDkyZTk3ZmYxNDE5ODA3MTUzYmJkMWI3Njc0ZmQ1NyJ9	2019-09-15 22:12:43.966362+00
btlx8y1hkb7x4rn1dd3s7cpw4161uqs3	YWQ4MzJiZjcwYzYwYWZmN2RhNjJmMDgyMmQ2MDJhZDNhZTBjZjM0Yzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0Mjc2MzlhYWYzZGFlOTQ4MTNmYzUzMWUxOGM3YzQyY2JkNGNjMTg3In0=	2019-09-17 02:10:53.413569+00
x4ivhm4dus48no7ar5ltpn0jlg0mksa0	YWQ4MzJiZjcwYzYwYWZmN2RhNjJmMDgyMmQ2MDJhZDNhZTBjZjM0Yzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0Mjc2MzlhYWYzZGFlOTQ4MTNmYzUzMWUxOGM3YzQyY2JkNGNjMTg3In0=	2019-09-24 13:55:06.907349+00
9k7yp930497sizzmn64iheuqgsvxm85m	YWQ4MzJiZjcwYzYwYWZmN2RhNjJmMDgyMmQ2MDJhZDNhZTBjZjM0Yzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0Mjc2MzlhYWYzZGFlOTQ4MTNmYzUzMWUxOGM3YzQyY2JkNGNjMTg3In0=	2019-09-24 19:20:30.004483+00
s0mviai1z0lehggjcogts6aio9jyg5vd	YWQ4MzJiZjcwYzYwYWZmN2RhNjJmMDgyMmQ2MDJhZDNhZTBjZjM0Yzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0Mjc2MzlhYWYzZGFlOTQ4MTNmYzUzMWUxOGM3YzQyY2JkNGNjMTg3In0=	2019-09-25 20:12:31.163985+00
4k07lhlork9lv4qz24wr8udz4ka6v08e	YWQ4MzJiZjcwYzYwYWZmN2RhNjJmMDgyMmQ2MDJhZDNhZTBjZjM0Yzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0Mjc2MzlhYWYzZGFlOTQ4MTNmYzUzMWUxOGM3YzQyY2JkNGNjMTg3In0=	2019-09-25 22:42:00.418497+00
p7bt27eaicqt15v0up0p8l9ffpbuohcu	YWQ4MzJiZjcwYzYwYWZmN2RhNjJmMDgyMmQ2MDJhZDNhZTBjZjM0Yzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0Mjc2MzlhYWYzZGFlOTQ4MTNmYzUzMWUxOGM3YzQyY2JkNGNjMTg3In0=	2019-09-27 01:07:20.89824+00
wfitgbars913l4apdstg3xqe9h02yu5f	YWQ4MzJiZjcwYzYwYWZmN2RhNjJmMDgyMmQ2MDJhZDNhZTBjZjM0Yzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0Mjc2MzlhYWYzZGFlOTQ4MTNmYzUzMWUxOGM3YzQyY2JkNGNjMTg3In0=	2019-10-11 22:18:04.859977+00
80dhwsjbdx66aifsq38od5chdeyjf6ke	MGQ5MDliZGFhYWE4M2U1NTllMmUyNWQwM2I2YWJjOGYzYmU1Mjk4NDp7Il9hdXRoX3VzZXJfaWQiOiIxNyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMzg3NDU1OWE4OTUyN2Q5NDkzMmQ0MTE5OTliYmRiZWYwNDg5YWZiZiJ9	2019-10-11 22:22:24.768008+00
nnmmdtmlbg8k6p4jghwz8cirt1247otc	YWQ4MzJiZjcwYzYwYWZmN2RhNjJmMDgyMmQ2MDJhZDNhZTBjZjM0Yzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0Mjc2MzlhYWYzZGFlOTQ4MTNmYzUzMWUxOGM3YzQyY2JkNGNjMTg3In0=	2019-10-27 18:42:28.18352+00
u3oef6516nhe0g8oknq8kaxldg56vzdu	YWQ4MzJiZjcwYzYwYWZmN2RhNjJmMDgyMmQ2MDJhZDNhZTBjZjM0Yzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0Mjc2MzlhYWYzZGFlOTQ4MTNmYzUzMWUxOGM3YzQyY2JkNGNjMTg3In0=	2019-10-28 13:53:52.784211+00
48psnxw4wmgvjqgjo420gv72i4kbdcjl	YWQ4MzJiZjcwYzYwYWZmN2RhNjJmMDgyMmQ2MDJhZDNhZTBjZjM0Yzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0Mjc2MzlhYWYzZGFlOTQ4MTNmYzUzMWUxOGM3YzQyY2JkNGNjMTg3In0=	2019-11-11 15:29:23.198626+00
s5wpeuepb4qcqms63ax5tzq4wem2493i	MGQ5MDliZGFhYWE4M2U1NTllMmUyNWQwM2I2YWJjOGYzYmU1Mjk4NDp7Il9hdXRoX3VzZXJfaWQiOiIxNyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMzg3NDU1OWE4OTUyN2Q5NDkzMmQ0MTE5OTliYmRiZWYwNDg5YWZiZiJ9	2019-11-11 15:49:21.439298+00
7xkn4ua83j49azk880xz4dra6gw8i5so	YWQ4MzJiZjcwYzYwYWZmN2RhNjJmMDgyMmQ2MDJhZDNhZTBjZjM0Yzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0Mjc2MzlhYWYzZGFlOTQ4MTNmYzUzMWUxOGM3YzQyY2JkNGNjMTg3In0=	2019-11-11 15:51:02.348804+00
cg02us8xlfcsv3kds9q4r930ultvy646	MGQ5MDliZGFhYWE4M2U1NTllMmUyNWQwM2I2YWJjOGYzYmU1Mjk4NDp7Il9hdXRoX3VzZXJfaWQiOiIxNyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMzg3NDU1OWE4OTUyN2Q5NDkzMmQ0MTE5OTliYmRiZWYwNDg5YWZiZiJ9	2019-11-11 15:57:46.462666+00
\.


--
-- Data for Name: patients_patient; Type: TABLE DATA; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

COPY public.patients_patient (id, created, modified, first_name, last_name, username, gender, birthdate, doctor_id) FROM stdin;
284	2019-09-11 22:42:38.215024+00	2019-09-11 22:42:38.215053+00	alexis	roff	user_alrof2	F	1990-09-11	23
285	2019-09-11 23:07:25.282538+00	2019-09-11 23:07:25.282566+00	juan	perez	user_jupem2	M	1984-09-11	23
286	2019-09-11 23:09:49.045046+00	2019-09-11 23:09:49.045085+00	julia	diaz	user_judif4	F	1992-09-11	23
287	2019-09-12 21:33:02.615592+00	2019-09-12 21:33:02.615619+00	pablo	perez	user_papem8	M	1991-09-12	10
288	2019-09-12 21:41:10.979939+00	2019-09-12 21:41:10.979967+00	Luis	pin	user_Lupim8	M	1990-09-12	10
289	2019-09-12 21:45:52.163886+00	2019-09-12 21:45:52.163911+00	carla	diaz	user_cadif8	F	1991-09-12	10
290	2019-09-13 00:46:45.991565+00	2019-09-13 00:46:45.991603+00	diego	pin	user_dipim4	M	1992-09-12	10
291	2019-09-13 00:47:49.296075+00	2019-09-13 00:47:49.296102+00	juana	lopez	user_julof2	F	1972-09-12	10
292	2019-09-13 00:48:43.823132+00	2019-09-13 00:48:43.823159+00	pedro	pin	user_pepim7	M	1992-09-12	10
293	2019-09-13 16:18:57.534885+00	2019-09-13 16:18:57.534912+00	pablo	gonzalez	user_pagom2	M	1979-09-13	30
294	2019-09-13 16:34:11.695758+00	2019-09-13 16:34:11.695797+00	laura	gomez	user_lagom2	M	1984-09-13	30
295	2019-09-14 00:49:25.090986+00	2019-09-14 00:49:25.091016+00	Juan	Pin	user_JuPim6	M	1995-09-13	30
296	2019-09-15 17:58:44.199578+00	2019-09-15 17:58:44.199604+00	Mariano	Zamora	user_MaZam8	M	1999-09-15	10
297	2019-09-15 19:13:17.838893+00	2019-09-15 19:13:17.838918+00	diego	pin	user_dipim9	M	1988-09-15	30
298	2019-09-15 19:28:57.796801+00	2019-09-15 19:28:57.796827+00	flor	pin	user_flpif7	F	1980-09-15	30
299	2019-09-15 22:35:51.370445+00	2019-09-15 22:35:51.370471+00	ana	duque	user_andum3	M	1994-11-11	1
300	2019-09-16 00:00:02.726333+00	2019-09-16 00:00:02.72636+00	ana	pin	user_anpif6	F	1977-09-15	10
301	2019-09-16 00:09:04.814438+00	2019-09-16 00:09:04.814466+00	Ernesto	Pin	user_ErPim7	M	1976-09-15	30
302	2019-09-16 18:43:49.130986+00	2019-09-16 18:43:49.131011+00	Alex	Bonifacio	user_AlBom9	M	1947-09-16	10
303	2019-09-16 18:43:50.058455+00	2019-09-16 18:43:50.058481+00	Alex	Bonifacio	user_AlBom7	M	1947-09-16	10
304	2019-09-16 18:47:04.30886+00	2019-09-16 18:47:04.308886+00	Flor	rolandi	user_Flrof4	F	1982-09-16	10
305	2019-09-16 18:53:53.899954+00	2019-09-16 18:53:53.89998+00	ana	botin	user_anbof3	F	1975-09-16	10
306	2019-09-16 18:57:34.887564+00	2019-09-16 18:57:34.887591+00	Jose	Lopez	user_JoLom2	M	1970-09-16	10
307	2019-09-16 19:06:25.942712+00	2019-09-16 19:06:25.942737+00	jose	lopez	user_jolom5	M	1971-09-16	31
308	2019-09-16 20:20:47.484052+00	2019-09-16 20:20:47.484079+00	jaun	perez	user_japem3	M	1959-09-16	31
309	2019-09-17 20:34:34.047142+00	2019-09-17 20:34:34.047168+00	Gabriel	Hanglif	user_GaHam6	M	1972-09-01	35
310	2019-09-17 20:37:28.416467+00	2019-09-17 20:37:28.416493+00	Stella	Pavon	user_StPaf5	F	1969-09-17	35
311	2019-09-18 14:44:51.536259+00	2019-09-18 14:44:51.536286+00	Her	Chula	user_HeChf8	F	1963-09-18	10
312	2019-09-18 14:45:07.020951+00	2019-09-18 14:45:07.020976+00	Carolina	Perin	user_CaPef1	F	1950-03-23	32
313	2019-09-18 14:45:07.296185+00	2019-09-18 14:45:07.29621+00	Carolina	Perin	user_CaPef7	F	1950-03-23	32
314	2019-09-18 20:32:46.66613+00	2019-09-18 20:32:46.666157+00	Sergio	Prueba	user_SePrm7	M	1977-09-18	35
315	2019-09-18 20:35:05.077149+00	2019-09-18 20:35:05.077175+00	Prueba	Prueba	user_PrPrf6	F	1968-09-18	35
316	2019-09-20 14:39:40.073026+00	2019-09-20 14:39:40.073054+00	Ana	Conti	user_AnCof5	F	1981-09-20	36
317	2019-09-25 23:02:48.605368+00	2019-09-25 23:02:48.605394+00	Pedro	Pin	user_PePim8	M	1970-09-25	10
319	2019-09-27 04:56:45.22273+00	2019-09-27 04:56:45.222755+00	Kao	Ming	user_KaMim9	M	1992-09-27	10
320	2019-09-27 04:56:46.826472+00	2019-09-27 04:56:46.826498+00	Kao	Ming	user_KaMim5	M	1992-09-27	10
321	2019-09-28 16:55:13.947332+00	2019-09-28 16:55:13.947364+00	Elisa	Yan	user_ElYaf4	F	1982-09-28	10
322	2019-09-28 23:48:42.426198+00	2019-09-28 23:48:42.426236+00	pedro	diaz	user_pedim3	M	1997-09-28	10
323	2019-09-29 00:19:51.657099+00	2019-09-29 00:19:51.657125+00	ana	pan	user_anpaf5	F	1953-09-28	10
329	2019-09-29 13:35:44.108959+00	2019-09-29 13:35:44.10899+00	pedro	diaz	user_pedim9	M	1967-09-29	30
330	2019-09-29 13:40:26.362071+00	2019-09-29 13:40:26.362096+00	JUAN	DIAZ	user_JUDIm7	M	1991-09-29	30
331	2019-09-29 13:44:11.461486+00	2019-09-29 13:44:11.461512+00	alvaro	pin	user_alpim5	M	1988-09-29	30
332	2019-09-29 13:46:42.613829+00	2019-09-29 13:46:42.613854+00	JULIO	pin	user_JUpim7	M	1989-09-29	30
333	2019-09-29 14:51:04.050536+00	2019-09-29 14:51:04.050562+00	Joaco	Rey	user_JoRem7	M	1989-08-29	10
337	2019-10-01 03:49:45.46419+00	2019-10-01 03:49:45.464215+00	Mei	Ying	user_MeYif7	F	1986-10-01	10
338	2019-10-01 03:50:29.689374+00	2019-10-01 03:50:29.689399+00	Juan	Perez	user_JuPem1	M	1981-10-01	10
339	2019-10-01 04:44:16.634545+00	2019-10-01 04:44:16.634572+00	Juan	Perez	user_JuPem7	M	1985-10-01	10
341	2019-10-01 04:54:33.201132+00	2019-10-01 04:54:33.201157+00	Juan	Perez	user_JuPem8	M	1930-10-01	10
342	2019-10-01 19:23:59.4408+00	2019-10-01 19:23:59.440825+00	Ani	Diaz	user_AnDim1	M	1979-10-01	10
343	2019-10-01 19:24:46.450213+00	2019-10-01 19:24:46.45024+00	Ani	Oidella	user_AnOim8	M	1990-10-01	10
346	2019-10-03 01:05:18.321598+00	2019-10-03 01:05:18.321622+00	usuario 1	apellido 1	user_usapm4	M	1992-10-02	10
347	2019-10-03 01:35:01.155225+00	2019-10-03 01:35:01.155252+00	Carlitos	Tervez	user_CaTem5	M	1975-08-20	10
348	2019-10-03 01:52:54.930123+00	2019-10-03 01:52:54.930147+00	Usuario 1	Apellido 1	user_UsApf8	F	1990-10-02	10
349	2019-10-03 01:57:36.613258+00	2019-10-03 01:57:36.613283+00	Usuario 1	Apellido 1	user_UsApm4	M	1974-10-02	10
350	2019-10-03 01:58:50.208983+00	2019-10-03 01:58:50.20901+00	Usuario 1	Apellido 1	user_UsApf1	F	1984-10-02	10
351	2019-10-03 02:06:21.122554+00	2019-10-03 02:06:21.122579+00	Usuario 1	Apellido 1	user_UsApf5	F	1971-10-02	10
352	2019-10-03 02:08:12.334161+00	2019-10-03 02:08:12.334188+00	Ss	Ss	user_SsSsf1	F	1991-10-02	10
353	2019-10-03 02:09:05.072561+00	2019-10-03 02:09:05.072587+00	Juan	Martin	user_JuMaf3	F	1950-10-02	10
354	2019-10-03 02:19:15.642337+00	2019-10-03 02:19:15.642364+00	Usuario 1	Apellido 1	user_UsApm7	M	1989-10-02	10
355	2019-10-05 04:05:46.523715+00	2019-10-05 04:05:46.523746+00	Juan	Pin	user_JuPim3	M	1979-10-05	37
388	2019-10-07 14:31:16.59908+00	2019-10-07 14:31:16.599106+00	Jorge	Porcel	user_JoPom1	M	1951-10-07	70
389	2019-10-07 14:50:02.243831+00	2019-10-07 14:50:02.243859+00	Diego	Pin	user_DiPim6	M	1989-03-07	37
390	2019-10-07 20:36:13.729644+00	2019-10-07 20:36:13.72967+00	Carlos	Prueba1	user_CaPrf2	F	1975-10-01	71
391	2019-10-07 22:45:56.401659+00	2019-10-07 22:45:56.401686+00	Romi	Perez	user_RoPem6	M	1955-12-10	72
393	2019-10-08 02:37:55.284935+00	2019-10-08 02:37:55.284962+00	Carlos	Pim	user_CaPim9	M	1952-10-07	30
394	2019-10-08 02:39:21.127326+00	2019-10-08 02:39:21.127352+00	Pepe	Luis	user_PeLum6	M	1987-10-07	30
396	2019-10-08 11:38:21.688624+00	2019-10-08 11:38:21.68865+00	Carlos	Naltreva	user_CaNam7	M	1983-10-08	75
397	2019-10-08 11:41:21.101981+00	2019-10-08 11:41:21.102006+00	Silvia	Bertino	user_SiBef8	F	1968-08-22	71
399	2019-10-08 19:13:33.631547+00	2019-10-08 19:13:33.631573+00	Maria Eugenia	Garcia	user_MaGaf2	F	1975-02-22	77
400	2019-10-08 19:14:29.52689+00	2019-10-08 19:14:29.526922+00	Marcos	Bullones	user_MaBum7	M	1977-01-30	86
401	2019-10-08 19:35:24.550402+00	2019-10-08 19:35:24.550429+00	Rs	Ka	user_RsKaf6	F	1987-06-19	83
402	2019-10-08 19:42:22.727032+00	2019-10-08 19:42:22.727056+00	Sebastian	Balla	user_SeBam6	M	1989-04-02	90
403	2019-10-08 19:52:43.866083+00	2019-10-08 19:52:43.866109+00	Alejandro	Longo	user_AlLom7	M	1976-05-21	92
404	2019-10-08 20:41:35.992643+00	2019-10-08 20:41:35.992672+00	Lola	Lilo	user_LoLif8	F	1995-01-01	79
405	2019-10-08 20:41:36.744667+00	2019-10-08 20:41:36.744695+00	Lola	Lilo	user_LoLif7	F	1995-01-01	79
406	2019-10-08 21:46:56.306306+00	2019-10-08 21:46:56.306334+00	María Belén	Albornoz	user_MaAlf8	F	1977-04-15	82
407	2019-10-08 22:04:10.348788+00	2019-10-08 22:04:10.348814+00	Patricia	Cabrera	user_PaCaf3	F	1973-10-08	95
408	2019-10-09 00:08:55.025802+00	2019-10-09 00:08:55.025826+00	Rodolfo	Gomez	user_RoGom3	M	1996-10-08	98
409	2019-10-09 01:06:30.175701+00	2019-10-09 01:06:30.175726+00	Huanque	Julio	user_HuJum5	M	1973-11-29	99
410	2019-10-09 01:06:31.128139+00	2019-10-09 01:06:31.128164+00	Huanque	Julio	user_HuJum7	M	1973-11-29	99
411	2019-10-09 09:31:18.937117+00	2019-10-09 09:31:18.937147+00	Rolando	Silvestri	user_RoSim3	M	1962-12-26	100
412	2019-10-09 11:25:49.703834+00	2019-10-09 11:25:49.70386+00	Daniel	Xx	user_DaXxm1	M	1970-03-14	101
413	2019-10-09 12:53:13.254752+00	2019-10-09 12:53:13.254807+00	Beti Maria	Murer	user_BeMuf9	F	1957-04-04	85
414	2019-10-09 13:45:26.638967+00	2019-10-09 13:45:26.638994+00	Angélica	Giordanella	user_AnGif9	F	1970-10-01	103
415	2019-10-09 21:43:44.757633+00	2019-10-09 21:43:44.757659+00	Ailin	Blanco	user_AiBlf8	F	1987-03-27	85
416	2019-10-09 22:20:49.069901+00	2019-10-09 22:20:49.069929+00	Maribel	Burgués	user_MaBuf6	F	1961-04-14	85
417	2019-10-09 22:37:08.316506+00	2019-10-09 22:37:08.316531+00	Juan	Pirulo	user_JuPim7	M	1972-09-09	108
418	2019-10-09 23:00:58.288853+00	2019-10-09 23:00:58.28888+00	María José	Delvilano	user_MaDef3	F	1976-09-22	102
419	2019-10-10 12:21:50.003175+00	2019-10-10 12:21:50.003202+00	Juan	Fruncillo	user_JuFrm9	M	1970-01-01	110
420	2019-10-10 12:28:07.576069+00	2019-10-10 12:28:07.576095+00	Rissotto	Rissotto	user_RiRim1	M	1970-01-01	110
421	2019-10-10 12:32:12.548086+00	2019-10-10 12:32:12.548113+00	Guille	Living	user_GuLim4	M	1983-08-01	110
422	2019-10-10 12:45:02.739266+00	2019-10-10 12:45:02.739292+00	Jose	Canseco	user_JoCam2	M	1978-04-10	111
423	2019-10-10 12:54:39.901129+00	2019-10-10 12:54:39.901446+00	Carlos	Pesce	user_CaPem7	M	1961-05-06	31
424	2019-10-10 13:34:26.175328+00	2019-10-10 13:34:26.175354+00	Ana	Urbina Saavedra	user_AnUrf5	F	1984-02-02	85
425	2019-10-10 14:30:41.624898+00	2019-10-10 14:30:41.624923+00	Cristián	Del Castillo	user_CrDem3	M	1972-10-10	117
426	2019-10-10 14:39:36.969989+00	2019-10-10 14:39:36.970027+00	José	Acosta	user_JoAcm6	M	1974-02-26	118
427	2019-10-10 15:55:56.310466+00	2019-10-10 15:55:56.310493+00	Yo	Prueba	user_YoPrf3	F	1969-02-19	119
428	2019-10-10 16:02:47.017684+00	2019-10-10 16:02:47.01771+00	Yo	Prueba	user_YoPrm7	M	1969-02-19	119
429	2019-10-10 16:44:46.562576+00	2019-10-10 16:44:46.562603+00	Diego	Maradona	user_DiMam5	M	1950-10-30	120
430	2019-10-10 16:48:35.396929+00	2019-10-10 16:48:35.396956+00	Jorge	Sampaio	user_JoSam7	M	1970-05-25	121
431	2019-10-10 17:34:22.41964+00	2019-10-10 17:34:22.419665+00	A	Hgg	user_AHgm4	M	1982-10-10	124
432	2019-10-10 19:13:13.304888+00	2019-10-10 19:13:13.304913+00	Michel	Yo	user_MiYom6	M	1969-02-19	119
433	2019-10-10 19:44:10.43725+00	2019-10-10 19:44:10.437276+00	Yo	Capaz	user_YoCam4	M	2000-10-09	119
434	2019-10-10 20:19:16.821126+00	2019-10-10 20:19:16.821152+00	Soledad	Mestre	user_SoMef2	F	1971-04-09	129
435	2019-10-10 21:13:47.167805+00	2019-10-10 21:13:47.167831+00	Matias	Romero	user_MaRom1	M	1987-02-11	130
436	2019-10-10 21:27:03.087731+00	2019-10-10 21:27:03.087757+00	Toto	Perez	user_ToPem4	M	1981-10-10	131
437	2019-10-10 21:30:18.701808+00	2019-10-10 21:30:18.701834+00	Cacho	Lopez	user_CaLom8	M	1989-10-10	131
438	2019-10-10 21:39:42.999939+00	2019-10-10 21:39:42.99997+00	Héctor	Jimenez	user_HéJim1	M	1983-02-23	132
439	2019-10-10 22:06:10.961639+00	2019-10-10 22:06:10.961665+00	Edison	Pele	user_EdPem7	M	1994-01-10	111
440	2019-10-10 22:07:55.790705+00	2019-10-10 22:07:55.790732+00	Carlos	Galetto	user_CaGam8	M	1963-07-12	133
442	2019-10-10 23:21:17.025176+00	2019-10-10 23:21:17.0252+00	Diego R	Ramirez	user_DiRam5	M	1976-10-21	136
443	2019-10-10 23:21:18.14565+00	2019-10-10 23:21:18.145676+00	Diego R	Ramirez	user_DiRam4	M	1976-10-21	136
445	2019-10-10 23:21:18.566413+00	2019-10-10 23:21:18.566441+00	Diego R	Ramirez	user_DiRam6	M	1976-10-21	136
446	2019-10-11 02:09:20.334346+00	2019-10-11 02:09:20.334374+00	Gustavo	Perez	user_GuPem4	M	1982-10-10	136
447	2019-10-11 04:43:58.744157+00	2019-10-11 04:43:58.744182+00	Irene	Garcia	user_IrGaf6	F	1958-04-08	145
448	2019-10-11 08:19:13.08132+00	2019-10-11 08:19:13.081344+00	Tobias	Lobo	user_ToLom9	M	1971-03-03	139
449	2019-10-11 10:54:42.374598+00	2019-10-11 10:54:42.374624+00	Héctor	Menta	user_HéMem8	M	1969-01-28	146
451	2019-10-11 11:27:40.610763+00	2019-10-11 11:27:40.610791+00	Federico	Repossi	user_FeRem2	M	1971-04-23	148
452	2019-10-11 11:53:29.21686+00	2019-10-11 11:53:29.216885+00	Nicolas	Moyano	user_NiMom1	M	1981-10-11	149
453	2019-10-11 11:54:59.432046+00	2019-10-11 11:54:59.432078+00	Pablo	Moyano	user_PaMom1	M	1975-10-11	149
454	2019-10-11 12:20:22.814379+00	2019-10-11 12:20:22.814431+00	Gabriel	Cicka	user_GaCim4	M	1986-05-20	151
455	2019-10-11 12:55:04.428071+00	2019-10-11 12:55:04.428098+00	A	Ggg	user_AGgf4	F	1989-10-11	124
456	2019-10-11 13:19:47.839854+00	2019-10-11 13:19:47.840239+00	Cesar	Alvarez	user_CeAlm3	M	1963-10-11	124
457	2019-10-11 14:17:51.149595+00	2019-10-11 14:17:51.14962+00	Nestor	Strach	user_NeStm2	M	1972-06-07	157
458	2019-10-11 14:19:04.380939+00	2019-10-11 14:19:04.380966+00	Francisco	Luna	user_FrLuf6	F	1977-01-06	149
459	2019-10-11 14:19:04.766504+00	2019-10-11 14:19:04.76653+00	Francisco	Luna	user_FrLuf5	F	1977-01-06	149
460	2019-10-11 14:24:06.173791+00	2019-10-11 14:24:06.173817+00	Hector	Gomez	user_HeGom1	M	1991-04-13	98
461	2019-10-11 15:23:53.785196+00	2019-10-11 15:23:53.785225+00	Lucas	Ghiano	user_LuGhm3	M	1989-01-08	154
462	2019-10-11 15:25:48.430123+00	2019-10-11 15:25:48.43015+00	Lidia	Castro	user_LiCaf7	F	1966-08-30	145
463	2019-10-11 15:48:24.199198+00	2019-10-11 15:48:24.199223+00	Paola	Martin	user_PaMaf5	F	1974-03-07	158
464	2019-10-11 16:06:28.754154+00	2019-10-11 16:06:28.75418+00	Juan	Raffo	user_JuRam1	M	1961-10-11	101
465	2019-10-11 18:16:46.771317+00	2019-10-11 18:16:46.771344+00	Sandra	Maidana	user_SaMaf5	F	1968-05-03	162
466	2019-10-11 18:43:23.034426+00	2019-10-11 18:43:23.034451+00	Ludmila	Bertneche	user_LuBef3	F	1991-04-23	161
467	2019-10-11 18:43:23.897923+00	2019-10-11 18:43:23.89795+00	Ludmila	Bertneche	user_LuBef5	F	1991-04-23	161
468	2019-10-11 18:59:12.800891+00	2019-10-11 18:59:12.800922+00	Juan	Sesto	user_JuSem7	M	1984-07-07	161
469	2019-10-11 20:24:02.090158+00	2019-10-11 20:24:02.090183+00	Cecilia	Massqroni	user_CeMaf5	F	1966-09-13	116
470	2019-10-11 20:25:05.659553+00	2019-10-11 20:25:05.659581+00	Pettel	Mariana	user_PeMaf8	F	1986-10-11	116
471	2019-10-11 20:27:43.408956+00	2019-10-11 20:27:43.408983+00	Lino	Paola	user_LiPaf8	F	1976-10-11	116
472	2019-10-12 00:10:14.845231+00	2019-10-12 00:10:14.845257+00	Juan	Perón	user_JuPem5	M	1945-10-17	164
473	2019-10-12 11:39:00.539321+00	2019-10-12 11:39:00.539345+00	Ana	Annechini	user_AnAnf5	F	1975-01-11	166
474	2019-10-12 11:44:51.568005+00	2019-10-12 11:44:51.568032+00	Ana	Otero	user_AnOtf5	F	1975-01-11	166
475	2019-10-12 11:50:43.629904+00	2019-10-12 11:50:43.629929+00	Miguel	Annechini	user_MiAnm4	M	1971-12-06	166
476	2019-10-12 19:42:32.525299+00	2019-10-12 19:42:32.525324+00	Cecilia	Mazzarini	user_CeMaf4	F	1966-09-13	116
477	2019-10-12 19:44:10.824881+00	2019-10-12 19:44:10.824908+00	Ceci	Massa	user_CeMaf2	F	1966-10-12	116
478	2019-10-13 19:07:13.830568+00	2019-10-13 19:07:13.830598+00	Marcos	Tomasi	user_MaTom4	M	1973-11-09	134
479	2019-10-14 23:04:22.080296+00	2019-10-14 23:04:22.080322+00	Cecilia	Pucci	user_CePuf3	F	1975-08-13	189
480	2019-10-15 18:11:03.238864+00	2019-10-15 18:11:03.238893+00	Karina	Hughes	user_KaHuf7	F	1984-09-18	77
482	2019-10-15 18:11:04.984446+00	2019-10-15 18:11:04.984473+00	Karina	Hughes	user_KaHuf4	F	1984-09-18	77
483	2019-10-15 21:54:27.857387+00	2019-10-15 21:54:27.857414+00	H	H	user_HHm3	M	1970-10-15	101
484	2019-10-16 11:18:32.873109+00	2019-10-16 11:18:32.873135+00	Rosa	Vicente	user_RoVif8	F	1969-10-16	116
485	2019-10-16 17:20:15.558489+00	2019-10-16 17:20:15.558516+00	Alma	Lopez	user_AlLof8	F	1975-10-16	189
486	2019-10-17 12:00:02.487378+00	2019-10-17 12:00:02.487404+00	Aaa	Ddd	user_AaDdm6	M	1989-10-17	199
487	2019-10-17 13:32:39.49694+00	2019-10-17 13:32:39.496965+00	Gabi	Tulian	user_GaTuf4	F	1967-10-17	149
489	2019-10-17 15:35:42.91566+00	2019-10-17 15:35:42.915685+00	Vicko	Banus	user_ViBaf6	F	1984-03-26	149
490	2019-10-17 15:36:20.028916+00	2019-10-17 15:36:20.028942+00	Vicko	Banus	user_ViBaf9	F	1984-03-26	149
491	2019-10-17 18:23:39.325629+00	2019-10-17 18:23:39.325654+00	Maria Eliana	Tello	user_MaTef8	F	1981-04-17	200
492	2019-10-17 18:28:54.224292+00	2019-10-17 18:28:54.224317+00	Rubén	Insa	user_RuInm2	M	1958-03-31	202
493	2019-10-17 19:38:19.344173+00	2019-10-17 19:38:19.3442+00	Lucas	Lombardi	user_LuLom1	M	1991-10-17	89
494	2019-10-17 19:38:19.724502+00	2019-10-17 19:38:19.724526+00	Lucas	Lombardi	user_LuLom7	M	1991-10-17	89
495	2019-10-17 19:38:20.514732+00	2019-10-17 19:38:20.514759+00	Lucas	Lombardi	user_LuLom5	M	1991-10-17	89
496	2019-10-17 19:38:20.867434+00	2019-10-17 19:38:20.86746+00	Lucas	Lombardi	user_LuLom6	M	1991-10-17	89
497	2019-10-17 23:51:31.091725+00	2019-10-17 23:51:31.091752+00	Ariel	Pereyra	user_ArPem1	M	1973-01-05	203
498	2019-10-18 00:51:16.491258+00	2019-10-18 00:51:16.491285+00	Ana	Lajonquiere	user_AnLaf6	F	1984-01-07	198
499	2019-10-18 14:48:53.673887+00	2019-10-18 14:48:53.673913+00	Vvv	Yy	user_VvYyf8	F	1979-10-18	124
500	2019-10-18 14:54:49.281028+00	2019-10-18 14:54:49.281058+00	3rrrrr	Hhgt	user_3rHhf1	F	1973-10-18	124
501	2019-10-18 18:25:18.717154+00	2019-10-18 18:25:18.71718+00	Ffff	Bhhh	user_FfBhm1	M	1992-10-18	124
502	2019-10-18 18:28:08.495088+00	2019-10-18 18:28:08.495114+00	A	D	user_ADm6	M	1989-10-18	124
503	2019-10-19 00:23:06.660743+00	2019-10-19 00:23:06.660773+00	Ruben	Marquez	user_RuMam5	M	1960-02-06	189
504	2019-10-19 18:13:35.411117+00	2019-10-19 18:13:35.411144+00	Silvia	Realini	user_SiRef9	F	1953-11-10	149
505	2019-10-19 18:13:36.491055+00	2019-10-19 18:13:36.491082+00	Silvia	Realini	user_SiRef5	F	1953-11-10	149
506	2019-10-19 18:14:02.666934+00	2019-10-19 18:14:02.666961+00	Jonathan	Arias	user_JoArm1	M	1986-08-14	206
507	2019-10-19 18:14:04.04754+00	2019-10-19 18:14:04.047568+00	Jonathan	Arias	user_JoArm3	M	1986-08-14	206
508	2019-10-19 20:50:34.313314+00	2019-10-19 20:50:34.31334+00	Luos	Paz	user_LuPam3	M	1955-07-19	207
509	2019-10-19 20:50:35.247731+00	2019-10-19 20:50:35.247757+00	Luos	Paz	user_LuPam9	M	1955-07-19	207
510	2019-10-19 21:57:08.332522+00	2019-10-19 21:57:08.332548+00	Carolina	Borrello	user_CaBof7	F	1983-01-06	117
511	2019-10-19 21:57:08.621275+00	2019-10-19 21:57:08.6213+00	Carolina	Borrello	user_CaBof2	F	1983-01-06	117
512	2019-10-21 15:01:51.581484+00	2019-10-21 15:01:51.581509+00	Gabriela	Pagura	user_GaPaf8	F	1990-10-21	89
513	2019-10-22 20:04:30.775146+00	2019-10-22 20:04:30.775172+00	Marisa	Alvarez	user_MaAlf1	F	1967-03-27	211
514	2019-10-22 20:04:34.448253+00	2019-10-22 20:04:34.44828+00	Marisa	Alvarez	user_MaAlf3	F	1967-03-27	211
515	2019-10-23 12:29:54.063199+00	2019-10-23 12:29:54.063224+00	Juan	Perez	user_JuPem2	M	1958-10-23	212
516	2019-10-23 15:45:56.258722+00	2019-10-23 15:45:56.258754+00	Myriam	Gipo	user_MyGif8	F	1972-02-23	212
517	2019-10-23 17:00:12.622377+00	2019-10-23 17:00:12.622403+00	Alejandra	Melchor	user_AlMef8	F	1969-01-08	210
518	2019-10-23 17:05:35.305078+00	2019-10-23 17:05:35.305102+00	Gamboa	Yesica	user_GaYef2	F	1980-06-10	210
519	2019-10-23 17:07:48.804291+00	2019-10-23 17:07:48.804331+00	Civalero	Eva	user_CiEvf5	F	1956-04-15	210
520	2019-10-23 20:26:25.81762+00	2019-10-23 20:26:25.817647+00	malasisi	Eduardo	user_maEdm4	M	1955-10-23	214
521	2019-10-23 20:59:05.316266+00	2019-10-23 20:59:05.316291+00	Lujan	Amaya	user_LuAmm2	M	1974-01-20	216
522	2019-10-24 03:48:02.874688+00	2019-10-24 03:48:02.874714+00	Brenda	Livenco	user_BrLif8	F	2000-03-03	217
523	2019-10-24 03:48:04.079478+00	2019-10-24 03:48:04.079505+00	Brenda	Livenco	user_BrLif5	F	2000-03-03	217
524	2019-10-24 12:40:07.334321+00	2019-10-24 12:40:07.334348+00	Miguel	Francioni	user_MiFrm4	M	1955-10-01	218
525	2019-10-24 12:40:07.348154+00	2019-10-24 12:40:07.348179+00	Miguel	Francioni	user_MiFrm6	M	1955-10-01	218
527	2019-10-24 16:51:52.845375+00	2019-10-24 16:51:52.845425+00	Ggjjh	Bhhh	user_GgBhm2	M	1976-10-24	124
528	2019-10-24 17:41:53.104414+00	2019-10-24 17:41:53.104441+00	Ariel	Fernandez	user_ArFem6	M	1971-05-14	219
529	2019-10-25 19:22:12.609809+00	2019-10-25 19:22:12.609836+00	Luis Eduardo	Romano	user_LuRom9	M	1949-04-06	219
530	2019-10-25 19:33:00.042463+00	2019-10-25 19:33:00.042491+00	Jose	Soler	user_JoSom1	M	1958-01-07	219
531	2019-10-26 17:22:11.536154+00	2019-10-26 17:22:11.53618+00	Alerta De Sykvas	Jimena	user_AlJif7	F	1971-07-07	221
532	2019-10-28 13:45:28.479733+00	2019-10-28 13:45:28.479759+00	Eric	Gay	user_ErGam8	M	1983-07-01	130
\.


--
-- Data for Name: users_profile; Type: TABLE DATA; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

COPY public.users_profile (id, created, modified, registration_number, registration_type_id, speciality_id, user_id) FROM stdin;
7	2019-08-31 20:56:22.186072+00	2019-08-31 20:56:22.186103+00	123456	1	1	10
12	2019-09-01 16:23:43.286471+00	2019-09-01 16:23:43.286491+00	67432659763256	2	3	15
14	2019-09-03 13:15:45.918983+00	2019-09-03 13:15:45.919003+00	100000	1	1	18
15	2019-09-06 22:21:49.653377+00	2019-09-06 22:21:49.653394+00	100667	1	1	19
19	2019-09-11 21:19:11.020386+00	2019-09-11 21:19:11.020405+00	570119	2	1	23
24	2019-09-13 16:05:28.310793+00	2019-09-13 16:05:28.310813+00	10101010	1	1	28
26	2019-09-13 16:16:09.896361+00	2019-09-13 16:16:09.89638+00	100100	1	1	30
27	2019-09-16 19:05:18.090695+00	2019-09-16 19:05:18.090714+00	076130	1	2	31
28	2019-09-17 18:45:28.911697+00	2019-09-17 18:45:28.911729+00	095300	1	3	32
29	2019-09-17 19:38:02.188657+00	2019-09-17 19:38:02.188682+00	089186	1	4	33
30	2019-09-17 19:49:29.822758+00	2019-09-17 19:49:29.822778+00	111111	1	4	34
31	2019-09-17 20:33:55.722127+00	2019-09-17 20:33:55.722146+00	100237	1	2	35
32	2019-09-20 14:39:10.106158+00	2019-09-20 14:39:10.106178+00	1111114	1	5	36
33	2019-10-05 04:04:55.364698+00	2019-10-05 04:04:55.36472+00	100123	1	1	37
66	2019-10-07 14:30:23.567085+00	2019-10-07 14:30:23.567105+00	122122	1	1	70
67	2019-10-07 20:31:24.821544+00	2019-10-07 20:31:24.821564+00	095058	1	1	71
68	2019-10-07 21:34:21.731559+00	2019-10-07 21:34:21.731578+00	058310	1	1	72
69	2019-10-08 00:35:46.111597+00	2019-10-08 00:35:46.111616+00	091173	1	2	73
70	2019-10-08 03:02:25.951861+00	2019-10-08 03:02:25.951881+00	0088409	1	1	74
71	2019-10-08 11:37:11.604003+00	2019-10-08 11:37:11.604023+00	091165	1	2	75
72	2019-10-08 16:40:04.400046+00	2019-10-08 16:40:04.400066+00	100705	1	2	76
73	2019-10-08 18:24:17.054645+00	2019-10-08 18:24:17.054664+00	002892	2	1	77
74	2019-10-08 18:43:08.882715+00	2019-10-08 18:43:08.882733+00	112112	2	5	78
75	2019-10-08 18:43:24.383507+00	2019-10-08 18:43:24.383526+00	113456	3	2	79
76	2019-10-08 18:56:54.757503+00	2019-10-08 18:56:54.757522+00	152681	3	2	80
77	2019-10-08 19:03:06.121786+00	2019-10-08 19:03:06.121807+00	001111	2	1	81
78	2019-10-08 19:05:54.879022+00	2019-10-08 19:05:54.879041+00	140000	2	5	82
79	2019-10-08 19:06:57.766694+00	2019-10-08 19:06:57.766713+00	005576	2	5	83
80	2019-10-08 19:09:43.681417+00	2019-10-08 19:09:43.681438+00	22556688	3	5	84
81	2019-10-08 19:13:05.917608+00	2019-10-08 19:13:05.917642+00	331200	3	5	85
82	2019-10-08 19:13:54.666151+00	2019-10-08 19:13:54.666171+00	966669	3	4	86
83	2019-10-08 19:24:44.486774+00	2019-10-08 19:24:44.486794+00	352563	2	5	87
84	2019-10-08 19:30:39.80228+00	2019-10-08 19:30:39.8023+00	000000	2	5	88
85	2019-10-08 19:34:25.440986+00	2019-10-08 19:34:25.441006+00	682452	1	2	89
86	2019-10-08 19:41:47.800314+00	2019-10-08 19:41:47.800333+00	0000000	3	5	90
87	2019-10-08 19:47:05.002873+00	2019-10-08 19:47:05.002892+00	015054	2	2	91
88	2019-10-08 19:51:14.983707+00	2019-10-08 19:51:14.983726+00	999999	1	2	92
89	2019-10-08 19:53:26.41556+00	2019-10-08 19:53:26.415577+00	006467	2	4	93
90	2019-10-08 20:02:05.721355+00	2019-10-08 20:02:05.721374+00	067329	1	1	94
91	2019-10-08 21:50:31.797825+00	2019-10-08 21:50:31.797844+00	006334	2	5	95
92	2019-10-08 22:09:39.198321+00	2019-10-08 22:09:39.198341+00	005257	2	5	96
93	2019-10-08 22:29:53.02654+00	2019-10-08 22:29:53.026558+00	049287	1	4	97
94	2019-10-09 00:08:13.592272+00	2019-10-09 00:08:13.592291+00	008050	2	5	98
95	2019-10-09 01:03:31.301739+00	2019-10-09 01:03:31.301758+00	138337	1	2	99
96	2019-10-09 09:30:08.16162+00	2019-10-09 09:30:08.16164+00	099736	1	5	100
97	2019-10-09 11:25:12.75934+00	2019-10-09 11:25:12.759359+00	1234567	1	2	101
98	2019-10-09 12:06:45.765313+00	2019-10-09 12:06:45.765332+00	141363	1	1	102
99	2019-10-09 13:44:19.04273+00	2019-10-09 13:44:19.04275+00	103583	1	2	103
100	2019-10-09 15:57:01.389245+00	2019-10-09 15:57:01.389265+00	245685	1	5	104
101	2019-10-09 16:28:26.423809+00	2019-10-09 16:28:26.423828+00	000001	1	5	105
102	2019-10-09 21:23:21.579766+00	2019-10-09 21:23:21.579785+00	25032127	3	5	106
103	2019-10-09 21:42:51.44536+00	2019-10-09 21:42:51.445377+00	112074	1	3	107
104	2019-10-09 22:36:18.771905+00	2019-10-09 22:36:18.771923+00	093909	2	2	108
105	2019-10-10 00:16:50.665135+00	2019-10-10 00:16:50.665154+00	002204	2	2	109
106	2019-10-10 12:20:44.142073+00	2019-10-10 12:20:44.142092+00	111111111	3	5	110
107	2019-10-10 12:44:16.94468+00	2019-10-10 12:44:16.944711+00	121212	1	1	111
108	2019-10-10 13:11:24.416262+00	2019-10-10 13:11:24.416282+00	003884	2	2	112
109	2019-10-10 13:17:49.187987+00	2019-10-10 13:17:49.188005+00	1111111	1	4	113
110	2019-10-10 13:57:57.89583+00	2019-10-10 13:57:57.895848+00	200200	1	1	114
111	2019-10-10 14:02:13.809758+00	2019-10-10 14:02:13.809777+00	300300	3	2	115
112	2019-10-10 14:12:13.69628+00	2019-10-10 14:12:13.6963+00	263200	2	4	116
113	2019-10-10 14:30:07.500264+00	2019-10-10 14:30:07.500284+00	122796	1	2	117
114	2019-10-10 14:39:01.838945+00	2019-10-10 14:39:01.838964+00	123123123	2	2	118
115	2019-10-10 15:52:30.635647+00	2019-10-10 15:52:30.635665+00	92331568	1	5	119
116	2019-10-10 16:43:25.927065+00	2019-10-10 16:43:25.927095+00	111112	1	4	120
117	2019-10-10 16:45:37.11394+00	2019-10-10 16:45:37.113957+00	310399	2	1	121
118	2019-10-10 16:50:00.610648+00	2019-10-10 16:50:00.610667+00	111845	1	3	122
119	2019-10-10 17:19:13.746589+00	2019-10-10 17:19:13.746608+00	094130	2	5	123
120	2019-10-10 17:32:54.026479+00	2019-10-10 17:32:54.026499+00	1111111111	2	2	124
121	2019-10-10 17:36:42.731578+00	2019-10-10 17:36:42.731596+00	13245678	2	1	125
122	2019-10-10 18:14:59.38894+00	2019-10-10 18:14:59.388958+00	111115	1	3	126
123	2019-10-10 18:56:27.739471+00	2019-10-10 18:56:27.73949+00	210365	3	5	127
124	2019-10-10 19:26:56.584729+00	2019-10-10 19:26:56.584749+00	154800	2	5	128
125	2019-10-10 20:18:01.195431+00	2019-10-10 20:18:01.195451+00	011451	2	2	129
126	2019-10-10 21:13:14.998902+00	2019-10-10 21:13:14.998921+00	11111111	2	5	130
127	2019-10-10 21:26:28.700376+00	2019-10-10 21:26:28.700393+00	654321	2	2	131
128	2019-10-10 21:37:06.90438+00	2019-10-10 21:37:06.904412+00	004414	2	4	132
129	2019-10-10 22:06:50.129997+00	2019-10-10 22:06:50.130017+00	236775	2	2	133
130	2019-10-10 22:46:51.002769+00	2019-10-10 22:46:51.002789+00	094240	2	2	134
131	2019-10-10 23:05:32.036878+00	2019-10-10 23:05:32.036896+00	108203	2	2	135
132	2019-10-10 23:19:58.699968+00	2019-10-10 23:19:58.699988+00	101213	2	2	136
133	2019-10-11 01:35:17.232223+00	2019-10-11 01:35:17.232241+00	555555	1	2	137
134	2019-10-11 01:37:37.932373+00	2019-10-11 01:37:37.932391+00	014692	2	2	138
135	2019-10-11 01:42:51.962344+00	2019-10-11 01:42:51.962364+00	236037	2	2	139
136	2019-10-11 02:05:10.889328+00	2019-10-11 02:05:10.889348+00	0094900	2	5	140
137	2019-10-11 02:30:36.063224+00	2019-10-11 02:30:36.063244+00	009599	2	5	141
138	2019-10-11 02:52:15.890669+00	2019-10-11 02:52:15.890688+00	012123	1	1	142
139	2019-10-11 03:12:19.678764+00	2019-10-11 03:12:19.678783+00	021050	2	4	143
140	2019-10-11 03:12:49.779626+00	2019-10-11 03:12:49.779645+00	064241	2	4	144
141	2019-10-11 04:42:39.402604+00	2019-10-11 04:42:39.402622+00	001196	2	2	145
142	2019-10-11 10:52:42.290524+00	2019-10-11 10:52:42.290543+00	222222	2	2	146
143	2019-10-11 11:04:56.192621+00	2019-10-11 11:04:56.19264+00	015189	2	4	147
144	2019-10-11 11:26:58.700405+00	2019-10-11 11:26:58.700425+00	417215	2	2	148
145	2019-10-11 11:53:00.896259+00	2019-10-11 11:53:00.896278+00	111113	1	2	149
146	2019-10-11 12:05:12.425714+00	2019-10-11 12:05:12.425733+00	21393152	2	2	150
147	2019-10-11 12:19:43.464913+00	2019-10-11 12:19:43.464932+00	398253	3	4	151
148	2019-10-11 12:41:27.959117+00	2019-10-11 12:41:27.959136+00	338046	2	2	152
149	2019-10-11 13:04:24.144089+00	2019-10-11 13:04:24.144109+00	057471	1	4	153
150	2019-10-11 13:10:35.861488+00	2019-10-11 13:10:35.861507+00	124586	2	3	154
151	2019-10-11 13:26:14.986637+00	2019-10-11 13:26:14.986655+00	064682	1	2	155
152	2019-10-11 13:53:05.046162+00	2019-10-11 13:53:05.046181+00	091306	1	3	156
153	2019-10-11 14:15:34.520163+00	2019-10-11 14:15:34.520182+00	104489	1	4	157
154	2019-10-11 15:47:29.387+00	2019-10-11 15:47:29.387021+00	136238	1	5	158
155	2019-10-11 15:48:17.909355+00	2019-10-11 15:48:17.909375+00	118431	1	2	159
156	2019-10-11 17:25:55.900299+00	2019-10-11 17:25:55.900319+00	070282	1	5	160
157	2019-10-11 18:10:17.211243+00	2019-10-11 18:10:17.211261+00	335138	2	2	161
158	2019-10-11 18:15:45.714748+00	2019-10-11 18:15:45.714769+00	217600	2	2	162
159	2019-10-11 20:03:12.969268+00	2019-10-11 20:03:12.969287+00	166666	3	2	163
160	2019-10-12 00:09:14.379686+00	2019-10-12 00:09:14.379708+00	080700	1	4	164
161	2019-10-12 07:27:31.589683+00	2019-10-12 07:27:31.589703+00	111163	2	2	165
162	2019-10-12 11:37:53.105679+00	2019-10-12 11:37:53.105698+00	22576679	2	2	166
163	2019-10-14 13:54:39.794658+00	2019-10-14 13:54:39.794679+00	0295091	2	5	167
164	2019-10-14 14:38:53.638782+00	2019-10-14 14:38:53.638801+00	088935	1	5	168
185	2019-10-14 23:03:26.431359+00	2019-10-14 23:03:26.431379+00	777777	2	5	189
187	2019-10-15 15:29:57.166701+00	2019-10-15 15:29:57.166721+00	006015	2	2	191
188	2019-10-15 16:09:48.278607+00	2019-10-15 16:09:48.278627+00	011111	1	5	192
189	2019-10-15 16:53:49.33998+00	2019-10-15 16:53:49.34+00	014129	2	2	193
190	2019-10-15 21:27:33.910462+00	2019-10-15 21:27:33.910483+00	036706	2	2	194
191	2019-10-15 22:42:50.238401+00	2019-10-15 22:42:50.238419+00	092192	2	5	195
192	2019-10-16 17:02:35.150317+00	2019-10-16 17:02:35.150338+00	447206	2	3	196
193	2019-10-16 23:37:10.482185+00	2019-10-16 23:37:10.482204+00	070645	1	2	197
194	2019-10-17 03:05:24.436847+00	2019-10-17 03:05:24.436867+00	141050	1	2	198
195	2019-10-17 11:59:34.813478+00	2019-10-17 11:59:34.813497+00	111110	2	1	199
196	2019-10-17 16:21:32.066149+00	2019-10-17 16:21:32.066183+00	026891	2	2	200
197	2019-10-17 18:02:29.761904+00	2019-10-17 18:02:29.761923+00	109779	1	4	201
198	2019-10-17 18:27:58.760379+00	2019-10-17 18:27:58.760399+00	174013	1	2	202
199	2019-10-17 23:50:47.628165+00	2019-10-17 23:50:47.628184+00	328519	2	2	203
200	2019-10-18 15:41:48.336332+00	2019-10-18 15:41:48.336352+00	081479	2	2	204
201	2019-10-19 15:24:55.722889+00	2019-10-19 15:24:55.72291+00	110590	1	4	205
202	2019-10-19 18:12:56.859492+00	2019-10-19 18:12:56.859511+00	144343	1	5	206
203	2019-10-19 20:48:44.976906+00	2019-10-19 20:48:44.976925+00	024308	2	5	207
204	2019-10-20 22:48:54.382768+00	2019-10-20 22:48:54.382788+00	115396	1	4	208
205	2019-10-21 18:16:13.487634+00	2019-10-21 18:16:13.487654+00	096364	1	4	209
206	2019-10-22 15:25:14.795659+00	2019-10-22 15:25:14.795679+00	002581	2	3	210
207	2019-10-22 20:02:12.195295+00	2019-10-22 20:02:12.195315+00	021534	2	3	211
208	2019-10-23 12:29:18.942986+00	2019-10-23 12:29:18.943005+00	072535	1	4	212
209	2019-10-23 15:19:01.235414+00	2019-10-23 15:19:01.235435+00	133415	1	4	213
210	2019-10-23 20:25:49.194662+00	2019-10-23 20:25:49.194682+00	015284	2	1	214
211	2019-10-23 20:38:51.412128+00	2019-10-23 20:38:51.412148+00	002260	2	1	215
212	2019-10-23 20:58:09.311585+00	2019-10-23 20:58:09.311604+00	016333	2	5	216
213	2019-10-24 03:47:04.301665+00	2019-10-24 03:47:04.301684+00	568093	3	5	217
214	2019-10-24 11:36:19.17971+00	2019-10-24 11:36:19.179744+00	020263	2	2	218
215	2019-10-24 17:40:50.563174+00	2019-10-24 17:40:50.563194+00	069064	1	1	219
216	2019-10-25 15:14:53.227778+00	2019-10-25 15:14:53.227799+00	002938	2	5	220
217	2019-10-26 17:18:41.025179+00	2019-10-26 17:18:41.025198+00	011937	2	2	221
218	2019-10-28 16:47:00.217231+00	2019-10-28 16:47:00.21725+00	002407	2	2	222
219	2019-10-28 17:46:46.588017+00	2019-10-28 17:46:46.588042+00	019406	2	2	223
220	2019-10-28 18:02:05.079529+00	2019-10-28 18:02:05.079549+00	\N	3	2	224
221	2019-10-28 18:36:20.234192+00	2019-10-28 18:36:20.234239+00	026927	2	2	225
222	2019-10-28 18:49:59.142585+00	2019-10-28 18:49:59.142605+00	064618	2	3	226
223	2019-10-28 18:51:42.579329+00	2019-10-28 18:51:42.579349+00	228237	2	2	227
224	2019-10-28 19:21:26.862833+00	2019-10-28 19:21:26.862853+00	227274	2	4	228
\.


--
-- Data for Name: users_registrationtype; Type: TABLE DATA; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

COPY public.users_registrationtype (id, name, slug_name) FROM stdin;
1	Nacional	nacional
2	Provincial	provincial
3	En trámite	en_tramite
\.


--
-- Data for Name: users_speciality; Type: TABLE DATA; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

COPY public.users_speciality (id, name, slug_name) FROM stdin;
1	Cardiología	cardiologia
3	Endocrinología	endocrinologia
4	Nutrición	nutricion
5	Otras	otras
2	Clínica médica	clinica_medica
\.


--
-- Data for Name: users_user; Type: TABLE DATA; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

COPY public.users_user (id, password, last_login, is_superuser, username, first_name, last_name, is_staff, is_active, date_joined, created, modified, email) FROM stdin;
70	argon2$argon2i$v=19$m=512,t=2,p=2$aExpUGYwWjkxYWpm$/JwEnr40ImDCvarXz5s7Ug	\N	f	122122	Alex	Bonifacio	f	t	2019-10-07 14:30:23.552696+00	2019-10-07 14:30:23.555104+00	2019-10-07 14:30:23.555119+00	abonifacio@raffo.com.ar
5	argon2$argon2i$v=19$m=512,t=2,p=2$RVFrVzVWWXZuRFR2$Xknw0lIpACgCB1herwxlxg	2019-08-31 16:11:13+00	f	catalina.picco@gmail.com	Catalina	Picco	f	t	2019-08-31 16:09:58+00	2019-08-31 16:09:58.893467+00	2019-08-31 16:11:19.617279+00	catalina.picco@gmail.com
15	argon2$argon2i$v=19$m=512,t=2,p=2$MHBIaE5iWFZHQUxU$O92SdcNZgv9W57Nbfgnv6w	\N	f	67432659763256	lorena	picco	f	t	2019-09-01 16:23:43.283406+00	2019-09-01 16:23:43.285588+00	2019-09-01 16:23:43.285601+00	lorenapicco@hotmail.com
28	argon2$argon2i$v=19$m=512,t=2,p=2$dVlKaERkalNxSE5K$hJ5VRf8AyP3XX0JxiVvJnQ	\N	f	10101010	Juan	Perez	f	t	2019-09-13 16:05:28.307668+00	2019-09-13 16:05:28.309827+00	2019-09-13 16:05:28.309842+00	juanperez@gmail.com
71	argon2$argon2i$v=19$m=512,t=2,p=2$T1VweWdyNjl3c1Nr$L7ZdXRbizWVJ4ufg9s3tOQ	\N	f	095058	Ezequiel	Berlante	f	t	2019-10-07 20:31:24.818182+00	2019-10-07 20:31:24.820462+00	2019-10-07 20:31:24.820477+00	ezequiel.berlante@gmail.com
18	argon2$argon2i$v=19$m=512,t=2,p=2$R1JnSml4TlRUeG5N$INK7WvmWXTSzST+C7lem+A	\N	f	100000	test	test	f	t	2019-09-03 13:15:45.914486+00	2019-09-03 13:15:45.918078+00	2019-09-03 13:15:45.918092+00	test@test.com
19	argon2$argon2i$v=19$m=512,t=2,p=2$RHVhQVcydG4wUzBi$YWW7CiKiS7IvtrSCxW+nUQ	\N	f	100667	test	test	f	t	2019-09-06 22:21:49.648114+00	2019-09-06 22:21:49.650445+00	2019-09-06 22:21:49.650458+00	test@gmail.com
30	argon2$argon2i$v=19$m=512,t=2,p=2$QVRYa0p3SWtYcE5Y$K4fQs8RpDuylJMPZw1CP2Q	\N	f	100100	Juan	Diaz	f	t	2019-09-13 16:16:09.893249+00	2019-09-13 16:16:09.895414+00	2019-09-13 16:16:09.895427+00	juandiaz@gmail.com
31	argon2$argon2i$v=19$m=512,t=2,p=2$NUtXVUl5T3lSNWx1$cvdreXhBrWJrAvItHYF8PA	\N	f	076130	carlos	pesce	f	t	2019-09-16 19:05:18.07114+00	2019-09-16 19:05:18.073528+00	2019-09-16 19:05:18.073543+00	cpesce@raffo.com.ar
32	argon2$argon2i$v=19$m=512,t=2,p=2$ZkRWeExzVWZSWXkx$5t+y2MzmR/+wgDjTD1I9JQ	\N	f	095300	Juliana	Mociulsky	f	t	2019-09-17 18:45:28.901588+00	2019-09-17 18:45:28.903676+00	2019-09-17 18:45:28.903689+00	juliana.mociulsky@gmail.com
23	argon2$argon2i$v=19$m=512,t=2,p=2$bUVNNmxDQjRTUTlq$E628s621/ox9a413bQ2+gQ	\N	f	570119	Flora	Rolandi	f	t	2019-09-11 21:19:11.017153+00	2019-09-11 21:19:11.019399+00	2019-09-11 21:19:11.019412+00	florencia.rolandi@septum.com.ar
72	argon2$argon2i$v=19$m=512,t=2,p=2$RnltbDhub0dmNWNq$2gmegns9qKHEi3oPYy6/HQ	\N	f	058310	Ricardo	Iglesias	f	t	2019-10-07 21:34:21.728372+00	2019-10-07 21:34:21.730519+00	2019-10-07 21:34:21.730545+00	ricardomiglesias@gmail.com
33	argon2$argon2i$v=19$m=512,t=2,p=2$bXdjNU1rWXNjU1Z1$QhJ+3rWoJ/Stctow/8WMag	\N	f	089186	Nancy	Buschenbaum	f	t	2019-09-17 19:38:02.184407+00	2019-09-17 19:38:02.186568+00	2019-09-17 19:38:02.186581+00	nbuschenbaum@gmail.com
34	argon2$argon2i$v=19$m=512,t=2,p=2$OXV0N3ppTExrbDc2$8b/5gyyUV6g4wQUZSsH3XQ	\N	f	111111	Ariel	Santamaria	f	t	2019-09-17 19:49:29.819674+00	2019-09-17 19:49:29.821838+00	2019-09-17 19:49:29.821853+00	alsanta1974@gmail.com
35	argon2$argon2i$v=19$m=512,t=2,p=2$TlpnaWQxTEZBTW9B$EI6xvKt7ybIsYoLLn54nWQ	\N	f	100237	Adrian	Cormillot	f	t	2019-09-17 20:33:55.661046+00	2019-09-17 20:33:55.720877+00	2019-09-17 20:33:55.720893+00	adrian.cormillot@gmail.com
36	argon2$argon2i$v=19$m=512,t=2,p=2$em1ZVGx4cXdpNVli$DnDXtrVNz9C+sm4XGrd3hA	\N	f	1111114	Ana	Conti	f	t	2019-09-20 14:39:10.103119+00	2019-09-20 14:39:10.10513+00	2019-09-20 14:39:10.105144+00	ana@septum.com.ar
73	argon2$argon2i$v=19$m=512,t=2,p=2$MUFSbUxFWEZJT0Vh$7iG3iWTnbCBTu7foXshidQ	\N	f	091173	Diego	Bashkansky	f	t	2019-10-08 00:35:46.108551+00	2019-10-08 00:35:46.110705+00	2019-10-08 00:35:46.110719+00	dbashkansky@gmail.com
74	argon2$argon2i$v=19$m=512,t=2,p=2$eWNYZ2FsYUVUZEV1$ERO1fE05KPgrC1qtgK9Hpg	\N	f	0088409	Andrea	Curcio	f	t	2019-10-08 03:02:25.948446+00	2019-10-08 03:02:25.950895+00	2019-10-08 03:02:25.950909+00	andc@live.com.ar
75	argon2$argon2i$v=19$m=512,t=2,p=2$SUl5UWxQVVZnMDBl$CCFYxmrZIgIizEcmtgbLcg	\N	f	091165	Gabriel	Safatli	f	t	2019-10-08 11:37:11.600765+00	2019-10-08 11:37:11.602887+00	2019-10-08 11:37:11.602901+00	gabrielsafatli@hotmail.com
76	argon2$argon2i$v=19$m=512,t=2,p=2$c1l4Nk5WdWZjN0NV$iu88uI4oFdCw15IUuacFOQ	\N	f	100705	Carlos	Urdaniz	f	t	2019-10-08 16:40:04.39688+00	2019-10-08 16:40:04.399113+00	2019-10-08 16:40:04.399127+00	carlosurdaniz@hotmail.com
77	argon2$argon2i$v=19$m=512,t=2,p=2$WlN5ajdXczQzOEhC$0UeWS1IwoYKmp+18qDYC9w	\N	f	002892	Damian	Serebrinsky	f	t	2019-10-08 18:24:17.051478+00	2019-10-08 18:24:17.053702+00	2019-10-08 18:24:17.053716+00	serebrinsky@intramed.net
37	argon2$argon2i$v=19$m=512,t=2,p=2$U2d3UzBkRER4UWFO$qYo0oSlzHPCLrShWwFS+Zw	\N	f	100123	Juan	Test	f	t	2019-10-05 04:04:55.349727+00	2019-10-05 04:04:55.352006+00	2019-10-05 04:04:55.352032+00	juantest1@gmail.com
78	argon2$argon2i$v=19$m=512,t=2,p=2$S3N1R2FodWE3ZlpD$2oGAs0UwO45lp7YaAwLd9A	\N	f	112112	Nicolas	Keil	f	t	2019-10-08 18:43:08.879651+00	2019-10-08 18:43:08.881775+00	2019-10-08 18:43:08.881788+00	nkeil@raffo.com
79	argon2$argon2i$v=19$m=512,t=2,p=2$SlBOV2VyRTI0aGg3$7u+m6MxjP+HkQKmk6LG8PQ	\N	f	113456	Sebastian	Dedomenici	f	t	2019-10-08 18:43:24.380449+00	2019-10-08 18:43:24.382593+00	2019-10-08 18:43:24.382607+00	sebadedomenici@yahoo.com.ar
80	argon2$argon2i$v=19$m=512,t=2,p=2$UDZCR2ptTW5ueDFO$WCfLpkC0fRypAWDLUq+fPQ	\N	f	152681	Alejandra	Rodriguez	f	t	2019-10-08 18:56:54.754339+00	2019-10-08 18:56:54.756523+00	2019-10-08 18:56:54.756552+00	alejandrar@raffo.com.ar
81	argon2$argon2i$v=19$m=512,t=2,p=2$Y0NTcU5pM1NZd2dU$OOkZPIM3CyauLDX2Nr8ZKQ	\N	f	001111	Germán Agustín	Arias	f	t	2019-10-08 19:03:06.118648+00	2019-10-08 19:03:06.120844+00	2019-10-08 19:03:06.120858+00	garias@raffo.com.ar
82	argon2$argon2i$v=19$m=512,t=2,p=2$QkNKb2VqV1hRRks1$JP5ofMC4yrPFb7pER12SxA	\N	f	140000	Carlos	Tillar	f	t	2019-10-08 19:05:54.875711+00	2019-10-08 19:05:54.877814+00	2019-10-08 19:05:54.877827+00	ctillar@raffo.com.ar
83	argon2$argon2i$v=19$m=512,t=2,p=2$dFAxTFE2RTNyTUJ1$RWR0lTTyYNLqA4F0Sj2yow	\N	f	005576	Silene	Kairuz	f	t	2019-10-08 19:06:57.763608+00	2019-10-08 19:06:57.765724+00	2019-10-08 19:06:57.765738+00	kairuzsile@gmail.com
84	argon2$argon2i$v=19$m=512,t=2,p=2$YUJIdnI4RU9iY2Y0$Tm/nl82MymI+AeaCj6RF2g	\N	f	22556688	Mario	Garrido	f	t	2019-10-08 19:09:43.678305+00	2019-10-08 19:09:43.680481+00	2019-10-08 19:09:43.680495+00	Garrido.mr@gmail.con
85	argon2$argon2i$v=19$m=512,t=2,p=2$Y1RjbWNRaG1qUGFk$aqcOonvF9EN86jVFo4LuAw	\N	f	331200	Andrés	Sandoval	f	t	2019-10-08 19:13:05.914555+00	2019-10-08 19:13:05.916711+00	2019-10-08 19:13:05.916726+00	ahsnqn@gmail.com
10	argon2$argon2i$v=19$m=512,t=2,p=2$RE4zQzUyT0kzRHo2$yV/QCs9TIsmyuLtZJsYGgw	2019-10-28 15:29:17.740428+00	f	123456	Ming Chun	Kao	t	t	2019-08-31 20:56:22+00	2019-08-31 20:56:22.185203+00	2019-10-14 21:14:36.117144+00	sir.kao@gmail.com
17	argon2$argon2i$v=19$m=512,t=2,p=2$TjRGRXNXVTIxS1N2$6IOMpck37Ukv/9XJoqkVSQ	2019-10-28 15:57:46.459612+00	t	florencia.rolandi@gmail.com	Florencia	Rolandi	t	t	2019-09-01 22:06:41+00	2019-09-01 22:06:41.82766+00	2019-09-27 22:22:12.178935+00	florencia.rolandi@gmail.com
86	argon2$argon2i$v=19$m=512,t=2,p=2$d1FlZ25jUVg5UkV2$bfEgFuIlt2TGBM4TVtgcRQ	\N	f	966669	Marcos	Bullones	f	t	2019-10-08 19:13:54.662496+00	2019-10-08 19:13:54.664638+00	2019-10-08 19:13:54.664652+00	mbullones@raffo.com.ar
87	argon2$argon2i$v=19$m=512,t=2,p=2$bWhsMlZkY2Q3NWgz$wGmorr7zFZTDFxYn11qPSw	\N	f	352563	Mauricio	Reano	f	t	2019-10-08 19:24:44.483553+00	2019-10-08 19:24:44.485817+00	2019-10-08 19:24:44.485831+00	mauricioreano@gmail.com
88	argon2$argon2i$v=19$m=512,t=2,p=2$SFMzRm4yVGdHa2xa$N8osbotkk5tp/5UfPTENZw	\N	f	000000	Natalia	Mancuso	f	t	2019-10-08 19:30:39.79927+00	2019-10-08 19:30:39.801355+00	2019-10-08 19:30:39.801369+00	nmancuso@raffo.com.ar
89	argon2$argon2i$v=19$m=512,t=2,p=2$TlRjOVQ4b09OTGFB$ZhCfmRo7BatpUdUHPzfepQ	\N	f	682452	Guillermo	Sosa	f	t	2019-10-08 19:34:25.437801+00	2019-10-08 19:34:25.440036+00	2019-10-08 19:34:25.44005+00	gsosa@raffo.com.ar
90	argon2$argon2i$v=19$m=512,t=2,p=2$V0VGN2ZUa01uZW5D$0NbrsEiY7wK39UVhlFEEcw	\N	f	0000000	Sebastian	Balla	f	t	2019-10-08 19:41:47.796952+00	2019-10-08 19:41:47.799236+00	2019-10-08 19:41:47.799261+00	sebab8994@gmail.com
91	argon2$argon2i$v=19$m=512,t=2,p=2$TXZHY1AyU0JGWjV2$owIS1wmUpPX/ik45zxmbjQ	\N	f	015054	Lorena Maricel	Medicina	f	t	2019-10-08 19:47:04.999728+00	2019-10-08 19:47:05.001877+00	2019-10-08 19:47:05.001892+00	loiena@hotmail.com
92	argon2$argon2i$v=19$m=512,t=2,p=2$ZDBJNGZNU3RKSjI2$ejt3SyFFtBfx1FcaxDz3SA	\N	f	999999	Alejandro	Longo	f	t	2019-10-08 19:51:14.980592+00	2019-10-08 19:51:14.982782+00	2019-10-08 19:51:14.982797+00	alongo@raffo.com.ar
93	argon2$argon2i$v=19$m=512,t=2,p=2$NGxybFhUR0haWTFK$EXrfxLMoB21w6fqMQErHsw	\N	f	006467	Pablo	Campos	f	t	2019-10-08 19:53:26.412416+00	2019-10-08 19:53:26.414701+00	2019-10-08 19:53:26.414715+00	drpcampos@hotmail.con
94	argon2$argon2i$v=19$m=512,t=2,p=2$eXNDUjJMc044WG1M$QoTiww66mH1Bt6g/FGrBPg	\N	f	067329	Pedro	Aleart	f	t	2019-10-08 20:02:05.71832+00	2019-10-08 20:02:05.720475+00	2019-10-08 20:02:05.72049+00	aleart10@gmail.com
95	argon2$argon2i$v=19$m=512,t=2,p=2$Q1NQNWhZMFZLeUY0$XW7aMpqs1ZrQLTBsqDtr1Q	\N	f	006334	Conrado	Dip	f	t	2019-10-08 21:50:31.79475+00	2019-10-08 21:50:31.796885+00	2019-10-08 21:50:31.796899+00	conradotiburcio@hotmail.com
96	argon2$argon2i$v=19$m=512,t=2,p=2$Nlh6cVlNOW1GWlM1$5APckV2OAhuV2TRnq/ngoA	\N	f	005257	Rubén Sebastián	Zalazar	f	t	2019-10-08 22:09:39.195246+00	2019-10-08 22:09:39.197404+00	2019-10-08 22:09:39.197417+00	ruben_zalazar@hotmail.com
97	argon2$argon2i$v=19$m=512,t=2,p=2$M3p2bGY2TUliU20w$UmIiUN0Gbdk4ByISYjJyOQ	\N	f	049287	Oscar	Karagenzian	f	t	2019-10-08 22:29:53.023468+00	2019-10-08 22:29:53.025587+00	2019-10-08 22:29:53.025601+00	oscarkaragenzian@gmail.com
98	argon2$argon2i$v=19$m=512,t=2,p=2$TU5PZFdMSTY1ZXJG$pDZeRIBQ6S1v3Xkt4PVkcw	\N	f	008050	Vanessa	Nelegatti	f	t	2019-10-09 00:08:13.58918+00	2019-10-09 00:08:13.591352+00	2019-10-09 00:08:13.591366+00	vane_nelegatti83@hotmail.com
99	argon2$argon2i$v=19$m=512,t=2,p=2$TG1iZWxxclBJMFRw$Wh8bu8rB0eCl1ZSRxQVCkA	\N	f	138337	Angelina	Zeballos	f	t	2019-10-09 01:03:31.298746+00	2019-10-09 01:03:31.300812+00	2019-10-09 01:03:31.300825+00	angelinazeballos@hotmail.com
100	argon2$argon2i$v=19$m=512,t=2,p=2$Y3BIN0hBT1RiZXJ2$FLogDENXvaOPDUN9ZQ3D0A	\N	f	099736	Miryan	Fernández Bedoya	f	t	2019-10-09 09:30:08.157629+00	2019-10-09 09:30:08.159884+00	2019-10-09 09:30:08.159898+00	miryfebe@yahoo.com.ar
101	argon2$argon2i$v=19$m=512,t=2,p=2$am8zVGR5SHVzY0U4$SBoqRsC8orETyzcCX4qiBQ	\N	f	1234567	Daniel	Bettera	f	t	2019-10-09 11:25:12.756246+00	2019-10-09 11:25:12.758422+00	2019-10-09 11:25:12.758436+00	dbettera@raffo.com.ar
102	argon2$argon2i$v=19$m=512,t=2,p=2$ME9uZmRoektOWmV6$Y36Ws2vOPtCzbEaBcCIeTQ	\N	f	141363	Maximiliano	Méndez Velazquez	f	t	2019-10-09 12:06:45.762167+00	2019-10-09 12:06:45.764357+00	2019-10-09 12:06:45.764384+00	maximendezv@gmail.com
103	argon2$argon2i$v=19$m=512,t=2,p=2$aGRpZ1lqZDU3RUMz$w2i3lUY0ivc8dKAFMUM/rA	\N	f	103583	Silvia Analia	Ybañez	f	t	2019-10-09 13:44:19.039593+00	2019-10-09 13:44:19.041739+00	2019-10-09 13:44:19.041754+00	silviaybanez@yahoo.com.ar
104	argon2$argon2i$v=19$m=512,t=2,p=2$VUxoS1lkOWc2ZFpF$o1JquRJRhcipbaVC9XjB2Q	\N	f	245685	Mariana	Rellan	f	t	2019-10-09 15:57:01.38612+00	2019-10-09 15:57:01.388308+00	2019-10-09 15:57:01.388322+00	mrellan@raffo.com.ar
105	argon2$argon2i$v=19$m=512,t=2,p=2$ZVF6bWR3VFBvSElE$gefuPwmIuvbQU8hcgtYqig	\N	f	000001	Diego	Posse	f	t	2019-10-09 16:28:26.420684+00	2019-10-09 16:28:26.422862+00	2019-10-09 16:28:26.422876+00	dposse@raffo.com.ar
106	argon2$argon2i$v=19$m=512,t=2,p=2$QllTbE05SExDQWg4$M2bdO5NgYcEdq1LNaziOHw	\N	f	25032127	Mariano	Galeano	f	t	2019-10-09 21:23:21.576583+00	2019-10-09 21:23:21.578799+00	2019-10-09 21:23:21.578813+00	mgaleano@raffo.com.ar
107	argon2$argon2i$v=19$m=512,t=2,p=2$VGl0TEVtSHh3UnBU$re67gflHFyfqiyCY8ZISUQ	\N	f	112074	Marina	Núñez	f	t	2019-10-09 21:42:51.442359+00	2019-10-09 21:42:51.444421+00	2019-10-09 21:42:51.444435+00	marina_gn@hotmail.com
108	argon2$argon2i$v=19$m=512,t=2,p=2$V2d1bE1zVW4yeG1a$j02PID0e6APea9R+RdxQkg	\N	f	093909	Juan Francisco	Delbés	f	t	2019-10-09 22:36:18.768768+00	2019-10-09 22:36:18.770965+00	2019-10-09 22:36:18.770991+00	franciscodelbes@hotmail.com.ar
109	argon2$argon2i$v=19$m=512,t=2,p=2$Y3FOYkR2Zm96YXJl$34kJc5J6Gr3ZZ+MfIWg/JQ	\N	f	002204	Fernando	Migliavaca	f	t	2019-10-10 00:16:50.662076+00	2019-10-10 00:16:50.664229+00	2019-10-10 00:16:50.664244+00	fmigliavaca@gmail.com
110	argon2$argon2i$v=19$m=512,t=2,p=2$cXJZRkgwMHVqUFl2$LlyCv7SZ6AuM/GKRkkiMzg	\N	f	111111111	Juan	Fruncillo	f	t	2019-10-10 12:20:44.131986+00	2019-10-10 12:20:44.134265+00	2019-10-10 12:20:44.134278+00	jfruncillo@raffo.com.ar
111	argon2$argon2i$v=19$m=512,t=2,p=2$T2pwVnFJWXc2dEV4$utBKiddW/KWt9FveOc1WlQ	\N	f	121212	Diego	Diotallevi	f	t	2019-10-10 12:44:16.941583+00	2019-10-10 12:44:16.943763+00	2019-10-10 12:44:16.943777+00	ddiotallevi@raffo.com.ar
112	argon2$argon2i$v=19$m=512,t=2,p=2$Q1BkQ2ZINEZudGhL$13E12fN81wgp6Ba6vNuwdQ	\N	f	003884	ana	irusta	f	t	2019-10-10 13:11:24.413107+00	2019-10-10 13:11:24.415328+00	2019-10-10 13:11:24.415341+00	a.irusta@hotmail.com
113	argon2$argon2i$v=19$m=512,t=2,p=2$YU5OQXBYZ3J1ckFB$CfbT7nVlskZOFj9yXM+cNQ	\N	f	1111111	Pablo	Perez	f	t	2019-10-10 13:17:49.184888+00	2019-10-10 13:17:49.187045+00	2019-10-10 13:17:49.18706+00	pperez@raffo.com.ar
114	argon2$argon2i$v=19$m=512,t=2,p=2$cjA1cVZDR05BR2dG$sFOwQegBilMIOl8ZdL+Htg	\N	f	200200	Alejandro	Pin	f	t	2019-10-10 13:57:57.892715+00	2019-10-10 13:57:57.894938+00	2019-10-10 13:57:57.894965+00	alejandropin@gmail.com
115	argon2$argon2i$v=19$m=512,t=2,p=2$NkliTzdpd2pjZVpm$SWJD5aKjxnwXhEfXhjf0PQ	\N	f	300300	Ale	Pin	f	t	2019-10-10 14:02:13.806459+00	2019-10-10 14:02:13.80876+00	2019-10-10 14:02:13.808774+00	pinpon@gmail.com
116	argon2$argon2i$v=19$m=512,t=2,p=2$Zjl0ZnJzOUVxU0FH$4IEkzrbiWS2TWF9nHPcQRw	\N	f	263200	Irene	Ojeda  Damico	f	t	2019-10-10 14:12:13.693078+00	2019-10-10 14:12:13.695363+00	2019-10-10 14:12:13.695377+00	ryod2003@gmail.com
117	argon2$argon2i$v=19$m=512,t=2,p=2$dnMzNUI1c1JGaUdU$KmNIvVTHpHFWvZdUvS2R7A	\N	f	122796	Gustavo	Martearena	f	t	2019-10-10 14:30:07.497081+00	2019-10-10 14:30:07.499295+00	2019-10-10 14:30:07.499309+00	gustavomartearena46@hotmail.com
118	argon2$argon2i$v=19$m=512,t=2,p=2$dGVRWTlkVGxpR2Yy$ai5tN7FDfCMXPQexXrG0+w	\N	f	123123123	Egar	Avila	f	t	2019-10-10 14:39:01.835746+00	2019-10-10 14:39:01.837913+00	2019-10-10 14:39:01.837928+00	eavila@raffo.com
119	argon2$argon2i$v=19$m=512,t=2,p=2$YzVwczQ2TFplN29u$LTB0uAlk7LjxBfaSjUbzYw	\N	f	92331568	Michel	Brun	f	t	2019-10-10 15:52:30.632554+00	2019-10-10 15:52:30.634753+00	2019-10-10 15:52:30.634766+00	cbrun@raffo.com.ar
120	argon2$argon2i$v=19$m=512,t=2,p=2$Q3dJOWU0bmZHaEtC$saWAuwZ13VhxwngAS64QQg	\N	f	111112	Hector	Silva	f	t	2019-10-10 16:43:25.923983+00	2019-10-10 16:43:25.926073+00	2019-10-10 16:43:25.926086+00	hsilva@raffo.com.ar
121	argon2$argon2i$v=19$m=512,t=2,p=2$WFJXTDhsVlBlb0pO$H5nAMWfmp0wwtsYHQsru2w	\N	f	310399	Juan	Pazos	f	t	2019-10-10 16:45:37.110713+00	2019-10-10 16:45:37.113003+00	2019-10-10 16:45:37.113017+00	jpazos@raffo.com.ar
122	argon2$argon2i$v=19$m=512,t=2,p=2$WUNza0lCamdmT0tF$9ake1RO4B7ekcOjvvZVixQ	\N	f	111845	Maria Paz	Martinez	f	t	2019-10-10 16:50:00.607474+00	2019-10-10 16:50:00.609681+00	2019-10-10 16:50:00.609695+00	mpazmartinez@hotmail.com
123	argon2$argon2i$v=19$m=512,t=2,p=2$bERXSFNxTjAxSWhM$evl+bSp5mIJTQwuvL6Nkzw	\N	f	094130	Andrea	Alebuena	f	t	2019-10-10 17:19:13.743381+00	2019-10-10 17:19:13.745602+00	2019-10-10 17:19:13.745616+00	andreahoracio@hotmail.com
124	argon2$argon2i$v=19$m=512,t=2,p=2$M1RYTkhEcnBIMXR1$kqIdxYPHSJJp7qHrg6ERxw	\N	f	1111111111	ANDRES	DALOISIO	f	t	2019-10-10 17:32:54.02343+00	2019-10-10 17:32:54.025482+00	2019-10-10 17:32:54.025497+00	adaloisio@raffo.com.ar
125	argon2$argon2i$v=19$m=512,t=2,p=2$eUJKWUtmZEg5ejBy$JL3eCuE9TSF4qkY7+6mBdg	\N	f	13245678	Pablo	Oviedo	f	t	2019-10-10 17:36:42.728449+00	2019-10-10 17:36:42.730585+00	2019-10-10 17:36:42.730599+00	aoviedo@raffo.com.ar
126	argon2$argon2i$v=19$m=512,t=2,p=2$bm1uMExyVHdpVk4w$BKVPbUESAeg7JC8t9UxE+w	\N	f	111115	Pablo	Ahumada	f	t	2019-10-10 18:14:59.385763+00	2019-10-10 18:14:59.38802+00	2019-10-10 18:14:59.388034+00	pahumada@raffo.com.ar
127	argon2$argon2i$v=19$m=512,t=2,p=2$TTRRN1o3T3FWQ2tu$dJRvNqEdZkz49WcjnGRoug	\N	f	210365	Walter	Sztrasberger	f	t	2019-10-10 18:56:27.736416+00	2019-10-10 18:56:27.738551+00	2019-10-10 18:56:27.738566+00	sztrasbw@hotmail.com
128	argon2$argon2i$v=19$m=512,t=2,p=2$elZ4RkNkeWFja0tO$eAeLPjCXC921xtIFhicUOA	\N	f	154800	Guillermo Javier	Acosta	f	t	2019-10-10 19:26:56.581314+00	2019-10-10 19:26:56.583563+00	2019-10-10 19:26:56.583577+00	guille_acosta@hotmail.com
129	argon2$argon2i$v=19$m=512,t=2,p=2$cE9IMHdXOFl3YmRz$X/HTlZq6aKzEsHPKSB1NpQ	\N	f	011451	Jaquelina	Giagnorio	f	t	2019-10-10 20:18:01.19237+00	2019-10-10 20:18:01.194513+00	2019-10-10 20:18:01.194527+00	jaquelinagiagnorio@gmail.com
130	argon2$argon2i$v=19$m=512,t=2,p=2$dGFPWUJEeDhVZmxU$3A3c7Bgo678gAcFOVzxnuQ	\N	f	11111111	Matias	Romero	f	t	2019-10-10 21:13:14.995784+00	2019-10-10 21:13:14.997952+00	2019-10-10 21:13:14.997967+00	maromero@raffo.com.ar
131	argon2$argon2i$v=19$m=512,t=2,p=2$N2ZFU3dNMU9CWDdL$qzVQAfDYe3SjpRq4aDBdgg	\N	f	654321	Sergio	D Angelo	f	t	2019-10-10 21:26:28.697266+00	2019-10-10 21:26:28.699452+00	2019-10-10 21:26:28.699479+00	Sdangelo@raffo.com.ar
132	argon2$argon2i$v=19$m=512,t=2,p=2$S0s1YjFSSXpOekNy$ppLDefEAr080Fe+1R+jweg	\N	f	004414	Andrea	Requena	f	t	2019-10-10 21:37:06.901242+00	2019-10-10 21:37:06.90342+00	2019-10-10 21:37:06.903434+00	andreq78@hotmail.com
133	argon2$argon2i$v=19$m=512,t=2,p=2$dG5saVc5emE2NHd2$RTT7xzQp/wx1lcxjVTlhxw	\N	f	236775	Maria graciela	Morales	f	t	2019-10-10 22:06:50.126659+00	2019-10-10 22:06:50.128981+00	2019-10-10 22:06:50.128995+00	moralesmedgral@yahoo.com.ar
134	argon2$argon2i$v=19$m=512,t=2,p=2$RXhrVU1LWmpQcFpa$i4XIVlEuRAHp+0UT7gVrCg	\N	f	094240	Marcos	Tomasi	f	t	2019-10-10 22:46:50.999571+00	2019-10-10 22:46:51.001783+00	2019-10-10 22:46:51.001798+00	marcostomasi@yahoo.com
135	argon2$argon2i$v=19$m=512,t=2,p=2$TmozYUo1ekNzSXpl$LLeK9rPNHSYS8IZ//X5q5A	\N	f	108203	Diego Francisco	Ramirez	f	t	2019-10-10 23:05:32.033729+00	2019-10-10 23:05:32.035943+00	2019-10-10 23:05:32.035957+00	dramirez@raffo.com
136	argon2$argon2i$v=19$m=512,t=2,p=2$blBxNnBtR0xkeGI1$ViHYZ/gQM2ug0swMdHmH1g	\N	f	101213	Fabian	Tessaro	f	t	2019-10-10 23:19:58.696884+00	2019-10-10 23:19:58.699101+00	2019-10-10 23:19:58.699116+00	ftessaro@raffo.com.ar
137	argon2$argon2i$v=19$m=512,t=2,p=2$bExzSXdKZllxYUFM$pmde106ezlhLIbjdhoTM0A	\N	f	555555	Claudia	D'amico	f	t	2019-10-11 01:35:17.228983+00	2019-10-11 01:35:17.23128+00	2019-10-11 01:35:17.231294+00	cldamico73@yahoo.com.ar
138	argon2$argon2i$v=19$m=512,t=2,p=2$d1YyeHhkQlNhQ0s1$Qdgfg/4cw+lS++WDsz6Rmg	\N	f	014692	Felipe	Fernández Álvarez	f	t	2019-10-11 01:37:37.929379+00	2019-10-11 01:37:37.93149+00	2019-10-11 01:37:37.931503+00	eldrfelipe@gmail.com
139	argon2$argon2i$v=19$m=512,t=2,p=2$YWpMaGUycG1kelYw$muVWr/6LnUV/HbFf2Ghw7g	\N	f	236037	Enrique	Majul	f	t	2019-10-11 01:42:51.959297+00	2019-10-11 01:42:51.961384+00	2019-10-11 01:42:51.961399+00	enriquemajul@gmail.com
140	argon2$argon2i$v=19$m=512,t=2,p=2$RjZRVmpaNGtDTURZ$+UUnACRM1blX7yfR6MO6dQ	\N	f	0094900	Facundo	Bonavita	f	t	2019-10-11 02:05:10.886208+00	2019-10-11 02:05:10.8884+00	2019-10-11 02:05:10.888414+00	facubonavita75@gmail.com
141	argon2$argon2i$v=19$m=512,t=2,p=2$SGExU3kxN1AzamdI$V55D0jfk6hdu6IXu1BntYg	\N	f	009599	Guillermina	Barrera	f	t	2019-10-11 02:30:36.060199+00	2019-10-11 02:30:36.062326+00	2019-10-11 02:30:36.062341+00	guillerminabarrera@hotmail.com
142	argon2$argon2i$v=19$m=512,t=2,p=2$RTFIQll3VFpoeWky$wDGWzswG9jkLRHtAZUh/9w	\N	f	012123	Roberto	Giordano	f	t	2019-10-11 02:52:15.887603+00	2019-10-11 02:52:15.889729+00	2019-10-11 02:52:15.889744+00	rgiordano@raffo.com.ar
143	argon2$argon2i$v=19$m=512,t=2,p=2$SGxWRWpoRmp1NFlG$MzwN/9XP9Y0CivxbrnefIg	\N	f	021050	Florencia	Cappiello	f	t	2019-10-11 03:12:19.675759+00	2019-10-11 03:12:19.67779+00	2019-10-11 03:12:19.677803+00	dra.cappiello@gmail.com
144	argon2$argon2i$v=19$m=512,t=2,p=2$d1V4ZHl2WXlyZXRR$tw9q4MvTWEdady1+/nY81w	\N	f	064241	Gabriela	Rodríguez	f	t	2019-10-11 03:12:49.776467+00	2019-10-11 03:12:49.778704+00	2019-10-11 03:12:49.778719+00	dragabi10@hotmail.com
145	argon2$argon2i$v=19$m=512,t=2,p=2$MEJJblp5MWs0NEkx$jg1Ao3FSDUJgDWt9UPiQ8A	\N	f	001196	Alicia	Roman	f	t	2019-10-11 04:42:39.399485+00	2019-10-11 04:42:39.401625+00	2019-10-11 04:42:39.401639+00	aliciaroman307@gmail.com
146	argon2$argon2i$v=19$m=512,t=2,p=2$cENRYVlQaXhTMG96$tfw2RjNdZnc8HnLgq0JmCg	\N	f	222222	Héctor	Menta	f	t	2019-10-11 10:52:42.287488+00	2019-10-11 10:52:42.289593+00	2019-10-11 10:52:42.289608+00	hmenta@raffo.com.ar
147	argon2$argon2i$v=19$m=512,t=2,p=2$Umg1UjZGSjRmRUxa$EfumaAH/tBjmWJ9mAJL0gw	\N	f	015189	Jorgelina	Barrera	f	t	2019-10-11 11:04:56.18954+00	2019-10-11 11:04:56.191701+00	2019-10-11 11:04:56.191716+00	jorgelinabarrera@hotmail.com
148	argon2$argon2i$v=19$m=512,t=2,p=2$c3ZSblpiNGZqMktw$QsfkD7iCgQj4Q/8Bemik4w	\N	f	417215	Federico	Repossi	f	t	2019-10-11 11:26:58.697303+00	2019-10-11 11:26:58.699487+00	2019-10-11 11:26:58.699501+00	frepossi@raffo.com.ar
149	argon2$argon2i$v=19$m=512,t=2,p=2$c2xDZkYzVlZFM0d0$rwzcXEgPCafPobLyJac4CA	\N	f	111113	Nicolas	Moyano	f	t	2019-10-11 11:53:00.893042+00	2019-10-11 11:53:00.895301+00	2019-10-11 11:53:00.895315+00	nmoyano@raffo.com.ar
150	argon2$argon2i$v=19$m=512,t=2,p=2$MzdSbmNydjN2NGQx$6YA1G9USjns1WuY3Lhc6pA	\N	f	21393152	Patricia Inés	Valencio	f	t	2019-10-11 12:05:12.422687+00	2019-10-11 12:05:12.424805+00	2019-10-11 12:05:12.424819+00	patovalencio@hotmail.com
151	argon2$argon2i$v=19$m=512,t=2,p=2$STNsME9ITUxsU3ZI$m/SabPsPE1efWpzbtjAmYA	\N	f	398253	Vanina	Castillo	f	t	2019-10-11 12:19:43.461777+00	2019-10-11 12:19:43.463941+00	2019-10-11 12:19:43.463955+00	vany_ck@yahoo.com.ar
152	argon2$argon2i$v=19$m=512,t=2,p=2$QXZxUGhOY1Z6WW40$mkdJyXQc30kAo9xVKOBA1w	\N	f	338046	Elena	Tripputi	f	t	2019-10-11 12:41:27.955969+00	2019-10-11 12:41:27.958143+00	2019-10-11 12:41:27.958157+00	elenatripputi@hotmail.com
153	argon2$argon2i$v=19$m=512,t=2,p=2$Q2JZdHd6V0E2cGI3$9Q8OlyVrweE4nwquC1g3KA	\N	f	057471	Graciela	Ortensi	f	t	2019-10-11 13:04:24.140795+00	2019-10-11 13:04:24.143028+00	2019-10-11 13:04:24.143042+00	gmortensi@gmail.com
154	argon2$argon2i$v=19$m=512,t=2,p=2$TkNwTkZNbzBUV3dG$QrYSEF8zIVsU76he5llmng	\N	f	124586	Lucas	Ghiano	f	t	2019-10-11 13:10:35.858353+00	2019-10-11 13:10:35.860545+00	2019-10-11 13:10:35.86056+00	lghiano@raffo.com.ar
155	argon2$argon2i$v=19$m=512,t=2,p=2$bUtqajd4YXk3b2Z5$kDd818IinSy5K0ui4g3O1w	\N	f	064682	María Luisa	Cordini	f	t	2019-10-11 13:26:14.983422+00	2019-10-11 13:26:14.985676+00	2019-10-11 13:26:14.98569+00	mlcordini@intrames.net
156	argon2$argon2i$v=19$m=512,t=2,p=2$WXFZOVJ5ZzdhRmJm$LaKUi17RA4HSqvqTyE1NVg	\N	f	091306	Valeria	Fernández Escudero	f	t	2019-10-11 13:53:05.043011+00	2019-10-11 13:53:05.04524+00	2019-10-11 13:53:05.045254+00	valeriafernandezescudero@gmail.com
157	argon2$argon2i$v=19$m=512,t=2,p=2$YUh2RUVxMThhZ2Mw$G45tKrWEW3bQUrS6fqTAfQ	\N	f	104489	Guadalupe	Vanoli	f	t	2019-10-11 14:15:34.517044+00	2019-10-11 14:15:34.519296+00	2019-10-11 14:15:34.519309+00	guadalupevanoli@gmail.com
158	argon2$argon2i$v=19$m=512,t=2,p=2$aG5vMUZjY00xNTdH$TMoKlTB0Y/8AiWRiUA0cfg	\N	f	136238	Paola	Martin	f	t	2019-10-11 15:47:29.383926+00	2019-10-11 15:47:29.386036+00	2019-10-11 15:47:29.386051+00	spminza@hotmail.com
159	argon2$argon2i$v=19$m=512,t=2,p=2$MW5wSENaQ2dic2NL$0+Jxc7L2KwhDg7yka4ZIaw	\N	f	118431	Nancy	Britez	f	t	2019-10-11 15:48:17.906127+00	2019-10-11 15:48:17.908449+00	2019-10-11 15:48:17.908464+00	dranancybritez@gmail.com
160	argon2$argon2i$v=19$m=512,t=2,p=2$TTFSclZDTlBqSXI3$rwclOSUkMGwEiaiENK1ISA	\N	f	070282	Alejandra	Buedo	f	t	2019-10-11 17:25:55.897033+00	2019-10-11 17:25:55.89933+00	2019-10-11 17:25:55.899344+00	abuedo@intramed.net
161	argon2$argon2i$v=19$m=512,t=2,p=2$Um51YTRuV3hWaEVz$wkfk9SNyy6jS+HSf9lGzZA	\N	f	335138	Mauro	Grossmann	f	t	2019-10-11 18:10:17.207877+00	2019-10-11 18:10:17.210102+00	2019-10-11 18:10:17.210115+00	drmaurogrossmann@hotmail.com
162	argon2$argon2i$v=19$m=512,t=2,p=2$dlRmWXdaYzNPdU9l$EYg6CyZIrQGTSqWKlKMQjA	\N	f	217600	Gustavo	Pepe	f	t	2019-10-11 18:15:45.711592+00	2019-10-11 18:15:45.713736+00	2019-10-11 18:15:45.713751+00	gustapepe@gmail.com
163	argon2$argon2i$v=19$m=512,t=2,p=2$MjVQSHkwOUxxN3hC$1rNlN6GBGLWxqdtYfGAUzw	\N	f	166666	Hugo	Román	f	t	2019-10-11 20:03:12.966184+00	2019-10-11 20:03:12.968341+00	2019-10-11 20:03:12.968355+00	hroman@raffo.com.ar
164	argon2$argon2i$v=19$m=512,t=2,p=2$Ym9odzVTT3RPbnU3$6NJA/2qP1Wh7XJXk65nCtA	\N	f	080700	Fabio	Zambon	f	t	2019-10-12 00:09:14.376331+00	2019-10-12 00:09:14.378509+00	2019-10-12 00:09:14.378524+00	fzambon@gmail.com
165	argon2$argon2i$v=19$m=512,t=2,p=2$M2RDczQwT1dpamZD$6srDdyO5df5Stm0roZEd1Q	\N	f	111163	Sergio	Mainini	f	t	2019-10-12 07:27:31.586512+00	2019-10-12 07:27:31.588725+00	2019-10-12 07:27:31.588744+00	sergio.mainini11@gmail.com
166	argon2$argon2i$v=19$m=512,t=2,p=2$VXRsSWh2cWFoelRh$v2wJ0jc7kKi4Jxgbp98xrQ	\N	f	22576679	Miguel	Otero	f	t	2019-10-12 11:37:53.102409+00	2019-10-12 11:37:53.104755+00	2019-10-12 11:37:53.104769+00	miotero@raffo.com.ar
167	argon2$argon2i$v=19$m=512,t=2,p=2$S0E5M3lNVDdwbERs$izKo37xgC8V18V63PVzvjw	\N	f	0295091	Lorena Del Valle	Tosi	f	t	2019-10-14 13:54:39.788062+00	2019-10-14 13:54:39.792931+00	2019-10-14 13:54:39.792945+00	lorenatosi@hotmail.com.ar
168	argon2$argon2i$v=19$m=512,t=2,p=2$anVNUDFYbTJsYjVm$Rh6ePwUprgFi2OBn6dCYQQ	\N	f	088935	Gabriela	Del Giudice	f	t	2019-10-14 14:38:53.635287+00	2019-10-14 14:38:53.637367+00	2019-10-14 14:38:53.637382+00	gjdelgiudice@gmail.com
189	argon2$argon2i$v=19$m=512,t=2,p=2$dU5FblBnYlFNTGdL$0VVTiF8Ua7gpJlgpX0/OLw	\N	f	777777	Cecilia	Pucci	f	t	2019-10-14 23:03:26.428309+00	2019-10-14 23:03:26.430438+00	2019-10-14 23:03:26.430452+00	cpucci@raffo.com.ar
191	argon2$argon2i$v=19$m=512,t=2,p=2$bHFRbzNwNXN3UURV$YUID+vNes3PbDh3NUaoOGQ	\N	f	006015	María Lourdes	Loutayf Teran	f	t	2019-10-15 15:29:57.163577+00	2019-10-15 15:29:57.165743+00	2019-10-15 15:29:57.165758+00	lourdesloutayf@gmail.com
192	argon2$argon2i$v=19$m=512,t=2,p=2$MlphNUVIaTVTWGR4$Mx6f+nbOLzVQh1QYtpnZjQ	\N	f	011111	Mariana	Grabuska	f	t	2019-10-15 16:09:48.275487+00	2019-10-15 16:09:48.277623+00	2019-10-15 16:09:48.277638+00	marianagrabuska@hotmail.com
193	argon2$argon2i$v=19$m=512,t=2,p=2$WVJmcU9DRHZuNUEy$whOGfoudgTNPaEqiTLk/2w	\N	f	014129	Gabriel	Miri	f	t	2019-10-15 16:53:49.336844+00	2019-10-15 16:53:49.33904+00	2019-10-15 16:53:49.339054+00	gapami@hotmail.com
194	argon2$argon2i$v=19$m=512,t=2,p=2$SFg2SURkUDF2d2d1$v/nCfY99IE9xzBeqwrZ84g	\N	f	036706	Luis	Ovando	f	t	2019-10-15 21:27:33.907275+00	2019-10-15 21:27:33.909455+00	2019-10-15 21:27:33.90947+00	heloovando@hotmail.com
195	argon2$argon2i$v=19$m=512,t=2,p=2$OGdLa2p0U0tqaUxs$6ajPH+jvektaM3mLawNOTg	\N	f	092192	Roberto	Adamow	f	t	2019-10-15 22:42:50.235461+00	2019-10-15 22:42:50.237481+00	2019-10-15 22:42:50.237494+00	docadamow@gmail.com
196	argon2$argon2i$v=19$m=512,t=2,p=2$QVprMUJXaUh2RHNH$CXGEnOGdnYDVw8uFVEZ0Kw	\N	f	447206	Federico	Etchegoyen	f	t	2019-10-16 17:02:35.143319+00	2019-10-16 17:02:35.149322+00	2019-10-16 17:02:35.149336+00	federico.etchegoyen@gmail.com
197	argon2$argon2i$v=19$m=512,t=2,p=2$WVR3ZXU0ZVV0NFg5$HJA9s7+m3o1WgvCU7tES3w	\N	f	070645	Roxana	Galvano	f	t	2019-10-16 23:37:10.479161+00	2019-10-16 23:37:10.481249+00	2019-10-16 23:37:10.481264+00	rgalvano@intramed.net
198	argon2$argon2i$v=19$m=512,t=2,p=2$SUQwZkQxeXFIaGYy$dzA7O7YrsJt3MBRSAvZ/Iw	\N	f	141050	Micaela	Herrero	f	t	2019-10-17 03:05:24.433721+00	2019-10-17 03:05:24.435901+00	2019-10-17 03:05:24.435915+00	micaelaherrero@hotmail.com
199	argon2$argon2i$v=19$m=512,t=2,p=2$ZmxiWFphM0czamtt$kRHYeHUWObQ0kqy23qenbQ	\N	f	111110	Sergio	Campi	f	t	2019-10-17 11:59:34.810523+00	2019-10-17 11:59:34.812581+00	2019-10-17 11:59:34.812595+00	sergiocampi@hotmail.com
200	argon2$argon2i$v=19$m=512,t=2,p=2$V20zbWVCbHhpNFI2$E2F7bdyINGb9M1K9xWRZpw	\N	f	026891	Maria Delia	Palacio	f	t	2019-10-17 16:21:32.063041+00	2019-10-17 16:21:32.065174+00	2019-10-17 16:21:32.065188+00	deliapalacio@yahoo.com
201	argon2$argon2i$v=19$m=512,t=2,p=2$c2hpQ2Q4TkdUTEs3$XB8Wu1QK0OllaOEUogGsNw	\N	f	109779	Laura	Pelayo	f	t	2019-10-17 18:02:29.758843+00	2019-10-17 18:02:29.760959+00	2019-10-17 18:02:29.760973+00	lauranairpelayo@gmail.com
202	argon2$argon2i$v=19$m=512,t=2,p=2$dnp6dEpjanIyZ0Vr$1aVxOvtNEk41WgCq7YJd2w	\N	f	174013	Rubén	Insurralde	f	t	2019-10-17 18:27:58.757199+00	2019-10-17 18:27:58.759414+00	2019-10-17 18:27:58.759428+00	ruben_insa@outlook.es
203	argon2$argon2i$v=19$m=512,t=2,p=2$R0xYTTRBNlM1ekpl$rdt0F9EDgmeZHmXMD6EV2Q	\N	f	328519	Ariel	Pereyra	f	t	2019-10-17 23:50:47.625016+00	2019-10-17 23:50:47.627218+00	2019-10-17 23:50:47.627231+00	arielpereyra_790@hotmail.com
204	argon2$argon2i$v=19$m=512,t=2,p=2$Rnp5b0FMaVE4SnQ5$ASu/CfdQjKYrdEUmR87h8g	\N	f	081479	Juan Ignacio	Giovaneli	f	t	2019-10-18 15:41:48.333021+00	2019-10-18 15:41:48.335289+00	2019-10-18 15:41:48.335304+00	jgiovaneli@raffo.com.ar
205	argon2$argon2i$v=19$m=512,t=2,p=2$S3FoYUd1akd1WGND$nId9bu34Uz4rTuyY0lQ8lg	\N	f	110590	Paola Andrea	Di Francesco	f	t	2019-10-19 15:24:55.710821+00	2019-10-19 15:24:55.712936+00	2019-10-19 15:24:55.712951+00	drapaoladifrancesco@gmail.com
206	argon2$argon2i$v=19$m=512,t=2,p=2$VGNVNExHbFN3Z2tz$pYwNdxULVprNSWuXg1VGfg	\N	f	144343	Mariela	Caraballo	f	t	2019-10-19 18:12:56.856246+00	2019-10-19 18:12:56.858466+00	2019-10-19 18:12:56.858481+00	dramarielacd@gmail.com
207	argon2$argon2i$v=19$m=512,t=2,p=2$RDlScWtJdXFLd2hq$rhQkg3tGoOW8NruvPYrVew	\N	f	024308	Maria Eugenia	Biancciogti	f	t	2019-10-19 20:48:44.973733+00	2019-10-19 20:48:44.975966+00	2019-10-19 20:48:44.97598+00	eugeniabiancciotti@holmai.com
208	argon2$argon2i$v=19$m=512,t=2,p=2$RUhkbnh4eTZMcURv$LlqekxCbSz4QiD1O0Ag3Vw	\N	f	115396	Myriam	Rotondo	f	t	2019-10-20 22:48:54.367671+00	2019-10-20 22:48:54.369737+00	2019-10-20 22:48:54.369751+00	myriam.rotondo@gmail.com
209	argon2$argon2i$v=19$m=512,t=2,p=2$OVBmdmxwV3FLVzBC$i7705MHptb/Lt5B7qjZAqw	\N	f	096364	Silvina	Bilicich	f	t	2019-10-21 18:16:13.482952+00	2019-10-21 18:16:13.486631+00	2019-10-21 18:16:13.486646+00	silvinabilicich@gmail.com
210	argon2$argon2i$v=19$m=512,t=2,p=2$UzZRQlRoVmpLcU1n$r7kpfYVw5ZfyhSPOwsW7Cw	\N	f	002581	Cintia	Abate	f	t	2019-10-22 15:25:14.79258+00	2019-10-22 15:25:14.794735+00	2019-10-22 15:25:14.794751+00	cintiaa21@hotmail.com
211	argon2$argon2i$v=19$m=512,t=2,p=2$cjJGZjBGbWVWbVJB$AB1sl7XQ9MP7KQlzmob0+w	\N	f	021534	Maria Eugenia	Estario	f	t	2019-10-22 20:02:12.191933+00	2019-10-22 20:02:12.194052+00	2019-10-22 20:02:12.194066+00	meestario@gmail.com
212	argon2$argon2i$v=19$m=512,t=2,p=2$T3EzUVNocVQ2b2Fq$G1ui+sZ9XCRAv94rM2kP7g	\N	f	072535	Iluminada Estrella	Menendez	f	t	2019-10-23 12:29:18.939827+00	2019-10-23 12:29:18.941998+00	2019-10-23 12:29:18.942013+00	estrellamenendez@yahoo.com
213	argon2$argon2i$v=19$m=512,t=2,p=2$Rk0wanE0WU5kRFZw$nGoBORd+7YzvgkA1hcbHug	\N	f	133415	Valeria	Zlotnitzky	f	t	2019-10-23 15:19:01.23221+00	2019-10-23 15:19:01.234408+00	2019-10-23 15:19:01.234423+00	valezlot@gmail.com
214	argon2$argon2i$v=19$m=512,t=2,p=2$U1NwalAxRVIxcUNZ$W/6YVBVzN8N1Y20LisbTow	\N	f	015284	juliana	ALBERT	f	t	2019-10-23 20:25:49.19162+00	2019-10-23 20:25:49.193694+00	2019-10-23 20:25:49.193708+00	julyalbert@hotmail.com
215	argon2$argon2i$v=19$m=512,t=2,p=2$dkpmbVFVY3J3VEtk$++zWkHiW+OMNrd+5VNoAEg	\N	f	002260	Lorena	Brocal	f	t	2019-10-23 20:38:51.408919+00	2019-10-23 20:38:51.411131+00	2019-10-23 20:38:51.411145+00	lorebrocal80@gmail.com
216	argon2$argon2i$v=19$m=512,t=2,p=2$OUJJM1Rtd09pVTNI$V8hcRBBoQdNdc8xJNgD8kg	\N	f	016333	Aldana	Ianni	f	t	2019-10-23 20:58:09.308409+00	2019-10-23 20:58:09.310596+00	2019-10-23 20:58:09.310611+00	alduianni_76@hotmail.com
217	argon2$argon2i$v=19$m=512,t=2,p=2$RmNNUGR1cGFjRG1y$QblpmoGdIy5etlmtuehLhg	\N	f	568093	Lourdes	Bustos	f	t	2019-10-24 03:47:04.298682+00	2019-10-24 03:47:04.300755+00	2019-10-24 03:47:04.30077+00	lulubustos@hotmail.com
218	argon2$argon2i$v=19$m=512,t=2,p=2$TUE3OFNnb3Q2Qmxa$RKcYgaynSXq5QhWoPNno5g	\N	f	020263	Carlos Daniel	Ostorero	f	t	2019-10-24 11:36:19.169177+00	2019-10-24 11:36:19.171375+00	2019-10-24 11:36:19.171389+00	ostorerodaniel@gmail.com
219	argon2$argon2i$v=19$m=512,t=2,p=2$bGhtZVVhZXVsRDhx$XCs+u1rWXjtch94M7BwWAw	\N	f	069064	Jose	Soler	f	t	2019-10-24 17:40:50.56+00	2019-10-24 17:40:50.562199+00	2019-10-24 17:40:50.56224+00	drjosemsoler@gmail.com
220	argon2$argon2i$v=19$m=512,t=2,p=2$SFdvOURJbnp1YVUy$IiXDlpoSCRMMnbt7xMDsPg	\N	f	002938	Jorge Omar	Rivero	f	t	2019-10-25 15:14:53.209109+00	2019-10-25 15:14:53.220491+00	2019-10-25 15:14:53.220507+00	jorgeomarrivero@yahoo.com.ar
221	argon2$argon2i$v=19$m=512,t=2,p=2$bE54dTZGeVlPSUE2$FEV1qMgTlV3RLz4KO5ck/w	\N	f	011937	Marcelo	Mariño	f	t	2019-10-26 17:18:41.020774+00	2019-10-26 17:18:41.022901+00	2019-10-26 17:18:41.022916+00	drmarinomarcelo@icloud.com
1	argon2$argon2i$v=19$m=512,t=2,p=2$TXMyQWhWNmpDTWt5$7OONtAVUkLO4Vx11VZe5vQ	2019-10-28 15:51:02.345615+00	t	ducode	alejandro	duque	t	t	2019-08-31 04:38:02.759403+00	2019-08-31 04:38:02.772768+00	2019-08-31 04:38:02.772784+00	ducode@outlook.com
222	argon2$argon2i$v=19$m=512,t=2,p=2$S3hJTFZNb1Z5SXdq$cEEV3TZh5FFw946FFL22Gg	\N	f	002407	Jose David	Acevedo	f	t	2019-10-28 16:47:00.214111+00	2019-10-28 16:47:00.216302+00	2019-10-28 16:47:00.216327+00	jdavidacevedoctes@gmail.com
223	argon2$argon2i$v=19$m=512,t=2,p=2$QmkxbzFRTGpEWUxl$4G7P+rD+DVJ5FS3mjxvvpA	\N	f	019406	Eduardo Héctor	Caminos	f	t	2019-10-28 17:46:46.584914+00	2019-10-28 17:46:46.587074+00	2019-10-28 17:46:46.587089+00	camimos.eduardo@gmail.com
224	argon2$argon2i$v=19$m=512,t=2,p=2$Z2Y1eTlZSVpkQ3k2$QJPvtlH70u4U3CT7Wztf8A	\N	f	89737629057	Ruben	Felicetti	f	t	2019-10-28 18:02:05.076347+00	2019-10-28 18:02:05.078582+00	2019-10-28 18:02:05.078597+00	rfelicetti@raffo.com.ar
225	argon2$argon2i$v=19$m=512,t=2,p=2$dFhBbnR5SWdLVUZ4$3WG3naMaQBHxcp5fZJFoqw	\N	f	026927	Roberto Federico	Viano	f	t	2019-10-28 18:36:20.231166+00	2019-10-28 18:36:20.233271+00	2019-10-28 18:36:20.233286+00	fedeviano@hotmail.com
226	argon2$argon2i$v=19$m=512,t=2,p=2$SkFkazRJVW94UHdr$gKjVkdFch//Em6UOIGy+qQ	\N	f	064618	Santiago	Tobin	f	t	2019-10-28 18:49:59.139465+00	2019-10-28 18:49:59.141598+00	2019-10-28 18:49:59.141612+00	santiago_tobin@hotmail.com
227	argon2$argon2i$v=19$m=512,t=2,p=2$NVFna2hXVzdXNEkz$Gr5E/1F1CctHmfE8Gq9lEw	\N	f	228237	Dario	Amoruso	f	t	2019-10-28 18:51:42.576316+00	2019-10-28 18:51:42.578431+00	2019-10-28 18:51:42.578445+00	dramoruso@yahoo.com.ar
228	argon2$argon2i$v=19$m=512,t=2,p=2$Y3pPVjJJVFBhWEpL$Ast9ugH+Qa5CMypie+AmNg	\N	f	227274	Micaela	Ramirez	f	t	2019-10-28 19:21:26.859645+00	2019-10-28 19:21:26.861778+00	2019-10-28 19:21:26.861791+00	micasramirez@yahoo.com.ar
\.


--
-- Data for Name: users_user_groups; Type: TABLE DATA; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

COPY public.users_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: users_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

COPY public.users_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Data for Name: visits_firstvisitcomplementinformation; Type: TABLE DATA; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

COPY public.visits_firstvisitcomplementinformation (id, created, modified, depresion_mayor, otros_transtornos, hta_no_controlada, tratamiento_hipoglucemiantes, convulsiones, factores_predisponentes, anorexia, abuso_alcohol, tratamiento_actual, embarazo, glaucoma, tratamiento_beta_bloqueantes, actividad_fisica, dieta_hipocalorica, palpitaciones_aumento_fc, intolerancia_lactosa, tratamiento_levodopa, funcion_renal, alergia_naltrexona, insuficiencia_hepatica, visit_id, cirugia_planificada) FROM stdin;
258	2019-09-11 22:48:12.780136+00	2019-09-11 22:48:12.780161+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	293	f
259	2019-09-11 23:10:08.913908+00	2019-09-11 23:10:08.913931+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	330	f
260	2019-09-12 21:33:30.538034+00	2019-09-12 21:33:30.538059+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	332	f
261	2019-09-12 21:41:54.878724+00	2019-09-12 21:41:54.878751+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	337	f
262	2019-09-13 00:47:13.992764+00	2019-09-13 00:47:13.992789+00	f	f	f	f	t	t	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	341	f
263	2019-09-13 00:48:16.220783+00	2019-09-13 00:48:16.220811+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	normal	f	moderada	342	f
264	2019-09-13 00:49:07.290435+00	2019-09-13 00:49:07.290462+00	f	f	f	f	f	f	f	f	f	f	f	f	uno-dos	t	f	f	f	normal	f	no	343	f
265	2019-09-13 16:20:14.902146+00	2019-09-13 16:20:14.902172+00	f	f	f	f	f	f	f	f	f	f	f	f	uno-dos	f	f	f	f	normal	f	no	345	f
266	2019-09-13 16:35:05.374687+00	2019-09-13 16:35:05.374714+00	t	f	f	t	f	f	f	t	f	f	t	f	tres-mas	f	f	f	f	normal	f	leve	348	f
267	2019-09-14 00:49:52.697105+00	2019-09-14 00:49:52.697132+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	349	f
268	2019-09-15 17:59:10.372292+00	2019-09-15 17:59:10.372317+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	351	f
269	2019-09-15 19:13:37.080081+00	2019-09-15 19:13:37.080105+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	354	f
270	2019-09-15 19:29:39.727405+00	2019-09-15 19:29:39.72743+00	f	f	f	f	f	t	f	f	f	f	f	f	no	t	f	f	f	leve	f	leve	357	f
271	2019-09-16 00:00:32.016038+00	2019-09-16 00:00:32.016066+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	leve	f	no	364	f
272	2019-09-16 00:09:31.127404+00	2019-09-16 00:09:31.12743+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	366	f
273	2019-09-16 18:46:01.434814+00	2019-09-16 18:46:01.434842+00	t	f	f	f	f	f	f	f	f	f	f	f	uno-dos	f	f	f	f	normal	f	no	368	f
274	2019-09-16 18:47:33.394012+00	2019-09-16 18:47:33.394038+00	f	f	f	f	f	f	f	f	f	f	f	f	uno-dos	f	f	f	f	normal	f	no	369	f
275	2019-09-16 19:00:57.131993+00	2019-09-16 19:00:57.13202+00	f	f	t	t	f	f	f	f	f	f	f	f	tres-mas	t	f	f	f	normal	f	no	372	f
276	2019-09-16 19:07:47.867898+00	2019-09-16 19:07:47.867924+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	373	f
277	2019-09-17 20:36:12.334393+00	2019-09-17 20:36:12.334421+00	f	f	f	f	f	f	f	f	f	f	f	f	no	t	f	f	f	normal	f	no	375	f
278	2019-09-17 20:38:21.624041+00	2019-09-17 20:38:21.624068+00	f	f	f	t	f	f	f	f	f	f	f	f	no	t	f	f	f	normal	f	no	376	f
279	2019-09-18 14:46:48.783518+00	2019-09-18 14:46:48.783546+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	371	f
280	2019-09-18 20:37:47.123169+00	2019-09-18 20:37:47.123208+00	f	f	f	f	f	f	f	f	f	f	f	f	uno-dos	f	f	f	t	leve	f	no	378	f
281	2019-09-20 14:40:18.26801+00	2019-09-20 14:40:18.268035+00	f	f	f	f	f	f	f	f	f	f	f	f	uno-dos	f	f	f	f	normal	f	no	379	f
286	2019-09-29 13:36:37.571395+00	2019-09-29 13:36:37.571422+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	397	t
287	2019-09-29 13:40:47.414269+00	2019-09-29 13:40:47.414293+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	398	f
288	2019-09-29 13:44:48.080548+00	2019-09-29 13:44:48.080574+00	f	f	f	f	f	f	f	t	t	f	f	f	no	f	f	f	f	normal	f	no	400	f
289	2019-09-29 13:47:01.859468+00	2019-09-29 13:47:01.859495+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	401	f
290	2019-09-30 03:28:06.356085+00	2019-09-30 03:28:06.356112+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	386	f
293	2019-09-30 18:18:21.963085+00	2019-09-30 18:18:21.963111+00	f	f	f	f	f	f	f	f	t	f	f	f	no	f	f	f	f	normal	f	no	387	t
294	2019-09-30 18:28:41.531469+00	2019-09-30 18:28:41.531496+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	407	f
296	2019-10-01 04:55:19.077655+00	2019-10-01 04:55:19.077682+00	f	f	f	f	f	f	f	t	f	f	f	f	no	f	f	f	f	normal	f	no	411	f
297	2019-10-01 19:24:26.288351+00	2019-10-01 19:24:26.288378+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	412	f
298	2019-10-01 19:25:13.309968+00	2019-10-01 19:25:13.309995+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	413	f
300	2019-10-03 01:06:56.005797+00	2019-10-03 01:06:56.005824+00	f	f	f	t	f	t	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	416	f
301	2019-10-03 01:53:27.797566+00	2019-10-03 01:53:27.797592+00	f	f	f	t	f	t	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	418	f
302	2019-10-03 01:59:35.776472+00	2019-10-03 01:59:35.776496+00	f	f	f	t	f	t	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	420	f
303	2019-10-03 02:07:09.765111+00	2019-10-03 02:07:09.765138+00	f	f	f	t	f	t	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	421	f
304	2019-10-03 02:19:38.880028+00	2019-10-03 02:19:38.880054+00	f	f	f	t	f	t	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	424	f
305	2019-10-05 11:33:50.858853+00	2019-10-05 11:33:50.858885+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	425	f
306	2019-10-07 14:50:31.501237+00	2019-10-07 14:50:31.501264+00	f	f	f	f	f	f	f	f	f	f	f	f	uno-dos	f	f	f	f	normal	f	no	428	f
307	2019-10-07 14:53:51.693869+00	2019-10-07 14:53:51.694054+00	f	f	f	t	f	f	f	f	f	f	f	f	uno-dos	f	f	f	f	normal	f	no	430	f
308	2019-10-07 20:41:59.607499+00	2019-10-07 20:41:59.607525+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	432	f
309	2019-10-08 02:39:49.173451+00	2019-10-08 02:39:49.173477+00	f	f	f	f	f	f	f	f	f	f	f	f	tres-mas	t	f	f	f	normal	f	leve	435	f
310	2019-10-08 11:39:44.303639+00	2019-10-08 11:39:44.303665+00	f	f	f	f	f	f	f	f	f	f	f	f	uno-dos	t	f	f	f	normal	f	no	437	t
311	2019-10-08 11:44:46.939729+00	2019-10-08 11:44:46.939754+00	f	f	f	f	f	f	f	f	f	f	f	f	tres-mas	f	f	f	f	normal	f	no	438	f
312	2019-10-08 19:15:37.984028+00	2019-10-08 19:15:37.984054+00	f	f	f	f	f	f	f	f	f	f	f	f	tres-mas	t	f	f	f	normal	f	no	439	f
313	2019-10-08 19:16:26.23416+00	2019-10-08 19:16:26.234187+00	f	f	f	f	f	f	f	f	f	f	f	f	uno-dos	f	f	f	f	leve	f	no	440	f
314	2019-10-08 19:38:41.58517+00	2019-10-08 19:38:41.585195+00	f	f	f	f	f	f	f	f	f	f	f	f	uno-dos	t	f	f	f	normal	f	no	442	f
315	2019-10-08 19:54:35.782863+00	2019-10-08 19:54:35.782889+00	f	f	f	f	f	f	f	f	f	f	f	f	tres-mas	f	f	f	f	normal	f	no	444	f
316	2019-10-08 22:06:43.885742+00	2019-10-08 22:06:43.885773+00	f	f	f	t	f	f	f	f	f	f	f	f	tres-mas	f	t	f	f	normal	f	no	447	f
317	2019-10-09 01:10:48.606353+00	2019-10-09 01:10:48.606393+00	f	f	t	f	f	f	f	f	f	f	f	f	uno-dos	t	f	f	f	normal	f	no	448	f
318	2019-10-09 12:55:18.612562+00	2019-10-09 12:55:18.612588+00	f	f	f	f	f	f	f	f	f	f	f	f	tres-mas	t	f	f	t	normal	f	no	450	f
319	2019-10-09 13:49:32.055824+00	2019-10-09 13:49:32.05585+00	f	f	f	f	f	t	t	f	f	f	f	t	no	f	t	t	f	leve	f	leve	451	f
320	2019-10-09 21:51:19.660689+00	2019-10-09 21:51:19.660716+00	f	f	f	f	f	f	f	f	f	f	f	f	uno-dos	t	f	f	f	normal	f	no	452	f
321	2019-10-09 22:23:32.296612+00	2019-10-09 22:23:32.296639+00	f	f	f	f	f	f	f	f	f	f	f	f	tres-mas	t	f	f	f	normal	f	no	453	f
322	2019-10-10 12:24:16.241806+00	2019-10-10 12:24:16.241831+00	f	f	f	t	f	f	f	f	f	f	f	t	uno-dos	f	t	f	t	normal	f	no	455	f
323	2019-10-10 12:56:05.135368+00	2019-10-10 12:56:05.135393+00	f	f	f	f	f	f	f	f	f	f	f	f	tres-mas	f	f	f	f	normal	f	no	458	f
324	2019-10-10 13:35:52.565993+00	2019-10-10 13:35:52.56602+00	f	f	f	f	f	f	f	f	f	f	f	f	no	t	f	f	f	normal	f	no	459	f
325	2019-10-10 14:33:44.855736+00	2019-10-10 14:33:44.855763+00	f	t	f	f	f	f	f	f	f	f	f	f	uno-dos	t	f	f	f	normal	f	no	460	f
326	2019-10-10 16:46:43.82803+00	2019-10-10 16:46:43.828055+00	f	t	t	f	f	f	f	t	f	f	f	f	no	f	t	f	f	leve	f	leve	464	f
327	2019-10-10 19:14:57.535627+00	2019-10-10 19:14:57.535654+00	f	f	f	f	f	f	f	f	f	f	f	t	tres-mas	f	f	t	t	normal	f	no	467	f
328	2019-10-10 21:15:34.440392+00	2019-10-10 21:15:34.440418+00	f	f	f	f	f	f	f	f	f	f	f	f	tres-mas	f	f	f	f	normal	f	no	468	f
329	2019-10-10 21:28:40.955622+00	2019-10-10 21:28:40.955649+00	t	f	t	t	f	f	f	f	f	f	f	t	no	f	f	f	f	leve	f	no	469	f
330	2019-10-10 21:31:42.708148+00	2019-10-10 21:31:42.708174+00	f	f	f	t	f	f	f	f	f	f	f	f	no	f	f	f	f	leve	f	no	470	f
331	2019-10-10 22:10:35.865898+00	2019-10-10 22:10:35.865923+00	f	f	f	f	f	f	f	f	f	f	f	f	no	t	f	f	f	normal	f	no	471	f
332	2019-10-11 04:47:56.49438+00	2019-10-11 04:47:56.494408+00	f	f	f	f	f	f	f	f	t	f	f	f	tres-mas	t	f	f	t	normal	f	no	475	f
333	2019-10-11 08:21:12.387961+00	2019-10-11 08:21:12.387987+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	476	f
334	2019-10-11 11:58:24.104751+00	2019-10-11 11:58:24.104778+00	f	f	f	f	f	f	f	f	f	f	f	f	uno-dos	f	f	f	f	normal	f	no	479	f
335	2019-10-11 12:55:59.838469+00	2019-10-11 12:55:59.838496+00	f	f	f	t	f	f	f	f	f	f	f	f	uno-dos	f	f	f	f	normal	f	no	481	f
336	2019-10-11 13:20:33.117966+00	2019-10-11 13:20:33.117993+00	f	f	f	f	f	f	f	f	f	f	f	t	uno-dos	t	f	f	f	normal	f	no	482	f
337	2019-10-11 14:19:46.263189+00	2019-10-11 14:19:46.263214+00	f	f	f	f	f	f	f	f	f	f	f	f	uno-dos	t	f	f	f	normal	f	no	483	f
338	2019-10-11 14:21:03.56145+00	2019-10-11 14:21:03.561477+00	f	f	f	f	f	f	f	f	t	f	f	f	uno-dos	f	f	f	f	normal	f	no	484	f
339	2019-10-11 14:26:43.912903+00	2019-10-11 14:26:43.91293+00	f	f	f	f	f	f	f	f	f	f	f	f	tres-mas	t	f	f	f	normal	f	no	486	f
340	2019-10-11 15:27:17.055401+00	2019-10-11 15:27:17.055428+00	f	f	f	f	f	f	f	f	f	f	f	f	tres-mas	t	f	f	f	normal	f	no	487	f
341	2019-10-11 16:12:02.712974+00	2019-10-11 16:12:02.713+00	t	f	t	f	f	f	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	490	f
342	2019-10-11 18:19:47.300549+00	2019-10-11 18:19:47.300588+00	f	f	f	f	f	f	f	f	f	f	f	t	no	f	f	f	t	normal	f	no	491	f
343	2019-10-11 19:00:16.721886+00	2019-10-11 19:00:16.721912+00	f	f	f	f	f	f	f	f	f	f	f	f	uno-dos	f	f	f	f	normal	f	no	493	f
344	2019-10-11 19:03:00.1066+00	2019-10-11 19:03:00.106625+00	f	f	f	f	f	f	f	f	f	f	f	f	uno-dos	f	f	f	f	normal	f	no	492	f
345	2019-10-11 20:34:39.478525+00	2019-10-11 20:34:39.478551+00	f	f	f	f	f	f	f	f	f	f	f	f	uno-dos	f	f	f	f	normal	f	no	496	f
346	2019-10-12 00:12:10.440928+00	2019-10-12 00:12:10.440956+00	f	f	f	t	f	t	f	f	f	f	f	f	no	t	t	f	f	leve	f	no	497	f
347	2019-10-12 11:48:27.409273+00	2019-10-12 11:48:27.4093+00	f	f	f	f	f	f	f	f	f	f	f	f	tres-mas	f	f	f	f	normal	f	no	499	f
348	2019-10-12 11:52:11.231694+00	2019-10-12 11:52:11.231721+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	500	f
349	2019-10-12 19:45:57.133317+00	2019-10-12 19:45:57.133345+00	t	t	f	f	f	f	f	f	f	f	f	f	tres-mas	t	f	f	f	normal	f	no	502	f
350	2019-10-15 18:14:07.745617+00	2019-10-15 18:14:07.745644+00	f	f	f	f	f	f	f	f	f	f	f	f	tres-mas	t	f	f	f	normal	f	no	506	f
351	2019-10-16 11:19:50.747556+00	2019-10-16 11:19:50.747596+00	f	f	f	f	f	f	f	f	f	f	f	f	tres-mas	t	f	f	f	normal	f	no	507	f
352	2019-10-16 17:22:44.013428+00	2019-10-16 17:22:44.013456+00	f	f	f	t	f	f	f	f	f	f	f	t	no	f	t	t	f	normal	f	leve	508	f
353	2019-10-17 12:01:08.357052+00	2019-10-17 12:01:08.357079+00	f	f	f	t	f	f	f	f	f	f	f	f	uno-dos	f	f	f	f	normal	f	no	509	f
354	2019-10-17 13:34:50.984474+00	2019-10-17 13:34:50.984511+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	t	f	f	normal	f	no	510	f
355	2019-10-17 15:38:08.667996+00	2019-10-17 15:38:08.668023+00	f	f	f	t	f	f	f	f	f	f	f	f	tres-mas	f	f	f	f	normal	f	no	513	f
356	2019-10-17 18:28:46.458159+00	2019-10-17 18:28:46.458186+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	515	f
357	2019-10-17 19:40:33.382421+00	2019-10-17 19:40:33.382447+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	517	f
358	2019-10-17 23:53:25.942077+00	2019-10-17 23:53:25.942104+00	f	f	f	f	f	f	f	f	f	f	f	f	uno-dos	f	f	f	f	normal	f	no	518	f
359	2019-10-18 00:53:36.048253+00	2019-10-18 00:53:36.04828+00	f	f	f	f	f	f	f	f	f	f	f	t	no	f	f	f	f	normal	f	no	519	f
360	2019-10-18 14:55:24.104124+00	2019-10-18 14:55:24.104149+00	f	f	f	f	f	f	f	f	f	f	f	f	uno-dos	t	f	f	f	normal	f	no	522	f
361	2019-10-18 18:26:46.961462+00	2019-10-18 18:26:46.961488+00	f	f	f	f	f	f	f	f	f	f	f	f	uno-dos	t	f	f	t	normal	f	no	524	f
362	2019-10-19 00:25:19.646816+00	2019-10-19 00:25:19.646846+00	f	f	f	f	f	f	f	f	t	f	f	f	tres-mas	f	t	f	f	normal	f	no	526	f
363	2019-10-19 18:15:12.45044+00	2019-10-19 18:15:12.450466+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	527	f
364	2019-10-19 18:15:27.806956+00	2019-10-19 18:15:27.806982+00	f	f	f	f	f	f	f	f	f	f	f	f	uno-dos	f	f	f	f	normal	f	no	528	f
365	2019-10-23 12:32:00.745228+00	2019-10-23 12:32:00.745256+00	t	t	f	t	f	f	f	f	f	f	f	t	uno-dos	t	f	f	t	leve	f	moderada	532	f
366	2019-10-23 15:48:36.015806+00	2019-10-23 15:48:36.015833+00	f	f	f	f	f	f	f	f	f	f	f	f	uno-dos	t	t	f	f	normal	f	no	533	f
367	2019-10-23 17:03:23.841774+00	2019-10-23 17:03:23.8418+00	f	f	f	t	f	f	f	f	f	f	f	f	tres-mas	t	f	f	f	normal	f	no	534	f
368	2019-10-23 17:06:40.756515+00	2019-10-23 17:06:40.756541+00	f	f	f	f	f	f	f	f	f	f	f	f	uno-dos	f	f	f	f	normal	f	no	535	f
369	2019-10-23 17:08:52.104278+00	2019-10-23 17:08:52.104319+00	f	f	f	f	f	f	f	f	f	f	f	f	tres-mas	t	t	f	f	normal	f	no	536	f
370	2019-10-24 12:43:20.163234+00	2019-10-24 12:43:20.163261+00	f	f	f	t	f	f	f	f	f	f	f	f	no	t	t	f	f	leve	f	no	539	f
371	2019-10-24 16:52:27.683396+00	2019-10-24 16:52:27.683423+00	f	f	f	t	f	f	f	f	f	f	f	f	uno-dos	f	f	f	f	normal	f	no	540	f
372	2019-10-24 17:43:27.277045+00	2019-10-24 17:43:27.277069+00	f	f	f	f	f	f	f	f	f	f	f	f	uno-dos	t	f	f	f	normal	f	no	542	f
373	2019-10-25 19:23:53.927185+00	2019-10-25 19:23:53.927221+00	f	f	f	t	f	f	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	543	t
374	2019-10-25 19:34:08.666423+00	2019-10-25 19:34:08.66645+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	normal	f	no	544	f
\.


--
-- Data for Name: visits_followupvisitcomplementinformation; Type: TABLE DATA; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

COPY public.visits_followupvisitcomplementinformation (id, created, modified, depresion_mayor, otros_transtornos, hta_no_controlada, tratamiento_hipoglucemiantes, convulsiones, factores_predisponentes, anorexia, abuso_alcohol, tratamiento_actual, embarazo, glaucoma, tratamiento_beta_bloqueantes, actividad_fisica, dieta_hipocalorica, palpitaciones_aumento_fc, intolerancia_lactosa, tratamiento_levodopa, hepatitis_aguda, hipertension_arterial, disfuncion_renal, nauseas, constipacion, cefalea, mareos, insomnio, boca_seca, diarrea, vomitos, dolor_abdominal, otros_eventos, incio_tratamiento_actual, suspendio, visit_id, cirugia_planificada) FROM stdin;
106	2019-09-11 23:00:47.567225+00	2019-09-11 23:00:47.567249+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	f	f	normal	f	f	f	f	f	f	f	f	f	f	f	f	296	f
139	2019-09-11 23:10:34.316952+00	2019-09-11 23:10:34.316979+00	f	f	f	f	f	f	f	f	f	f	f	f	tres-mas	f	f	f	f	f	f	normal	t	f	f	f	f	f	f	f	f	f	f	f	331	f
140	2019-09-12 21:34:08.75641+00	2019-09-12 21:34:08.756439+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	f	f	normal	t	f	f	f	f	f	f	f	f	f	f	f	333	f
141	2019-09-12 21:34:58.138523+00	2019-09-12 21:34:58.138575+00	t	f	f	f	f	f	t	f	f	f	t	f	no	f	f	f	f	f	f	normal	f	f	f	t	f	f	f	f	f	f	f	f	334	f
142	2019-09-12 21:38:18.230329+00	2019-09-12 21:38:18.230356+00	t	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	f	f	normal	f	f	f	f	f	f	f	f	f	f	f	f	336	f
143	2019-09-12 21:38:24.994147+00	2019-09-12 21:38:24.994175+00	t	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	f	f	normal	f	f	f	f	f	f	f	f	f	f	f	f	335	f
144	2019-09-12 21:42:49.062625+00	2019-09-12 21:42:49.062653+00	t	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	f	f	normal	f	f	f	t	f	f	f	f	f	f	f	f	338	f
145	2019-09-13 00:46:13.61441+00	2019-09-13 00:46:13.614436+00	f	f	f	f	f	f	f	f	f	f	f	f	tres-mas	t	f	f	f	t	f	normal	f	f	f	f	f	f	f	f	f	f	f	f	340	f
146	2019-09-13 00:49:40.322207+00	2019-09-13 00:49:40.322235+00	f	f	f	f	f	f	f	f	t	f	f	f	tres-mas	t	f	f	f	f	f	normal	f	f	f	f	f	f	f	f	f	f	f	f	344	f
147	2019-09-13 16:21:08.149556+00	2019-09-13 16:21:08.149583+00	t	f	f	t	f	f	f	f	f	f	f	f	tres-mas	t	f	f	f	f	f	normal	f	f	f	f	f	f	f	t	f	f	f	f	346	f
148	2019-09-13 16:26:53.088876+00	2019-09-13 16:26:53.088903+00	f	f	f	f	t	t	f	f	f	f	f	f	no	f	f	f	f	f	f	normal	f	f	f	f	f	f	f	f	f	f	f	f	347	f
149	2019-09-14 00:50:27.730247+00	2019-09-14 00:50:27.730272+00	t	f	f	f	t	f	f	f	f	f	f	f	tres-mas	t	f	f	f	f	f	normal	f	f	f	f	f	f	f	t	f	f	f	f	350	f
150	2019-09-15 18:00:11.619807+00	2019-09-15 18:00:11.619845+00	t	f	f	f	f	f	t	f	f	f	f	f	no	f	f	f	f	f	f	normal	f	f	f	t	f	f	f	f	f	f	f	f	352	f
151	2019-09-15 19:10:21.618124+00	2019-09-15 19:10:21.618151+00	f	t	f	f	f	f	f	f	f	f	f	f	tres-mas	f	f	f	f	f	f	normal	f	t	f	f	f	f	f	f	f	f	f	f	353	f
152	2019-09-15 19:14:50.293941+00	2019-09-15 19:14:50.293967+00	t	f	f	f	f	f	t	f	f	f	t	f	tres-mas	f	f	f	f	f	f	normal	f	f	f	t	f	f	f	f	f	f	f	f	355	f
153	2019-09-15 19:20:56.987404+00	2019-09-15 19:20:56.987445+00	f	f	f	f	f	t	f	f	f	f	t	f	tres-mas	t	f	f	f	f	f	normal	f	f	f	f	f	f	f	f	f	f	f	f	356	f
154	2019-09-15 19:30:37.073106+00	2019-09-15 19:30:37.073131+00	f	f	f	f	f	f	f	f	f	f	f	f	tres-mas	t	f	f	f	f	f	leve	f	f	f	f	f	f	f	f	f	f	f	f	358	f
155	2019-09-15 19:51:58.892734+00	2019-09-15 19:51:58.892761+00	f	f	f	f	f	t	f	f	t	f	f	f	no	t	f	f	f	f	f	normal	f	f	f	t	f	f	f	f	f	f	f	f	359	f
156	2019-09-15 22:46:18.496439+00	2019-09-15 22:46:18.496466+00	t	f	f	f	f	f	t	f	f	f	t	f	tres-mas	f	f	f	f	f	f	leve	t	f	f	t	f	f	f	f	f	f	f	f	361	f
157	2019-09-15 23:58:50.441344+00	2019-09-15 23:58:50.441372+00	f	t	f	f	f	f	f	f	f	f	f	f	uno-dos	f	f	f	f	f	f	normal	f	t	f	f	f	f	f	f	f	f	f	f	362	f
158	2019-09-15 23:58:54.535848+00	2019-09-15 23:58:54.535887+00	t	f	f	f	f	f	t	f	f	f	f	f	no	f	f	f	f	f	f	normal	f	f	f	t	f	f	f	f	f	f	f	f	363	f
159	2019-09-16 00:01:21.115353+00	2019-09-16 00:01:21.115381+00	f	f	t	f	f	f	f	f	f	f	t	f	tres-mas	f	f	f	f	f	f	normal	f	f	f	t	f	f	f	f	f	f	f	f	365	f
160	2019-09-16 00:10:08.964884+00	2019-09-16 00:10:08.96491+00	t	f	f	f	f	f	t	f	f	f	t	f	no	t	f	f	f	f	f	normal	f	f	f	t	f	f	f	f	f	f	f	f	367	f
161	2019-09-16 18:48:45.896024+00	2019-09-16 18:48:45.896052+00	f	f	f	f	f	f	f	f	f	f	f	f	tres-mas	f	f	f	f	f	f	normal	f	t	f	f	f	f	f	f	f	f	f	f	370	f
162	2019-09-16 19:09:47.169545+00	2019-09-16 19:09:47.169572+00	f	f	f	f	f	f	f	f	f	f	f	t	uno-dos	f	f	f	f	f	f	normal	f	f	f	f	f	f	f	f	f	f	f	f	374	f
163	2019-09-25 18:50:27.509399+00	2019-09-25 18:50:27.509427+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	f	f	leve	f	f	f	f	f	f	f	f	f	f	f	f	380	f
164	2019-09-27 04:54:06.266841+00	2019-09-27 04:54:06.266868+00	t	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	f	f	normal	t	f	f	f	f	f	f	t	f	f	f	f	383	f
167	2019-09-29 13:24:12.791511+00	2019-09-29 13:24:12.791536+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	f	f	normal	f	f	f	f	f	f	f	f	f	f	f	f	389	f
168	2019-09-29 13:24:49.012382+00	2019-09-29 13:24:49.012409+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	f	f	normal	f	f	f	f	f	f	f	f	f	f	f	f	396	t
169	2019-09-29 13:41:21.1275+00	2019-09-29 13:41:21.127538+00	f	f	f	f	f	f	f	f	f	f	f	f	no	f	f	f	f	f	f	normal	f	f	f	f	f	f	f	f	f	f	f	f	399	t
170	2019-09-29 13:47:37.179703+00	2019-09-29 13:47:37.179728+00	f	f	f	f	f	f	f	t	t	f	f	f	no	f	f	f	f	f	f	normal	f	f	f	f	f	f	f	f	f	f	f	f	402	f
171	2019-10-05 11:35:29.272425+00	2019-10-05 11:35:29.272453+00	f	f	f	f	f	f	f	f	f	f	f	f	tres-mas	t	f	f	f	f	f	normal	f	f	f	f	f	t	f	f	f	f	f	f	426	f
172	2019-10-07 14:51:14.728897+00	2019-10-07 14:51:14.728923+00	f	f	f	f	f	f	f	f	f	f	f	f	tres-mas	f	f	f	f	f	f	normal	f	f	f	f	f	t	f	f	f	f	f	f	429	f
173	2019-10-07 14:54:34.820915+00	2019-10-07 14:54:34.820942+00	f	f	f	f	t	f	f	f	f	f	f	f	uno-dos	f	f	f	f	f	f	irc-terminal	f	f	f	f	f	f	f	f	f	f	f	f	431	f
174	2019-10-07 21:39:56.840008+00	2019-10-07 21:39:56.840033+00	f	f	f	f	f	f	f	f	f	f	f	f	uno-dos	f	t	f	f	f	f	normal	t	f	f	f	f	t	f	f	f	f	f	f	433	f
175	2019-10-08 02:40:27.771829+00	2019-10-08 02:40:27.771856+00	f	f	f	f	f	f	f	f	f	f	f	f	tres-mas	t	f	f	f	f	f	normal	f	f	f	f	f	f	f	f	t	f	f	f	436	f
176	2019-10-08 19:22:53.982739+00	2019-10-08 19:22:53.982765+00	f	f	f	f	f	f	f	f	f	f	f	f	tres-mas	f	f	f	f	f	f	normal	f	f	f	f	f	t	f	f	f	t	f	f	441	f
177	2019-10-11 14:23:55.851047+00	2019-10-11 14:23:55.851074+00	f	f	f	f	f	f	f	f	f	f	f	f	tres-mas	t	f	f	f	f	f	normal	f	f	f	f	f	f	f	f	f	f	f	f	485	f
178	2019-10-15 12:53:50.492239+00	2019-10-15 12:53:50.492267+00	f	f	t	f	f	f	f	f	f	f	f	f	tres-mas	t	f	f	f	f	f	leve	f	f	f	f	f	f	f	f	f	f	f	f	505	f
179	2019-10-17 13:36:10.021385+00	2019-10-17 13:36:10.021413+00	f	f	f	f	f	f	f	f	f	f	f	f	uno-dos	f	f	f	f	f	f	normal	f	f	f	f	f	f	f	f	f	f	f	f	511	f
180	2019-10-18 13:56:41.855272+00	2019-10-18 13:56:41.855305+00	f	f	f	f	f	f	f	f	f	f	f	f	uno-dos	f	f	f	f	f	f	normal	f	f	f	f	t	f	f	f	f	f	f	f	520	f
181	2019-10-18 15:36:33.93985+00	2019-10-18 15:36:33.939876+00	f	f	f	f	f	f	f	f	t	f	f	f	uno-dos	f	f	f	f	f	f	normal	f	f	f	f	f	f	f	f	f	f	f	f	523	f
182	2019-10-22 18:27:56.801139+00	2019-10-22 18:27:56.801167+00	f	f	f	f	f	f	f	f	f	f	f	f	tres-mas	f	f	f	f	f	f	normal	f	f	f	f	f	f	f	f	f	f	f	f	531	f
183	2019-10-24 17:36:52.962611+00	2019-10-24 17:36:52.962637+00	f	f	f	f	f	f	f	f	f	f	f	f	tres-mas	f	f	f	f	f	f	normal	f	t	f	f	f	f	f	f	f	f	f	f	541	f
184	2019-10-28 13:31:49.549673+00	2019-10-28 13:31:49.5497+00	t	t	f	f	f	f	f	f	f	f	f	t	tres-mas	t	t	f	f	f	f	normal	t	f	f	f	f	t	f	f	f	f	f	f	545	f
\.


--
-- Data for Name: visits_visit; Type: TABLE DATA; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

COPY public.visits_visit (id, created, modified, weight, height, type_visit, risk_factor, doctor_id, patient_id, concept, result, percentage_evolution, result_header, treatment_weaks) FROM stdin;
356	2019-09-15 19:20:21.762851+00	2019-09-15 19:20:56.988701+00	100	170	follow-up	f	30	295	SUSPENDER	Glaucoma de ángulo cerrado.\n	-9.1	El paciente tiene las siguientes\n                            contraindicaciones y debe suspender el\n                            tratamiento de NALTREXONA - BUPROPION.	0
366	2019-09-16 00:09:19.274678+00	2019-09-16 00:09:31.128271+00	85	170	first	t	30	301	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
376	2019-09-17 20:37:44.419747+00	2019-09-17 20:38:21.624897+00	85	155	first	f	35	310	INDICADO	SE RECOMIENDA MEDIR RUTINARIAMENTE LA GLUCEMIA. DEBE TENERSE PRECAUCIÓN CON EL RIESGO DE HIPOGLUCEMIA Y CONSIDERAR DISMINUIR LA DOSIS DE HIPOGLUCEMIANTES.\nES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
293	2019-08-15 22:43:10.466851+00	2019-09-11 22:48:12.782434+00	90	160	first	f	23	284	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
296	2019-09-11 23:00:33.01953+00	2019-09-11 23:00:47.569782+00	89	160	follow-up	f	23	284	CONTINUAR	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n	-1.1	\n                                Iniciar tratamiento con 2 comprimido (8mg/90mg) por la\n                                mañana y 1 comprimido (8mg/90mg) por la noche (NO junto\n                                a comidas grasas). Los comprimidos no deben ser cortados,\n                                masticados ni triturados.\n\n                                Si se omitió una dosis, ésta debe saltearse y reanudar la\n                                administración al momento de la siguiente dosis.	3
329	2019-09-11 23:07:36.045608+00	2019-09-11 23:07:36.045634+00	83	170	first	f	23	285	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC está entre 27 y 29.9 en ausencia de                          factores de riesgo cardiovascular (hipertensión arterial, diabetes o dislipidemia).			
339	2019-09-12 21:46:04.014595+00	2019-09-12 21:46:04.014622+00	83	170	first	f	10	289	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC está entre 27 y 29.9 en ausencia de                          factores de riesgo cardiovascular (hipertensión arterial, diabetes o dislipidemia).			
350	2019-09-14 00:50:04.724527+00	2019-09-14 00:50:27.731226+00	108	170	follow-up	f	30	295	CONTINUAR	Evaluar continuidad debido a: Vómitos	-1.8	Su paciente podría continuar recibiendo NALTREXONA -\n                                BUPROPION como complemento de una dieta reducida en\n                                calorías y de actividad física para el control crónico del peso.\n	0
396	2019-09-29 13:24:32.99738+00	2019-09-29 13:24:49.013405+00	65	160	follow-up	t	30	298	SUSPENDER	SUSPENDER EL USO DE NALTREXONA - BUPROPION AL MENOS 3 DÍAS ANTES DE LA CIRUGÍA PROGRAMADA.\n	-7.1	El paciente tiene las siguientes\n                            contraindicaciones y debe suspender el\n                            tratamiento de NALTREXONA - BUPROPION.	1
386	2019-09-28 23:48:55.462391+00	2019-09-30 03:28:06.356997+00	110	170	first	f	10	322	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
425	2019-10-05 11:33:25.53179+00	2019-10-05 11:33:50.861507+00	100	170	first	f	37	355	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
435	2019-10-08 02:39:30.717448+00	2019-10-08 02:39:49.174362+00	100	170	first	f	30	394	INDICADO			Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
445	2019-10-08 20:41:59.407482+00	2019-10-08 20:41:59.407509+00	64	165	first	f	79	404	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC es menor a 27.			
357	2019-09-15 19:29:20.983563+00	2019-09-15 19:29:39.728312+00	70	160	first	t	30	298	INDICADO	PRECAUCIÓN. PARA REDUCIR EL RIESGO DE CONVULSIONES SE RECOMIENDA UNA DOSIS TOTAL DE MÁXIMO 4 COMPRIMIDOS POR DÍA. DIVIDIR LA DOSIS DIARIA EN DOS TOMAS, ESCALAR LA DOSIS DE MANERA GRADUAL.\nES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
367	2019-09-16 00:09:45.79722+00	2019-09-16 00:10:08.965999+00	83	170	follow-up	t	30	301	SUSPENDER	Depresión mayor, trastorno bipolar, manía o ideación suicida.\nAnorexia / Bulimia.\nGlaucoma de ángulo cerrado.\n	-2.4	El paciente tiene las siguientes\n                            contraindicaciones y debe suspender el\n                            tratamiento de NALTREXONA - BUPROPION.	0
377	2019-09-18 20:33:15.385324+00	2019-09-18 20:33:15.38535+00	80	178	first	f	35	314	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC es menor a 27.			
397	2019-09-29 13:36:11.536021+00	2019-09-29 13:36:37.572467+00	100	170	first	f	30	329	CONTRA INDICADO	EL USO DE NALTREXONA - BUPROPION ESTÁ CONTRA INDICADO AL MENOS 3 DÍAS ANTES DE LA CIRUGÍA PROGRAMADA.		El paciente tiene las siguientes\n                            contraindicaciones para recibir NALTREXONA\n                            - BUPROPION.	
387	2019-09-29 00:20:04.137089+00	2019-09-30 18:18:21.963982+00	80	160	first	f	10	323	CONTRA INDICADO	Tratamiento actual con: BARBITURICOS,\n                            ANTIEPILEPTICOS, ANTIPSICOTICOS,\n                            OPIOIDES O AGONISTAS OPIACEOS,\n                            BUPROPION, IMAO, RITONAVIR,\n                            LOPINAVIR, EFAVIRENZ,\n                            CARBAMACEPINA, ANTIDEPRESIVOS,\n                            DROGAS METABOLIZADAS POR\n                            CYP2D6 (TAMOXIFENO).\nEL USO DE NALTREXONA - BUPROPION ESTÁ CONTRA INDICADO AL MENOS 3 DÍAS ANTES DE LA CIRUGÍA PROGRAMADA.		El paciente tiene las siguientes\n                            contraindicaciones para recibir NALTREXONA\n                            - BUPROPION.	
330	2019-09-11 23:09:58.050435+00	2019-09-11 23:10:08.916999+00	110	180	first	f	23	286	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
340	2019-09-13 00:45:54.564258+00	2019-09-13 00:46:13.615401+00	100	170	follow-up	f	10	288	SUSPENDER	Hepatitis aguda o fallo hepático.\n	-9.1	El paciente tiene las siguientes\n                            contraindicaciones y debe suspender el\n                            tratamiento de NALTREXONA - BUPROPION.	0
351	2019-09-15 17:58:57.180681+00	2019-09-15 17:59:10.373132+00	90	170	first	t	10	296	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
407	2019-09-30 18:28:24.164924+00	2019-09-30 18:28:41.532341+00	100	170	first	f	10	320	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
416	2019-10-03 01:05:48.103331+00	2019-10-03 01:06:56.006714+00	100	170	first	t	10	346	INDICADO	SE RECOMIENDA MEDIR RUTINARIAMENTE LA GLUCEMIA. DEBE TENERSE PRECAUCIÓN CON EL RIESGO DE HIPOGLUCEMIA Y CONSIDERAR DISMINUIR LA DOSIS DE HIPOGLUCEMIANTES.\nPRECAUCIÓN. PARA REDUCIR EL RIESGO DE CONVULSIONES SE RECOMIENDA UNA DOSIS TOTAL DE MÁXIMO 4 COMPRIMIDOS POR DÍA. DIVIDIR LA DOSIS DIARIA EN DOS TOMAS, ESCALAR LA DOSIS DE MANERA GRADUAL.\nES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
426	2019-10-05 11:35:04.67343+00	2019-10-05 11:35:29.275045+00	98	170	follow-up	f	37	355	CONTINUAR	Evaluar continuidad debido a: Boca seca	-2.0	Su paciente podría continuar recibiendo NALTREXONA -\n                                BUPROPION como complemento de una dieta reducida en\n                                calorías y de actividad física para el control crónico del peso.\n	0
436	2019-10-08 02:40:07.183899+00	2019-10-08 02:40:27.772821+00	98	170	follow-up	f	30	394	CONTINUAR	Evaluar continuidad debido a: Dolor abdominal o dispesia	-2.0	Su paciente podría continuar recibiendo NALTREXONA -\n                                BUPROPION como complemento de una dieta reducida en\n                                calorías y de actividad física para el control crónico del peso.\n	0
446	2019-10-08 21:47:37.056164+00	2019-10-08 21:47:37.056192+00	79	162	first	f	82	406					
521	2019-10-18 14:49:04.656541+00	2019-10-18 14:49:04.656568+00	130	170	first	t	124	499					
358	2019-09-15 19:30:17.250847+00	2019-09-15 19:30:37.074124+00	69	160	follow-up	t	30	298	CONTINUAR		-1.4	Su paciente podría continuar recibiendo NALTREXONA -\n                                BUPROPION como complemento de una dieta reducida en\n                                calorías y de actividad física para el control crónico del peso.\n	0
368	2019-09-16 18:44:45.960494+00	2019-09-16 18:46:01.435685+00	95	175	first	f	10	302	CONTRA INDICADO	Depresión mayor, trastorno bipolar, manía o ideación suicida.\n		El paciente tiene las siguientes\n                            contraindicaciones para recibir NALTREXONA\n                            - BUPROPION.	
378	2019-09-18 20:35:15.750699+00	2019-09-18 20:37:47.12407+00	95	155	first	f	35	315	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\nPRECAUCIÓN. EL USO DE NALTREXONA - BUPROPION JUNTO CON ESTOS MEDICAMENTOS INCREMENTA EL RIESGO DE EVENTOS ADVERSOS.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
388	2019-09-29 00:23:05.177083+00	2019-09-29 00:23:05.177107+00	88	160	follow-up	f	10	305			-2.2		1
331	2019-09-11 23:10:20.456235+00	2019-09-11 23:10:34.318705+00	109	180	follow-up	f	23	286	CONTINUAR	Evaluar continuidad debido a: Náuseas	-0.9	Su paciente podría continuar recibiendo NALTREXONA -\n                                BUPROPION como complemento de una dieta reducida en\n                                calorías y de actividad física para el control crónico del peso.\n	0
341	2019-09-13 00:46:54.876091+00	2019-09-13 00:47:13.993534+00	120	180	first	f	10	290	CONTRA INDICADO	Convulsiones o Epilepsia.\n		El paciente tiene las siguientes\n                            contraindicaciones para recibir NALTREXONA\n                            - BUPROPION.	
352	2019-09-15 17:59:23.886439+00	2019-09-15 18:00:11.621932+00	100	170	follow-up	t	10	296	CONTINUAR	Evaluar continuidad debido a: Mareos	11.1	Su paciente podría continuar recibiendo NALTREXONA -\n                                BUPROPION como complemento de una dieta reducida en\n                                calorías y de actividad física para el control crónico del peso.\n	0
398	2019-09-29 13:40:36.617864+00	2019-09-29 13:40:47.415032+00	110	180	first	f	30	330	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
417	2019-10-03 01:35:51.228588+00	2019-10-03 01:35:51.228616+00	110	180	first	t	10	347					
427	2019-10-07 14:48:55.154689+00	2019-10-07 14:48:55.154714+00	90	170	follow-up	f	37	355			-10.0		0
437	2019-10-08 11:38:47.558477+00	2019-10-08 11:39:44.304498+00	98	160	first	t	75	396	CONTRA INDICADO	EL USO DE NALTREXONA - BUPROPION ESTÁ CONTRA INDICADO AL MENOS 3 DÍAS ANTES DE LA CIRUGÍA PROGRAMADA.		El paciente tiene las siguientes\n                            contraindicaciones para recibir NALTREXONA\n                            - BUPROPION.	
447	2019-10-08 22:04:44.143969+00	2019-10-08 22:06:43.886729+00	110	155	first	f	95	407	INDICADO	SE RECOMIENDA MEDIR RUTINARIAMENTE LA GLUCEMIA. DEBE TENERSE PRECAUCIÓN CON EL RIESGO DE HIPOGLUCEMIA Y CONSIDERAR DISMINUIR LA DOSIS DE HIPOGLUCEMIANTES.\nRECOMENDAR DIETA HIPOCALÓRICA.\nNALTREXONA - BUPROPION PUEDE AUMENTAR LA FRECUENCIA CARDIACA Y LA PRESIÓN ARTERIAL POR LO QUE SE RECOMIENDA UN CONTROL ESTRICTO DE LA FC Y LA TA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
454	2019-10-09 22:41:45.020183+00	2019-10-09 22:41:45.020208+00	95	183	first	f	108	417	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC está entre 27 y 29.9 en ausencia de                          factores de riesgo cardiovascular (hipertensión arterial, diabetes o dislipidemia).			
458	2019-10-10 12:54:58.510401+00	2019-10-10 12:56:05.136232+00	111	182	first	f	31	423	INDICADO	RECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
463	2019-10-10 16:03:11.693907+00	2019-10-10 16:03:11.693934+00	70	160	first	f	119	428	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC está entre 27 y 29.9 en ausencia de                          factores de riesgo cardiovascular (hipertensión arterial, diabetes o dislipidemia).			
469	2019-10-10 21:27:26.109369+00	2019-10-10 21:28:40.95651+00	145	170	first	t	131	436	CONTRA INDICADO	Depresión mayor, trastorno bipolar, manía o ideación suicida.\nHTA no controlada.\n		El paciente tiene las siguientes\n                            contraindicaciones para recibir NALTREXONA\n                            - BUPROPION.	
473	2019-10-10 23:22:45.432928+00	2019-10-10 23:22:45.432954+00	76	172	first	f	136	442	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC es menor a 27.			
477	2019-10-11 11:28:12.237844+00	2019-10-11 11:28:12.23787+00	79	169	first	f	148	451	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC está entre 27 y 29.9 en ausencia de                          factores de riesgo cardiovascular (hipertensión arterial, diabetes o dislipidemia).			
514	2019-10-17 15:39:00.832818+00	2019-10-17 15:39:00.832855+00	69	157	follow-up	f	149	490			-12.7		0
359	2019-09-15 19:51:33.321154+00	2019-09-15 19:51:58.893738+00	66	160	follow-up	t	30	298	CONTINUAR	Evaluar continuidad debido a: Mareos	-5.7	Su paciente podría continuar recibiendo NALTREXONA -\n                                BUPROPION como complemento de una dieta reducida en\n                                calorías y de actividad física para el control crónico del peso.\n	0
332	2019-09-12 21:33:11.211892+00	2019-09-12 21:33:30.538923+00	110	180	first	f	10	287	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
342	2019-09-13 00:47:59.899483+00	2019-09-13 00:48:16.221917+00	70	160	first	t	10	291	CONTRA INDICADO	Insuficiencia Hepática.: Moderada a grave\n		El paciente tiene las siguientes\n                            contraindicaciones para recibir NALTREXONA\n                            - BUPROPION.	
353	2019-09-15 19:09:46.575616+00	2019-09-15 19:10:21.619363+00	90	170	follow-up	t	10	296	CONTINUAR	Evaluar continuidad debido a: Constipación	0.0	Su paciente podría continuar recibiendo NALTREXONA -\n                                BUPROPION como complemento de una dieta reducida en\n                                calorías y de actividad física para el control crónico del peso.\n	0
369	2019-09-16 18:47:16.272065+00	2019-09-16 18:47:33.394938+00	90	160	first	f	10	304	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
379	2019-09-20 14:39:56.278663+00	2019-09-20 14:40:18.268926+00	90	165	first	f	36	316	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
389	2019-09-29 00:24:05.064121+00	2019-09-29 13:24:12.793522+00	61	160	follow-up	t	30	298	CONTINUAR	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n	-12.9	Su paciente podría continuar recibiendo NALTREXONA -\n                                BUPROPION como complemento de una dieta reducida en\n                                calorías y de actividad física para el control crónico del peso.\n	1
399	2019-09-29 13:41:07.794368+00	2019-09-29 13:41:21.128493+00	105	180	follow-up	f	30	330	SUSPENDER	SUSPENDER EL USO DE NALTREXONA - BUPROPION AL MENOS 3 DÍAS ANTES DE LA CIRUGÍA PROGRAMADA.\n	-4.5	El paciente tiene las siguientes\n                            contraindicaciones y debe suspender el\n                            tratamiento de NALTREXONA - BUPROPION.	0
409	2019-10-01 03:50:54.903992+00	2019-10-01 03:50:54.904018+00	90	170	first	t	10	338					
418	2019-10-03 01:53:11.308037+00	2019-10-03 01:53:27.798468+00	100	170	first	t	10	348	INDICADO	SE RECOMIENDA MEDIR RUTINARIAMENTE LA GLUCEMIA. DEBE TENERSE PRECAUCIÓN CON EL RIESGO DE HIPOGLUCEMIA Y CONSIDERAR DISMINUIR LA DOSIS DE HIPOGLUCEMIANTES.\nPRECAUCIÓN. PARA REDUCIR EL RIESGO DE CONVULSIONES SE RECOMIENDA UNA DOSIS TOTAL DE MÁXIMO 4 COMPRIMIDOS POR DÍA. DIVIDIR LA DOSIS DIARIA EN DOS TOMAS, ESCALAR LA DOSIS DE MANERA GRADUAL.\nES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
428	2019-10-07 14:50:18.182892+00	2019-10-07 14:50:31.5021+00	100	170	first	f	37	389	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
438	2019-10-08 11:42:17.190692+00	2019-10-08 11:44:46.940572+00	78	160	first	f	71	397	INDICADO	RECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
448	2019-10-09 01:07:56.288543+00	2019-10-09 01:10:48.607303+00	110	172	first	t	99	409	CONTRA INDICADO	HTA no controlada.\n		El paciente tiene las siguientes\n                            contraindicaciones para recibir NALTREXONA\n                            - BUPROPION.	
478	2019-10-11 11:53:46.924811+00	2019-10-11 11:53:46.924837+00	85	180	first	t	149	452	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC es menor a 27.			
360	2019-09-15 22:36:12.556022+00	2019-09-15 22:36:12.556049+00	80	165	first	t	1	299					
370	2019-09-16 18:48:10.86519+00	2019-09-16 18:48:45.897021+00	95	160	follow-up	f	10	304	CONTINUAR	Evaluar continuidad debido a: Constipación	5.6	Su paciente podría continuar recibiendo NALTREXONA -\n                                BUPROPION como complemento de una dieta reducida en\n                                calorías y de actividad física para el control crónico del peso.\n	0
333	2019-09-12 21:33:52.712719+00	2019-09-12 21:34:08.757479+00	109	180	follow-up	f	10	287	CONTINUAR	Evaluar continuidad debido a: Náuseas	-0.9	Su paciente podría continuar recibiendo NALTREXONA -\n                                BUPROPION como complemento de una dieta reducida en\n                                calorías y de actividad física para el control crónico del peso.\n	0
343	2019-09-13 00:48:52.385549+00	2019-09-13 00:49:07.291318+00	120	190	first	f	10	292	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
344	2019-09-13 00:49:20.059926+00	2019-09-13 00:49:40.323136+00	110	190	follow-up	f	10	292	SUSPENDER	Tratamiento actual con: BENZODIACEPINAS, BARBITURICOS,\n                                ANTIEPILEPTICOS, ANTIPSICOTICOS,\n                                OPIOIDES O AGONISTAS OPIACEOS,\n                                BUPROPION, IMAO, RITONAVIR,\n                                LOPINAVIR, EFAVIRENZ,\n                                CARBAMACEPINA, ANTIDEPRESIVOS,\n                                DROGAS METABOLIZADAS POR\n                                CYP2D6 (TAMOXIFENO).\n	-8.3	El paciente tiene las siguientes\n                            contraindicaciones y debe suspender el\n                            tratamiento de NALTREXONA - BUPROPION.	0
354	2019-09-15 19:13:26.502131+00	2019-09-15 19:13:37.080932+00	93	180	first	t	30	297	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
380	2019-09-25 04:18:49.241817+00	2019-09-25 18:50:27.511259+00	180	160	follow-up	f	10	305	CONTINUAR	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n	100.0	Su paciente podría continuar recibiendo NALTREXONA -\n                                BUPROPION como complemento de una dieta reducida en\n                                calorías y de actividad física para el control crónico del peso.\n	1
400	2019-09-29 13:44:20.095282+00	2019-09-29 13:44:48.081475+00	100	170	first	f	30	331	CONTRA INDICADO	Abuso de alcohol o abandono\n    abrupto reciente de alcohol.\nTratamiento actual con: BENZODIACEPINAS, BARBITURICOS,\n                            ANTIEPILEPTICOS, ANTIPSICOTICOS,\n                            OPIOIDES O AGONISTAS OPIACEOS,\n                            BUPROPION, IMAO, RITONAVIR,\n                            LOPINAVIR, EFAVIRENZ,\n                            CARBAMACEPINA, ANTIDEPRESIVOS,\n                            DROGAS METABOLIZADAS POR\n                            CYP2D6 (TAMOXIFENO).\n		El paciente tiene las siguientes\n                            contraindicaciones para recibir NALTREXONA\n                            - BUPROPION.	
410	2019-10-01 04:44:26.052038+00	2019-10-01 04:44:26.052068+00	100	170	first	t	10	339					
419	2019-10-03 01:57:53.313728+00	2019-10-03 01:57:53.313767+00	110	170	first	t	10	349					
429	2019-10-07 14:50:52.902289+00	2019-10-07 14:51:14.729921+00	98	170	follow-up	f	37	389	CONTINUAR	Evaluar continuidad debido a: Boca seca	-2.0	Su paciente podría continuar recibiendo NALTREXONA -\n                                BUPROPION como complemento de una dieta reducida en\n                                calorías y de actividad física para el control crónico del peso.\n	0
439	2019-10-08 19:14:21.569646+00	2019-10-08 19:15:37.984851+00	98	165	first	t	77	399	INDICADO			Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
449	2019-10-09 11:26:14.064377+00	2019-10-09 11:26:14.064416+00	85	178	first	t	101	412	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC es menor a 27.			
459	2019-10-10 13:34:54.190605+00	2019-10-10 13:35:52.566908+00	86	165	first	t	85	424	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
464	2019-10-10 16:45:07.65642+00	2019-10-10 16:46:43.82918+00	112	153	first	t	120	429	CONTRA INDICADO	Otros trastornos psiquiátricos{incluidos en la cesación tabáquica}.\nHTA no controlada.\nAbuso de alcohol o abandono\n    abrupto reciente de alcohol o de benzodiazepinas.\n		El paciente tiene las siguientes\n                            contraindicaciones para recibir NALTREXONA\n                            - BUPROPION.	
474	2019-10-11 02:10:05.991716+00	2019-10-11 02:10:05.991743+00	90	176	first	f	136	446	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC está entre 27 y 29.9 en ausencia de                          factores de riesgo cardiovascular (hipertensión arterial, diabetes o dislipidemia).			
495	2019-10-11 20:25:29.863521+00	2019-10-11 20:25:29.863548+00	106	158	first	t	116	470					
361	2019-09-15 22:36:25.478533+00	2019-09-15 22:46:18.497437+00	80	165	follow-up	t	1	299	CONTINUAR	Evaluar continuidad debido a: NáuseasEvaluar continuidad debido a: Mareos	0.0	Su paciente podría continuar recibiendo NALTREXONA -\n                                BUPROPION como complemento de una dieta reducida en\n                                calorías y de actividad física para el control crónico del peso.\n	0
334	2019-09-12 21:34:27.346486+00	2019-09-12 21:34:58.139678+00	108	180	follow-up	f	10	287	CONTINUAR	Evaluar continuidad debido a: Mareos	-1.8	Su paciente podría continuar recibiendo NALTREXONA -\n                                BUPROPION como complemento de una dieta reducida en\n                                calorías y de actividad física para el control crónico del peso.\n	0
345	2019-09-13 16:19:51.515644+00	2019-09-13 16:20:14.903055+00	100	170	first	f	30	293	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
355	2019-09-15 19:13:52.20962+00	2019-09-15 19:14:50.295049+00	90	180	follow-up	t	30	297	CONTINUAR	Evaluar continuidad debido a: Mareos	-3.2	Su paciente podría continuar recibiendo NALTREXONA -\n                                BUPROPION como complemento de una dieta reducida en\n                                calorías y de actividad física para el control crónico del peso.\n	0
371	2019-09-16 18:54:07.427009+00	2019-09-18 14:46:48.78437+00	90	160	first	f	10	305	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
381	2019-09-25 23:02:59.363905+00	2019-09-25 23:02:59.363932+00	100	170	first	f	10	317					
401	2019-09-29 13:46:49.978182+00	2019-09-29 13:47:01.860478+00	100	170	first	f	30	332	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
411	2019-10-01 04:54:46.19446+00	2019-10-01 04:55:19.078507+00	100	170	first	t	10	341	CONTRA INDICADO	Abuso de alcohol o abandono\n    abrupto reciente de alcohol o de benzodiazepinas.\n		El paciente tiene las siguientes\n                            contraindicaciones para recibir NALTREXONA\n                            - BUPROPION.	
420	2019-10-03 01:59:21.5073+00	2019-10-03 01:59:35.777358+00	90	160	first	t	10	350	INDICADO	SE RECOMIENDA MEDIR RUTINARIAMENTE LA GLUCEMIA. DEBE TENERSE PRECAUCIÓN CON EL RIESGO DE HIPOGLUCEMIA Y CONSIDERAR DISMINUIR LA DOSIS DE HIPOGLUCEMIANTES.\nPRECAUCIÓN. PARA REDUCIR EL RIESGO DE CONVULSIONES SE RECOMIENDA UNA DOSIS TOTAL DE MÁXIMO 4 COMPRIMIDOS POR DÍA. DIVIDIR LA DOSIS DIARIA EN DOS TOMAS, ESCALAR LA DOSIS DE MANERA GRADUAL.\nES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
430	2019-10-07 14:52:56.357871+00	2019-10-07 14:53:51.694922+00	160	175	first	f	70	388	INDICADO	USAR CON PRECAUCIÓN EN MAYORES DE 65 AÑOS POR MAYOR RIESGO DE EVENTOS ADVERSOS DEBIDO A LA ELIMINACIÓN RENAL DE NALTREXONA - BUPROPION.\nSE RECOMIENDA MEDIR RUTINARIAMENTE LA GLUCEMIA. DEBE TENERSE PRECAUCIÓN CON EL RIESGO DE HIPOGLUCEMIA Y CONSIDERAR DISMINUIR LA DOSIS DE HIPOGLUCEMIANTES.\nES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
440	2019-10-08 19:14:54.169538+00	2019-10-08 19:16:26.235141+00	91	180	first	t	86	400	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
465	2019-10-10 16:49:15.217551+00	2019-10-10 16:49:15.217578+00	90	174	first	t	121	430					
488	2019-10-11 15:26:10.432601+00	2019-10-11 15:26:10.432628+00	67	170	first	f	154	461	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC es menor a 27.			
362	2019-09-15 23:51:28.978572+00	2019-09-15 23:58:50.44366+00	100	170	follow-up	t	10	296	SUSPENDER	Otros trastornos psiquiátricos (incluidos en la cesación tabáquica).\n	11.1	El paciente tiene las siguientes\n                            contraindicaciones y debe suspender el\n                            tratamiento de NALTREXONA - BUPROPION.	0
335	2019-09-12 21:38:02.139224+00	2019-09-12 21:38:24.995174+00	100	180	follow-up	f	10	287	SUSPENDER	Depresión mayor, trastorno bipolar, manía o ideación suicida.\n	-9.1	El paciente tiene las siguientes\n                            contraindicaciones y debe suspender el\n                            tratamiento de NALTREXONA - BUPROPION.	0
346	2019-09-13 16:20:46.368014+00	2019-09-13 16:21:08.150583+00	98	170	follow-up	f	30	293	CONTINUAR	Evaluar continuidad debido a: Vómitos	-2.0	Su paciente podría continuar recibiendo NALTREXONA -\n                                BUPROPION como complemento de una dieta reducida en\n                                calorías y de actividad física para el control crónico del peso.\n	0
372	2019-09-16 18:57:58.645586+00	2019-09-16 19:00:57.132893+00	110	182	first	t	10	306	CONTRA INDICADO	HTA no controlada.\n		El paciente tiene las siguientes\n                            contraindicaciones para recibir NALTREXONA\n                            - BUPROPION.	
402	2019-09-29 13:47:13.327921+00	2019-09-29 13:47:37.180745+00	99	170	follow-up	f	30	332	SUSPENDER	Abuso de alcohol o abandono\n    abrupto reciente de alcohol o de benzodiazepinas.\nTratamiento actual con: BARBITURICOS,\n                                ANTIEPILEPTICOS, ANTIPSICOTICOS,\n                                OPIOIDES O AGONISTAS OPIACEOS,\n                                BUPROPION, IMAO, RITONAVIR,\n                                LOPINAVIR, EFAVIRENZ,\n                                CARBAMACEPINA, ANTIDEPRESIVOS,\n                                DROGAS METABOLIZADAS POR\n                                CYP2D6 (TAMOXIFENO).\n	-1.0	El paciente tiene las siguientes\n                            contraindicaciones y debe suspender el\n                            tratamiento de NALTREXONA - BUPROPION.	0
412	2019-10-01 19:24:11.557247+00	2019-10-01 19:24:26.28913+00	90	160	first	f	10	342	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
421	2019-10-03 02:06:43.660546+00	2019-10-03 02:07:09.767754+00	80	165	first	t	10	351	INDICADO	SE RECOMIENDA MEDIR RUTINARIAMENTE LA GLUCEMIA. DEBE TENERSE PRECAUCIÓN CON EL RIESGO DE HIPOGLUCEMIA Y CONSIDERAR DISMINUIR LA DOSIS DE HIPOGLUCEMIANTES.\nPRECAUCIÓN. PARA REDUCIR EL RIESGO DE CONVULSIONES SE RECOMIENDA UNA DOSIS TOTAL DE MÁXIMO 4 COMPRIMIDOS POR DÍA. DIVIDIR LA DOSIS DIARIA EN DOS TOMAS, ESCALAR LA DOSIS DE MANERA GRADUAL.\nES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
431	2019-10-07 14:54:04.463552+00	2019-10-07 14:54:34.821895+00	78	170	follow-up	f	37	389	SUSPENDER	Convulsiones o Epilepsia.\nDisfunción renal.:IRC Terminal\n	-22.0	El paciente tiene las siguientes\n                            contraindicaciones y debe suspender el\n                            tratamiento de NALTREXONA - BUPROPION.	0
441	2019-10-08 19:22:07.055842+00	2019-10-08 19:22:53.983764+00	100	165	follow-up	t	77	399	CONTINUAR	Evaluar continuidad debido a: Boca secaEvaluar continuidad debido a: Otros eventos	2.0	Su paciente podría continuar recibiendo NALTREXONA -\n                                BUPROPION como complemento de una dieta reducida en\n                                calorías y de actividad física para el control crónico del peso.\n	0
450	2019-10-09 12:53:44.103515+00	2019-10-09 12:55:18.613433+00	86	158	first	t	85	413	INDICADO	PRECAUCIÓN. EL USO DE NALTREXONA - BUPROPION JUNTO CON ESTOS MEDICAMENTOS INCREMENTA EL RIESGO DE EVENTOS ADVERSOS.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
460	2019-10-10 14:31:06.065933+00	2019-10-10 14:33:44.856857+00	115	178	first	t	117	425	CONTRA INDICADO	Otros trastornos psiquiátricos{incluidos en la cesación tabáquica}.\n		El paciente tiene las siguientes\n                            contraindicaciones para recibir NALTREXONA\n                            - BUPROPION.	
466	2019-10-10 17:34:39.353351+00	2019-10-10 17:34:39.353377+00	145	176	first	t	124	431					
363	2019-09-15 23:58:31.43709+00	2019-09-15 23:58:54.536959+00	110	170	follow-up	t	10	296	SUSPENDER	Depresión mayor, trastorno bipolar, manía o ideación suicida.\nAnorexia / Bulimia.\n	22.2	El paciente tiene las siguientes\n                            contraindicaciones y debe suspender el\n                            tratamiento de NALTREXONA - BUPROPION.	0
336	2019-09-12 21:38:03.546877+00	2019-09-12 21:38:18.23124+00	107	180	follow-up	f	10	287	SUSPENDER	Depresión mayor, trastorno bipolar, manía o ideación suicida.\n	-2.7	El paciente tiene las siguientes\n                            contraindicaciones y debe suspender el\n                            tratamiento de NALTREXONA - BUPROPION.	0
347	2019-09-13 16:26:37.369149+00	2019-09-13 16:26:53.089878+00	94	170	follow-up	f	30	293	SUSPENDER	Convulsiones o Epilepsia.\n	-6.0	El paciente tiene las siguientes\n                            contraindicaciones y debe suspender el\n                            tratamiento de NALTREXONA - BUPROPION.	0
373	2019-09-16 19:06:41.507752+00	2019-09-16 19:07:47.868744+00	130	182	first	f	31	307	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
383	2019-09-27 04:53:08.331127+00	2019-09-27 04:54:06.26784+00	55	160	follow-up	f	10	304	SUSPENDER	Depresión mayor, trastorno bipolar, manía o ideación suicida.\n	-38.9	El paciente tiene las siguientes\n                            contraindicaciones y debe suspender el\n                            tratamiento de NALTREXONA - BUPROPION.	1
403	2019-09-29 14:51:16.605174+00	2019-09-29 14:51:16.605202+00	90	170	first	f	10	333					
413	2019-10-01 19:24:59.095203+00	2019-10-01 19:25:13.310833+00	88	155	first	f	10	343	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
422	2019-10-03 02:08:25.866125+00	2019-10-03 02:08:25.866151+00	80	165	first	f	10	352	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC está entre 27 y 29.9 en ausencia de                          factores de riesgo cardiovascular (hipertensión arterial, diabetes o dislipidemia).			
432	2019-10-07 20:36:33.653075+00	2019-10-07 20:41:59.608378+00	118	168	first	f	71	390	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
442	2019-10-08 19:35:42.484292+00	2019-10-08 19:38:41.586067+00	85	160	first	t	83	401	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
451	2019-10-09 13:45:49.192631+00	2019-10-09 13:49:32.056726+00	75	166	first	t	103	414	CONTRA INDICADO	Anorexia / Bulimia.\nIntolerancia a la lactosa.\n		El paciente tiene las siguientes\n                            contraindicaciones para recibir NALTREXONA\n                            - BUPROPION.	
455	2019-10-10 12:22:13.864093+00	2019-10-10 12:24:16.242698+00	86	173	first	t	110	419	INDICADO	SE RECOMIENDA MEDIR RUTINARIAMENTE LA GLUCEMIA. DEBE TENERSE PRECAUCIÓN CON EL RIESGO DE HIPOGLUCEMIA Y CONSIDERAR DISMINUIR LA DOSIS DE HIPOGLUCEMIANTES.\nPRECAUCIÓN. LA MÁXIMA DOSIS RECOMENDADA EN EL SEGUIMIENTO ES 1 COMPRIMIDO A LA MAÑANA Y 1 COMPRIMIDO A LA NOCHE.\nES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\nNALTREXONA - BUPROPION PUEDE AUMENTAR LA FRECUENCIA CARDIACA Y LA PRESIÓN ARTERIAL POR LO QUE SE RECOMIENDA UN CONTROL ESTRICTO DE LA FC Y LA TA.\nPRECAUCIÓN. EL USO DE NALTREXONA - BUPROPION JUNTO CON ESTOS MEDICAMENTOS INCREMENTA EL RIESGO DE EVENTOS ADVERSOS.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
461	2019-10-10 14:40:04.371361+00	2019-10-10 14:40:04.371386+00	78	184	first	f	118	426	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC es menor a 27.			
467	2019-10-10 19:13:33.1493+00	2019-10-10 19:14:57.536505+00	70	160	first	t	119	432	CONTRA INDICADO	Intolerancia a la lactosa.\n		El paciente tiene las siguientes\n                            contraindicaciones para recibir NALTREXONA\n                            - BUPROPION.	
480	2019-10-11 12:21:04.333188+00	2019-10-11 12:21:04.333215+00	100	189	first	f	151	454	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC está entre 27 y 29.9 en ausencia de                          factores de riesgo cardiovascular (hipertensión arterial, diabetes o dislipidemia).			
337	2019-09-12 21:41:24.595048+00	2019-09-12 21:41:54.879533+00	110	170	first	f	10	288	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
348	2019-09-13 16:34:32.16492+00	2019-09-13 16:35:05.375569+00	76	160	first	t	30	294	CONTRA INDICADO	Depresión mayor, trastorno bipolar, manía o ideación suicida.\nAbuso de alcohol o abandono\n    abrupto reciente de alcohol.\nGlaucoma de ángulo cerrado.\n		El paciente tiene las siguientes\n                            contraindicaciones para recibir NALTREXONA\n                            - BUPROPION.	
364	2019-09-16 00:00:14.495103+00	2019-09-16 00:00:32.016921+00	80	160	first	f	10	300	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
374	2019-09-16 19:08:36.707839+00	2019-09-16 19:09:47.170606+00	115	182	follow-up	f	31	307	AJUSTAR DOSIS	 LA MÁXIMA DOSIS RECOMENDADA ES 1 COMPRIMIDO A LA MAÑANA Y 1 COMPRIMIDO A LA NOCHE.\n	-11.5	Su paciente podría continuar recibiendo NALTREXONA - BUPROPION como\n                                complemento de una dieta reducida en calorías y de actividad física para el\n                                control crónico del peso.	0
384	2019-09-28 05:45:14.229231+00	2019-09-28 05:45:14.229257+00	100	170	first	f	10	303					
404	2019-09-30 03:28:22.422422+00	2019-09-30 03:28:22.422448+00	90	170	follow-up	f	10	322			-18.2		0
423	2019-10-03 02:09:17.158765+00	2019-10-03 02:09:17.158792+00	120	170	first	t	10	353					
433	2019-10-07 21:38:47.277147+00	2019-10-07 21:39:56.840989+00	109	168	follow-up	f	71	390	CONTINUAR	Evaluar continuidad debido a: NáuseasEvaluar continuidad debido a: Boca seca	-7.6	Su paciente podría continuar recibiendo NALTREXONA -\n                                BUPROPION como complemento de una dieta reducida en\n                                calorías y de actividad física para el control crónico del peso.\n	0
443	2019-10-08 19:43:11.966126+00	2019-10-08 19:43:11.966158+00	79	179	first	f	90	402	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC es menor a 27.			
452	2019-10-09 21:44:33.278735+00	2019-10-09 21:51:19.661573+00	89	168	first	f	85	415	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
456	2019-10-10 12:28:35.635004+00	2019-10-10 12:28:35.635031+00	85	180	first	t	110	420	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC es menor a 27.			
462	2019-10-10 15:56:46.542083+00	2019-10-10 15:56:46.542137+00	70	162	first	f	119	427	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC es menor a 27.			
468	2019-10-10 21:14:16.42122+00	2019-10-10 21:15:34.441269+00	108	177	first	f	130	435	INDICADO	RECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
470	2019-10-10 21:30:43.140746+00	2019-10-10 21:31:42.709131+00	100	168	first	t	131	437	INDICADO	SE RECOMIENDA MEDIR RUTINARIAMENTE LA GLUCEMIA. DEBE TENERSE PRECAUCIÓN CON EL RIESGO DE HIPOGLUCEMIA Y CONSIDERAR DISMINUIR LA DOSIS DE HIPOGLUCEMIANTES.\nES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
471	2019-10-10 22:09:18.138015+00	2019-10-10 22:10:35.866861+00	128	176	first	t	133	440	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
485	2019-10-11 14:22:24.492522+00	2019-10-11 14:23:55.852296+00	96	180	follow-up	t	149	453	CONTINUAR		-2.0	Su paciente podría continuar recibiendo NALTREXONA -\n                                BUPROPION como complemento de una dieta reducida en\n                                calorías y de actividad física para el control crónico del peso.\n	0
365	2019-09-16 00:00:56.151752+00	2019-09-16 00:01:21.116337+00	79	160	follow-up	f	10	300	SUSPENDER	HTA no controlada.\nGlaucoma de ángulo cerrado.\n	-1.2	El paciente tiene las siguientes\n                            contraindicaciones y debe suspender el\n                            tratamiento de NALTREXONA - BUPROPION.	0
338	2019-09-12 21:42:19.453613+00	2019-09-12 21:42:49.063631+00	109	170	follow-up	f	10	288	CONTINUAR	Evaluar continuidad debido a: Mareos	-0.9	Su paciente podría continuar recibiendo NALTREXONA -\n                                BUPROPION como complemento de una dieta reducida en\n                                calorías y de actividad física para el control crónico del peso.\n	0
349	2019-09-14 00:49:41.351216+00	2019-09-14 00:49:52.697988+00	110	170	first	f	30	295	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
375	2019-09-17 20:35:17.135294+00	2019-09-17 20:36:12.335303+00	98	170	first	f	35	309	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
385	2019-09-28 16:55:48.613927+00	2019-09-28 16:55:48.613953+00	83	170	first	t	10	321					
424	2019-10-03 02:19:24.414467+00	2019-10-03 02:19:38.880913+00	120	170	first	t	10	354	INDICADO	SE RECOMIENDA MEDIR RUTINARIAMENTE LA GLUCEMIA. DEBE TENERSE PRECAUCIÓN CON EL RIESGO DE HIPOGLUCEMIA Y CONSIDERAR DISMINUIR LA DOSIS DE HIPOGLUCEMIANTES.\nPRECAUCIÓN. PARA REDUCIR EL RIESGO DE CONVULSIONES SE RECOMIENDA UNA DOSIS TOTAL DE MÁXIMO 4 COMPRIMIDOS POR DÍA. DIVIDIR LA DOSIS DIARIA EN DOS TOMAS, ESCALAR LA DOSIS DE MANERA GRADUAL.\nES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
434	2019-10-08 02:38:22.441821+00	2019-10-08 02:38:22.441848+00	97	190	first	t	30	393	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC es menor a 27.			
444	2019-10-08 19:53:12.536035+00	2019-10-08 19:54:35.783758+00	121	181	first	f	92	403	INDICADO	RECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
453	2019-10-09 22:21:22.17973+00	2019-10-09 22:23:32.297516+00	81	164	first	f	85	416	INDICADO			Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
457	2019-10-10 12:32:43.24933+00	2019-10-10 12:32:43.249356+00	94	188	first	f	110	421	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC es menor a 27.			
475	2019-10-11 04:45:00.366928+00	2019-10-11 04:47:56.495386+00	87	158	first	f	145	447	CONTRA INDICADO	Tratamiento actual con: BARBITURICOS,\n                            ANTIEPILEPTICOS, ANTIPSICOTICOS,\n                            OPIOIDES O AGONISTAS OPIACEOS,\n                            BUPROPION, IMAO, RITONAVIR,\n                            LOPINAVIR, EFAVIRENZ,\n                            CARBAMACEPINA, ANTIDEPRESIVOS,\n                            DROGAS METABOLIZADAS POR\n                            CYP2D6 (TAMOXIFENO).\n		El paciente tiene las siguientes\n                            contraindicaciones para recibir NALTREXONA\n                            - BUPROPION.	
476	2019-10-11 08:19:35.105332+00	2019-10-11 08:21:12.388891+00	103	175	first	f	139	448	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
479	2019-10-11 11:55:15.15918+00	2019-10-11 11:58:24.105629+00	98	180	first	t	149	453	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
481	2019-10-11 12:55:31.256928+00	2019-10-11 12:55:59.839594+00	120	176	first	t	124	455	INDICADO	SE RECOMIENDA MEDIR RUTINARIAMENTE LA GLUCEMIA. DEBE TENERSE PRECAUCIÓN CON EL RIESGO DE HIPOGLUCEMIA Y CONSIDERAR DISMINUIR LA DOSIS DE HIPOGLUCEMIANTES.\nES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
482	2019-10-11 13:20:01.579053+00	2019-10-11 13:20:33.118866+00	95	176	first	f	124	456	INDICADO	PRECAUCIÓN. LA MÁXIMA DOSIS RECOMENDADA EN EL SEGUIMIENTO ES 1 COMPRIMIDO A LA MAÑANA Y 1 COMPRIMIDO A LA NOCHE.\nES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
483	2019-10-11 14:18:27.535197+00	2019-10-11 14:19:46.264003+00	136	175	first	f	157	457	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
484	2019-10-11 14:19:22.171254+00	2019-10-11 14:21:03.56235+00	92	175	first	t	149	458	CONTRA INDICADO	Tratamiento actual con: BARBITURICOS,\n                            ANTIEPILEPTICOS, ANTIPSICOTICOS,\n                            OPIOIDES O AGONISTAS OPIACEOS,\n                            BUPROPION, IMAO, RITONAVIR,\n                            LOPINAVIR, EFAVIRENZ,\n                            CARBAMACEPINA, ANTIDEPRESIVOS,\n                            DROGAS METABOLIZADAS POR\n                            CYP2D6 (TAMOXIFENO).\n		El paciente tiene las siguientes\n                            contraindicaciones para recibir NALTREXONA\n                            - BUPROPION.	
486	2019-10-11 14:24:32.670419+00	2019-10-11 14:26:43.913859+00	116	181	first	t	98	460	INDICADO			Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
487	2019-10-11 15:26:10.213404+00	2019-10-11 15:27:17.056297+00	88	155	first	f	145	462	INDICADO			Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
489	2019-10-11 15:49:37.380012+00	2019-10-11 15:49:37.380037+00	62	159	first	f	158	463	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC es menor a 27.			
490	2019-10-11 16:10:59.623859+00	2019-10-11 16:12:02.713823+00	105	180	first	t	101	464	CONTRA INDICADO	Depresión mayor, trastorno bipolar, manía o ideación suicida.\nHTA no controlada.\n		El paciente tiene las siguientes\n                            contraindicaciones para recibir NALTREXONA\n                            - BUPROPION.	
491	2019-10-11 18:17:30.900834+00	2019-10-11 18:19:47.301391+00	98	158	first	f	162	465	INDICADO	PRECAUCIÓN. LA MÁXIMA DOSIS RECOMENDADA EN EL SEGUIMIENTO ES 1 COMPRIMIDO A LA MAÑANA Y 1 COMPRIMIDO A LA NOCHE.\nES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\nPRECAUCIÓN. EL USO DE NALTREXONA - BUPROPION JUNTO CON ESTOS MEDICAMENTOS INCREMENTA EL RIESGO DE EVENTOS ADVERSOS.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
493	2019-10-11 18:59:46.163913+00	2019-10-11 19:00:16.722787+00	88	164	first	t	161	468	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
492	2019-10-11 18:57:48.022607+00	2019-10-11 19:03:00.10751+00	83	161	first	t	161	466	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
494	2019-10-11 20:24:27.085858+00	2019-10-11 20:24:27.085884+00	79	164	first	f	116	469	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC está entre 27 y 29.9 en ausencia de                          factores de riesgo cardiovascular (hipertensión arterial, diabetes o dislipidemia).			
496	2019-10-11 20:28:04.644911+00	2019-10-11 20:34:39.479454+00	96	164	first	f	116	471	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
497	2019-10-12 00:10:33.1593+00	2019-10-12 00:12:10.441846+00	90	170	first	t	164	472	INDICADO	USAR CON PRECAUCIÓN EN MAYORES DE 65 AÑOS POR MAYOR RIESGO DE EVENTOS ADVERSOS DEBIDO A LA ELIMINACIÓN RENAL DE NALTREXONA - BUPROPION.\nSE RECOMIENDA MEDIR RUTINARIAMENTE LA GLUCEMIA. DEBE TENERSE PRECAUCIÓN CON EL RIESGO DE HIPOGLUCEMIA Y CONSIDERAR DISMINUIR LA DOSIS DE HIPOGLUCEMIANTES.\nPRECAUCIÓN. PARA REDUCIR EL RIESGO DE CONVULSIONES SE RECOMIENDA UNA DOSIS TOTAL DE MÁXIMO 4 COMPRIMIDOS POR DÍA. DIVIDIR LA DOSIS DIARIA EN DOS TOMAS, ESCALAR LA DOSIS DE MANERA GRADUAL.\nES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nNALTREXONA - BUPROPION PUEDE AUMENTAR LA FRECUENCIA CARDIACA Y LA PRESIÓN ARTERIAL POR LO QUE SE RECOMIENDA UN CONTROL ESTRICTO DE LA FC Y LA TA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
498	2019-10-12 11:41:20.444744+00	2019-10-12 11:41:20.444782+00	80	175	first	t	166	473	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC es menor a 27.			
499	2019-10-12 11:45:52.507845+00	2019-10-12 11:48:27.410147+00	85	175	first	t	166	474	INDICADO	RECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
500	2019-10-12 11:51:29.364315+00	2019-10-12 11:52:11.232577+00	112	182	first	f	166	475	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
501	2019-10-12 19:42:58.537307+00	2019-10-12 19:42:58.537334+00	80	164	first	f	116	476	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC está entre 27 y 29.9 en ausencia de                          factores de riesgo cardiovascular (hipertensión arterial, diabetes o dislipidemia).			
502	2019-10-12 19:44:32.754467+00	2019-10-12 19:45:57.134192+00	80	164	first	t	116	477	CONTRA INDICADO	Depresión mayor, trastorno bipolar, manía o ideación suicida.\nOtros trastornos psiquiátricos{incluidos en la cesación tabáquica}.\n		El paciente tiene las siguientes\n                            contraindicaciones para recibir NALTREXONA\n                            - BUPROPION.	
503	2019-10-13 19:07:54.805937+00	2019-10-13 19:07:54.805962+00	75	174	first	f	134	478	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC es menor a 27.			
504	2019-10-14 23:04:47.950772+00	2019-10-14 23:04:47.950799+00	64	162	first	f	189	479	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC es menor a 27.			
505	2019-10-15 12:53:34.101338+00	2019-10-15 12:53:50.494161+00	80	180	follow-up	t	30	297	SUSPENDER	HTA no controlada.\n	-14.0	El paciente tiene las siguientes\n                            contraindicaciones y debe suspender el\n                            tratamiento de NALTREXONA - BUPROPION.	4
506	2019-10-15 18:11:54.509851+00	2019-10-15 18:14:07.749883+00	108	158	first	f	77	480	INDICADO			Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
507	2019-10-16 11:18:59.449271+00	2019-10-16 11:19:50.748494+00	75	160	first	t	116	484	INDICADO			Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
508	2019-10-16 17:21:29.856277+00	2019-10-16 17:22:44.014342+00	79	163	first	t	189	485	CONTRA INDICADO	Intolerancia a la lactosa.\n		El paciente tiene las siguientes\n                            contraindicaciones para recibir NALTREXONA\n                            - BUPROPION.	
509	2019-10-17 12:00:20.572258+00	2019-10-17 12:01:08.358205+00	130	179	first	t	199	486	INDICADO	SE RECOMIENDA MEDIR RUTINARIAMENTE LA GLUCEMIA. DEBE TENERSE PRECAUCIÓN CON EL RIESGO DE HIPOGLUCEMIA Y CONSIDERAR DISMINUIR LA DOSIS DE HIPOGLUCEMIANTES.\nES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
510	2019-10-17 13:33:15.152262+00	2019-10-17 13:34:50.985343+00	86	160	first	t	149	487	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\nNALTREXONA - BUPROPION PUEDE AUMENTAR LA FRECUENCIA CARDIACA Y LA PRESIÓN ARTERIAL POR LO QUE SE RECOMIENDA UN CONTROL ESTRICTO DE LA FC Y LA TA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
511	2019-10-17 13:35:43.529353+00	2019-10-17 13:36:10.022426+00	58	160	follow-up	t	149	487	CONTINUAR	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n	-32.6	Su paciente podría continuar recibiendo NALTREXONA -\n                                BUPROPION como complemento de una dieta reducida en\n                                calorías y de actividad física para el control crónico del peso.\n	0
512	2019-10-17 15:36:07.747158+00	2019-10-17 15:36:07.747189+00	66	157	first	f	149	489	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC es menor a 27.			
513	2019-10-17 15:36:42.074992+00	2019-10-17 15:38:08.668848+00	79	157	first	f	149	490	INDICADO	SE RECOMIENDA MEDIR RUTINARIAMENTE LA GLUCEMIA. DEBE TENERSE PRECAUCIÓN CON EL RIESGO DE HIPOGLUCEMIA Y CONSIDERAR DISMINUIR LA DOSIS DE HIPOGLUCEMIANTES.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
515	2019-10-17 18:26:34.343865+00	2019-10-17 18:28:46.45894+00	104	163	first	f	200	491	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
516	2019-10-17 18:29:31.262059+00	2019-10-17 18:29:31.262091+00	90	183	first	t	202	492	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC es menor a 27.			
520	2019-10-18 13:53:35.911494+00	2019-10-18 13:56:41.856294+00	90	180	follow-up	t	86	400	CONTINUAR	Evaluar continuidad debido a: Insomnio	-1.1	Su paciente podría continuar recibiendo NALTREXONA -\n                                BUPROPION como complemento de una dieta reducida en\n                                calorías y de actividad física para el control crónico del peso.\n	1
537	2019-10-23 20:59:32.06667+00	2019-10-23 20:59:32.066697+00	92	173	first	f	216	521					
517	2019-10-17 19:38:41.347161+00	2019-10-17 19:40:33.383285+00	85	160	first	f	89	494	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
518	2019-10-17 23:52:04.115894+00	2019-10-17 23:53:25.943012+00	87	169	first	f	203	497	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
519	2019-10-18 00:51:45.787948+00	2019-10-18 00:53:36.04912+00	95	160	first	t	198	498	INDICADO	PRECAUCIÓN. LA MÁXIMA DOSIS RECOMENDADA EN EL SEGUIMIENTO ES 1 COMPRIMIDO A LA MAÑANA Y 1 COMPRIMIDO A LA NOCHE.\nES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
522	2019-10-18 14:55:00.723429+00	2019-10-18 14:55:24.105123+00	135	180	first	f	124	500	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
523	2019-10-18 15:36:09.733125+00	2019-10-18 15:36:33.940846+00	90	180	follow-up	t	86	400	SUSPENDER	Tratamiento actual con: BARBITURICOS,\n                                ANTIEPILEPTICOS, ANTIPSICOTICOS,\n                                OPIOIDES O AGONISTAS OPIACEOS,\n                                BUPROPION, IMAO, RITONAVIR,\n                                LOPINAVIR, EFAVIRENZ,\n                                CARBAMACEPINA, ANTIDEPRESIVOS,\n                                DROGAS METABOLIZADAS POR\n                                CYP2D6 (TAMOXIFENO).\n	-1.1	El paciente tiene las siguientes\n                            contraindicaciones y debe suspender el\n                            tratamiento de NALTREXONA - BUPROPION.	1
524	2019-10-18 18:25:35.266007+00	2019-10-18 18:26:46.96234+00	120	180	first	t	124	501	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nPRECAUCIÓN. EL USO DE NALTREXONA - BUPROPION JUNTO CON ESTOS MEDICAMENTOS INCREMENTA EL RIESGO DE EVENTOS ADVERSOS.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
525	2019-10-18 18:28:31.767014+00	2019-10-18 18:28:31.76704+00	79	178	first	f	124	502	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC es menor a 27.			
526	2019-10-19 00:23:40.543155+00	2019-10-19 00:25:19.647902+00	81	170	first	t	189	503	CONTRA INDICADO	Tratamiento actual con: BARBITURICOS,\n                            ANTIEPILEPTICOS, ANTIPSICOTICOS,\n                            OPIOIDES O AGONISTAS OPIACEOS,\n                            BUPROPION, IMAO, RITONAVIR,\n                            LOPINAVIR, EFAVIRENZ,\n                            CARBAMACEPINA, ANTIDEPRESIVOS,\n                            DROGAS METABOLIZADAS POR\n                            CYP2D6 (TAMOXIFENO).\n		El paciente tiene las siguientes\n                            contraindicaciones para recibir NALTREXONA\n                            - BUPROPION.	
527	2019-10-19 18:14:06.458316+00	2019-10-19 18:15:12.451285+00	81	159	first	t	149	504	INDICADO	USAR CON PRECAUCIÓN EN MAYORES DE 65 AÑOS POR MAYOR RIESGO DE EVENTOS ADVERSOS DEBIDO A LA ELIMINACIÓN RENAL DE NALTREXONA - BUPROPION.\nES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
528	2019-10-19 18:14:22.752836+00	2019-10-19 18:15:27.807849+00	98	170	first	f	206	506	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
530	2019-10-21 15:02:10.431814+00	2019-10-21 15:02:10.43184+00	86	175	first	t	89	512					
529	2019-10-19 21:57:30.005696+00	2019-10-19 21:57:30.005722+00	65	155	first	f	117	511	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC está entre 27 y 29.9 en ausencia de                          factores de riesgo cardiovascular (hipertensión arterial, diabetes o dislipidemia).			
531	2019-10-22 18:27:19.826657+00	2019-10-22 18:27:56.802132+00	113	181	follow-up	f	92	403	CONTINUAR	RECOMENDAR DIETA HIPOCALÓRICA.\n	-6.6	Su paciente podría continuar recibiendo NALTREXONA -\n                                BUPROPION como complemento de una dieta reducida en\n                                calorías y de actividad física para el control crónico del peso.\n	1
532	2019-10-23 12:30:43.531362+00	2019-10-23 12:32:00.746383+00	125	170	first	t	212	515	CONTRA INDICADO	Depresión mayor, trastorno bipolar, manía o ideación suicida.\nOtros trastornos psiquiátricos{incluidos en la cesación tabáquica}.\nInsuficiencia Hepática.: Moderada a grave\n		El paciente tiene las siguientes\n                            contraindicaciones para recibir NALTREXONA\n                            - BUPROPION.	
533	2019-10-23 15:46:21.549602+00	2019-10-23 15:48:36.016663+00	112	164	first	t	212	516	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nNALTREXONA - BUPROPION PUEDE AUMENTAR LA FRECUENCIA CARDIACA Y LA PRESIÓN ARTERIAL POR LO QUE SE RECOMIENDA UN CONTROL ESTRICTO DE LA FC Y LA TA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
534	2019-10-23 17:01:22.996059+00	2019-10-23 17:03:23.842666+00	149	180	first	t	210	517	INDICADO	SE RECOMIENDA MEDIR RUTINARIAMENTE LA GLUCEMIA. DEBE TENERSE PRECAUCIÓN CON EL RIESGO DE HIPOGLUCEMIA Y CONSIDERAR DISMINUIR LA DOSIS DE HIPOGLUCEMIANTES.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
535	2019-10-23 17:05:54.9428+00	2019-10-23 17:06:40.757394+00	94	169	first	f	210	518	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
536	2019-10-23 17:08:06.238687+00	2019-10-23 17:08:52.105156+00	86	163	first	t	210	519	INDICADO	NALTREXONA - BUPROPION PUEDE AUMENTAR LA FRECUENCIA CARDIACA Y LA PRESIÓN ARTERIAL POR LO QUE SE RECOMIENDA UN CONTROL ESTRICTO DE LA FC Y LA TA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
538	2019-10-24 03:48:34.923143+00	2019-10-24 03:48:34.923166+00	70	160	first	f	217	522	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC está entre 27 y 29.9 en ausencia de                          factores de riesgo cardiovascular (hipertensión arterial, diabetes o dislipidemia).			
539	2019-10-24 12:41:42.967966+00	2019-10-24 12:43:20.164078+00	135	167	first	t	218	525	INDICADO	SE RECOMIENDA MEDIR RUTINARIAMENTE LA GLUCEMIA. DEBE TENERSE PRECAUCIÓN CON EL RIESGO DE HIPOGLUCEMIA Y CONSIDERAR DISMINUIR LA DOSIS DE HIPOGLUCEMIANTES.\nES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nNALTREXONA - BUPROPION PUEDE AUMENTAR LA FRECUENCIA CARDIACA Y LA PRESIÓN ARTERIAL POR LO QUE SE RECOMIENDA UN CONTROL ESTRICTO DE LA FC Y LA TA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
540	2019-10-24 16:52:09.328424+00	2019-10-24 16:52:27.684276+00	120	178	first	t	124	527	INDICADO	SE RECOMIENDA MEDIR RUTINARIAMENTE LA GLUCEMIA. DEBE TENERSE PRECAUCIÓN CON EL RIESGO DE HIPOGLUCEMIA Y CONSIDERAR DISMINUIR LA DOSIS DE HIPOGLUCEMIANTES.\nES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
541	2019-10-24 17:36:24.114634+00	2019-10-24 17:36:52.963623+00	112	181	follow-up	f	92	403	CONTINUAR	Evaluar continuidad debido a: Constipación	-7.4	\n                                Iniciar tratamiento con 1 comprimido (8mg/90mg) por la \n                                mañana y 1 comprimido (8mg/90mg) por la noche (NO junto \n                                a comidas grasas). Los comprimidos no deben ser cortados, \n                                masticados ni triturados.\n\n                                Si se omitió una dosis, ésta debe saltearse y reanudar la \n                                administración al momento de la siguiente dosis.	2
542	2019-10-24 17:42:16.751249+00	2019-10-24 17:43:27.277874+00	100	170	first	t	219	528	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
543	2019-10-25 19:22:35.277262+00	2019-10-25 19:23:53.928049+00	115	162	first	t	219	529	CONTRA INDICADO	EL USO DE NALTREXONA - BUPROPION ESTÁ CONTRA INDICADO AL MENOS 3 DÍAS ANTES DE LA CIRUGÍA PROGRAMADA.		El paciente tiene las siguientes\n                            contraindicaciones para recibir NALTREXONA\n                            - BUPROPION.	
544	2019-10-25 19:33:29.916909+00	2019-10-25 19:34:08.667291+00	96	172	first	f	219	530	INDICADO	ES RECOMENDABLE INICIAR ACTIVIDAD FÍSICA O INCREMENTAR LA FRECUENCIA A 3 VECES POR SEMANA.\nRECOMENDAR DIETA HIPOCALÓRICA.\n		Su paciente podría recibir NALTREXONA - BUPROPION como\n                            complemento de una dieta reducida en calorías y de actividad\n                            física para el control crónico del peso.\n                            Iniciar tratamiento con 1 comprimido (8mg/90mg) por la\n                            mañana (NO junto a comidas grasas). Los comprimidos no\n                            deben ser cortados, masticados ni triturados.\n\n                            Si se omitió una dosis, ésta debe saltearse y reanudar la\n                            administración al momento de la siguiente dosis.	
545	2019-10-28 13:30:53.72497+00	2019-10-28 13:31:49.550701+00	82	160	follow-up	t	83	401	SUSPENDER	Depresión mayor, trastorno bipolar, manía o ideación suicida.\nOtros trastornos psiquiátricos (incluidos en la cesación tabáquica).\n	-3.5	El paciente tiene las siguientes\n                            contraindicaciones y debe suspender el\n                            tratamiento de NALTREXONA - BUPROPION.	2
546	2019-10-28 13:45:51.023527+00	2019-10-28 13:45:51.023555+00	83	175	first	f	130	532	NO INDICADO	NALTREXONA - BUPROPION no está indicado si el IMC está entre 27 y 29.9 en ausencia de                          factores de riesgo cardiovascular (hipertensión arterial, diabetes o dislipidemia).			
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 74, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 621, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 35, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 41, true);


--
-- Name: patients_patient_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

SELECT pg_catalog.setval('public.patients_patient_id_seq', 532, true);


--
-- Name: users_profile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

SELECT pg_catalog.setval('public.users_profile_id_seq', 224, true);


--
-- Name: users_registrationtype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

SELECT pg_catalog.setval('public.users_registrationtype_id_seq', 3, true);


--
-- Name: users_speciality_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

SELECT pg_catalog.setval('public.users_speciality_id_seq', 5, true);


--
-- Name: users_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

SELECT pg_catalog.setval('public.users_user_groups_id_seq', 1, false);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

SELECT pg_catalog.setval('public.users_user_id_seq', 228, true);


--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

SELECT pg_catalog.setval('public.users_user_user_permissions_id_seq', 1, false);


--
-- Name: visits_firstvisitcomplementinformation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

SELECT pg_catalog.setval('public.visits_firstvisitcomplementinformation_id_seq', 374, true);


--
-- Name: visits_followupvisitcomplementinformation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

SELECT pg_catalog.setval('public.visits_followupvisitcomplementinformation_id_seq', 184, true);


--
-- Name: visits_visit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

SELECT pg_catalog.setval('public.visits_visit_id_seq', 546, true);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: authtoken_token authtoken_token_pkey; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_pkey PRIMARY KEY (key);


--
-- Name: authtoken_token authtoken_token_user_id_key; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_key UNIQUE (user_id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: patients_patient patients_patient_pkey; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.patients_patient
    ADD CONSTRAINT patients_patient_pkey PRIMARY KEY (id);


--
-- Name: patients_patient patients_patient_username_key; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.patients_patient
    ADD CONSTRAINT patients_patient_username_key UNIQUE (username);


--
-- Name: users_profile users_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.users_profile
    ADD CONSTRAINT users_profile_pkey PRIMARY KEY (id);


--
-- Name: users_profile users_profile_user_id_key; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.users_profile
    ADD CONSTRAINT users_profile_user_id_key UNIQUE (user_id);


--
-- Name: users_registrationtype users_registrationtype_pkey; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.users_registrationtype
    ADD CONSTRAINT users_registrationtype_pkey PRIMARY KEY (id);


--
-- Name: users_speciality users_speciality_pkey; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.users_speciality
    ADD CONSTRAINT users_speciality_pkey PRIMARY KEY (id);


--
-- Name: users_user users_user_email_key; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_email_key UNIQUE (email);


--
-- Name: users_user_groups users_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups users_user_groups_user_id_group_id_b88eab82_uniq; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_group_id_b88eab82_uniq UNIQUE (user_id, group_id);


--
-- Name: users_user users_user_pkey; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_permission_id_43338c45_uniq; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_permission_id_43338c45_uniq UNIQUE (user_id, permission_id);


--
-- Name: users_user users_user_username_key; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_username_key UNIQUE (username);


--
-- Name: visits_firstvisitcomplementinformation visits_firstvisitcomplementinformation_pkey; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.visits_firstvisitcomplementinformation
    ADD CONSTRAINT visits_firstvisitcomplementinformation_pkey PRIMARY KEY (id);


--
-- Name: visits_firstvisitcomplementinformation visits_firstvisitcomplementinformation_visit_id_key; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.visits_firstvisitcomplementinformation
    ADD CONSTRAINT visits_firstvisitcomplementinformation_visit_id_key UNIQUE (visit_id);


--
-- Name: visits_followupvisitcomplementinformation visits_followupvisitcomplementinformation_pkey; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.visits_followupvisitcomplementinformation
    ADD CONSTRAINT visits_followupvisitcomplementinformation_pkey PRIMARY KEY (id);


--
-- Name: visits_followupvisitcomplementinformation visits_followupvisitcomplementinformation_visit_id_key; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.visits_followupvisitcomplementinformation
    ADD CONSTRAINT visits_followupvisitcomplementinformation_visit_id_key UNIQUE (visit_id);


--
-- Name: visits_visit visits_visit_pkey; Type: CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.visits_visit
    ADD CONSTRAINT visits_visit_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: authtoken_token_key_10f0b77e_like; Type: INDEX; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE INDEX authtoken_token_key_10f0b77e_like ON public.authtoken_token USING btree (key varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: patients_patient_doctor_id_1c263247; Type: INDEX; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE INDEX patients_patient_doctor_id_1c263247 ON public.patients_patient USING btree (doctor_id);


--
-- Name: patients_patient_username_dfed4915_like; Type: INDEX; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE INDEX patients_patient_username_dfed4915_like ON public.patients_patient USING btree (username varchar_pattern_ops);


--
-- Name: users_profile_registration_type_id_8ccc1877; Type: INDEX; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE INDEX users_profile_registration_type_id_8ccc1877 ON public.users_profile USING btree (registration_type_id);


--
-- Name: users_profile_speciality_id_90d12182; Type: INDEX; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE INDEX users_profile_speciality_id_90d12182 ON public.users_profile USING btree (speciality_id);


--
-- Name: users_registrationtype_slug_name_dd26647e; Type: INDEX; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE INDEX users_registrationtype_slug_name_dd26647e ON public.users_registrationtype USING btree (slug_name);


--
-- Name: users_registrationtype_slug_name_dd26647e_like; Type: INDEX; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE INDEX users_registrationtype_slug_name_dd26647e_like ON public.users_registrationtype USING btree (slug_name varchar_pattern_ops);


--
-- Name: users_speciality_slug_name_f7866c42; Type: INDEX; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE INDEX users_speciality_slug_name_f7866c42 ON public.users_speciality USING btree (slug_name);


--
-- Name: users_speciality_slug_name_f7866c42_like; Type: INDEX; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE INDEX users_speciality_slug_name_f7866c42_like ON public.users_speciality USING btree (slug_name varchar_pattern_ops);


--
-- Name: users_user_email_243f6e77_like; Type: INDEX; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE INDEX users_user_email_243f6e77_like ON public.users_user USING btree (email varchar_pattern_ops);


--
-- Name: users_user_groups_group_id_9afc8d0e; Type: INDEX; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE INDEX users_user_groups_group_id_9afc8d0e ON public.users_user_groups USING btree (group_id);


--
-- Name: users_user_groups_user_id_5f6f5a90; Type: INDEX; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE INDEX users_user_groups_user_id_5f6f5a90 ON public.users_user_groups USING btree (user_id);


--
-- Name: users_user_user_permissions_permission_id_0b93982e; Type: INDEX; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE INDEX users_user_user_permissions_permission_id_0b93982e ON public.users_user_user_permissions USING btree (permission_id);


--
-- Name: users_user_user_permissions_user_id_20aca447; Type: INDEX; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE INDEX users_user_user_permissions_user_id_20aca447 ON public.users_user_user_permissions USING btree (user_id);


--
-- Name: users_user_username_06e46fe6_like; Type: INDEX; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE INDEX users_user_username_06e46fe6_like ON public.users_user USING btree (username varchar_pattern_ops);


--
-- Name: visits_visit_doctor_id_ecb90376; Type: INDEX; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE INDEX visits_visit_doctor_id_ecb90376 ON public.visits_visit USING btree (doctor_id);


--
-- Name: visits_visit_patient_id_59dd1282; Type: INDEX; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

CREATE INDEX visits_visit_patient_id_59dd1282 ON public.visits_visit USING btree (patient_id);


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authtoken_token authtoken_token_user_id_35299eff_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_35299eff_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: patients_patient patients_patient_doctor_id_1c263247_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.patients_patient
    ADD CONSTRAINT patients_patient_doctor_id_1c263247_fk_users_user_id FOREIGN KEY (doctor_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_profile users_profile_registration_type_id_8ccc1877_fk_users_reg; Type: FK CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.users_profile
    ADD CONSTRAINT users_profile_registration_type_id_8ccc1877_fk_users_reg FOREIGN KEY (registration_type_id) REFERENCES public.users_registrationtype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_profile users_profile_speciality_id_90d12182_fk_users_speciality_id; Type: FK CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.users_profile
    ADD CONSTRAINT users_profile_speciality_id_90d12182_fk_users_speciality_id FOREIGN KEY (speciality_id) REFERENCES public.users_speciality(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_profile users_profile_user_id_2112e78d_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.users_profile
    ADD CONSTRAINT users_profile_user_id_2112e78d_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_group_id_9afc8d0e_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_group_id_9afc8d0e_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_user_id_5f6f5a90_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_5f6f5a90_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_perm_permission_id_0b93982e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_perm_permission_id_0b93982e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_20aca447_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_20aca447_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: visits_firstvisitcomplementinformation visits_firstvisitcom_visit_id_cbb83b73_fk_visits_vi; Type: FK CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.visits_firstvisitcomplementinformation
    ADD CONSTRAINT visits_firstvisitcom_visit_id_cbb83b73_fk_visits_vi FOREIGN KEY (visit_id) REFERENCES public.visits_visit(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: visits_followupvisitcomplementinformation visits_followupvisit_visit_id_cea7bf6e_fk_visits_vi; Type: FK CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.visits_followupvisitcomplementinformation
    ADD CONSTRAINT visits_followupvisit_visit_id_cea7bf6e_fk_visits_vi FOREIGN KEY (visit_id) REFERENCES public.visits_visit(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: visits_visit visits_visit_doctor_id_ecb90376_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.visits_visit
    ADD CONSTRAINT visits_visit_doctor_id_ecb90376_fk_users_user_id FOREIGN KEY (doctor_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: visits_visit visits_visit_patient_id_59dd1282_fk_patients_patient_id; Type: FK CONSTRAINT; Schema: public; Owner: drTRFirsjjWlynNSYPKywpdutrRazkEk
--

ALTER TABLE ONLY public.visits_visit
    ADD CONSTRAINT visits_visit_patient_id_59dd1282_fk_patients_patient_id FOREIGN KEY (patient_id) REFERENCES public.patients_patient(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

